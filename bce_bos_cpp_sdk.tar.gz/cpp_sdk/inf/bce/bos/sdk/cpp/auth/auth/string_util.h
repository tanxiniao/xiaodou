#ifndef INF_DS_BOSS_SDK_C_SRC_AUTH_STRING_UTIL_H_
#define INF_DS_BOSS_SDK_C_SRC_AUTH_STRING_UTIL_H_
#include <string>
class StringUtil {
};

#endif // INF_DS_BOSS_SDK_C_SRC_AUTH_STRING_UTIL_H_
