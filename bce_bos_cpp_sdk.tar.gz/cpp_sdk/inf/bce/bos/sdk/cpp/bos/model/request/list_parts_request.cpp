/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file list_parts_request.cpp
 * @author huangshuai05(com@baidu.com)
 * @date 2014/07/21 09:52:42
 * @brief 
 *  
 **/


#include "inf/bce/bos/sdk/cpp/bos/model/request/list_parts_request.h"
namespace bce {
namespace bos {
ListPartsRequest::~ListPartsRequest() {
	
}
}
}





















/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
