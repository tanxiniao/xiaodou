/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file list_multipart_uploads_request.cpp
 * @author huangshuai05(com@baidu.com)
 * @date 2014/07/21 09:50:47
 * @brief 
 *  
 **/


#include "inf/bce/bos/sdk/cpp/bos/model/request/list_multipart_uploads_request.h"
namespace bce {
namespace bos {
ListMultipartUploadsRequest::~ListMultipartUploadsRequest() {

}
}
}





















/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
