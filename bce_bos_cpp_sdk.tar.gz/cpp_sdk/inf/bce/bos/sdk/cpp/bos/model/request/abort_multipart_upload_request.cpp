/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file abort_multipart_upload_request.cpp
 * @author huangshuai05(com@baidu.com)
 * @date 2014/07/18 13:27:08
 * @brief 
 *  
 **/

#include "inf/bce/bos/sdk/cpp/bos/model/request/abort_multipart_upload_request.h"

namespace bce {
namespace bos {

AbortMultipartUploadRequest::~AbortMultipartUploadRequest() {

}
}
}





















/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
