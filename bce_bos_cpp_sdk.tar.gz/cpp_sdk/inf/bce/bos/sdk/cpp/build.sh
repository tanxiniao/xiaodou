comake2
make MAC=64 clean
make MAC=64

