#include "inf/bce/bos/sdk/cpp/util/log.h"

BEGIN_C_SDK_NAMESPACE
void SetLogId(uint64_t log_id) {
}

uint64_t GetLogId() {
    return 0;
}

int GetThreadId() {
    return 0;
}

int GetLogLevel() {
    return 16;
}

void SetLogLevel(int log_level) {
}

END_C_SDK_NAMESPACE
