/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file bos_log.cpp
 * @author huangshuai05(com@baidu.com)
 * @date 2014/08/13 16:44:27
 * @brief 
 *  
 **/

#include "inf/bce/bos/sdk/cpp/util/bos_log.h" 

namespace bce {
namespace bos {

int Log::m_level = 0;
UserPrintType Log::UserPrint = NULL;

}
}





















/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
