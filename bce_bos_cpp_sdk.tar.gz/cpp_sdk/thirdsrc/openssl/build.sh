#!/bin/bash

if [ "`echo $MAC`" = "ARM32" ]
    then
    export LANG=en_US:zh_CN.UTF-8
    export LC_ALL=C
fi

NAME=`ls *.gz *.bz2 2>/dev/null`
echo build $NAME

INSTALL=$PWD/install

case $NAME in
    *.tar.gz)
        SRC=`basename $NAME .tar.gz`
        rm -rf $SRC
        tar xzf $NAME
        ;;
    *.tar.bz2)
        SRC=`basename $NAME .tar.bz2`
        rm -rf $SRC
        tar xjf $NAME
        ;;
esac

cd $SRC
CONFIG="./config --prefix=$INSTALL no-shared threads -fPIC"
$CONFIG
make
make install

cd $INSTALL/..
rm -rf output
mkdir output
cp -r $INSTALL/include output
cp -r $INSTALL/lib output
if test -s README; then
    cp README output/
fi
if test -s ChangeLog; then
    cp ChangeLog output/
fi
if which tree; then
    tree output
fi
