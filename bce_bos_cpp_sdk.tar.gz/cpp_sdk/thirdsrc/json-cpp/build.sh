#! /bin/bash

GCC_VER="linux-gcc-3.4.5"

tar -zxvf scons-2.3.0.tar.gz

cd scons-2.3.0

python setup.py install

export MYSCONS=`pwd`

export SCONS_LIB_DIR=$MYSCONS/engine

cd ..

tar -zxvf jsoncpp-src-0.6.0-rc2.tar.gz

cd jsoncpp-src-0.6.0-rc2

python $MYSCONS/script/scons platform=linux-gcc

cd ..

mkdir output
mkdir output/lib

cp -r jsoncpp-src-0.6.0-rc2/include/ output/
cp -r jsoncpp-src-0.6.0-rc2/libs/${GCC_VER}/* output/lib
cd output/lib
mv libjson_${GCC_VER}_libmt.a libjson_libmt.a
mv libjson_${GCC_VER}_libmt.so libjson_libmt.so
