use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file BaseCae.php
 * @author wanglinqing01
 * @date 2014/10/13
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../baidubce/services/sms/SmsClient.php');
use baidubce\sms\SmsClient;

abstract class BaseCase extends PHPUnit_Framework_TestCase {
	protected static $VARIABLE_NAME_DEFAULT = 'variable';
	protected static $TPL_NAME_MAX_LEN = 32;
	private $tplIndex = 0;
	
	protected function getPhoneNumberRandom($suffix='0'){
		return strval(time()).$suffix;
	}
	
	protected function getTplNameRandom($prefix){
		$name = $prefix . time() . ($this->tplIndex++);
		$len = strlen($name);
		if($len > self::$TPL_NAME_MAX_LEN){
			$name = substr($name, $len-self::$TPL_NAME_MAX_LEN, self::$TPL_NAME_MAX_LEN);
		}
		return $name;
	}
	
    protected function newTpl($templateName='', $templateContent=''){
    	$client = SmsClient::getInstance();
    	if(empty($templateName))
    	{
    		$now = time();
    		$templateName = 'smstpl_' . $now;    // template name can not be more than 32 characters in length
    	}
		
		if(empty($templateContent))
		{
			$templateContent = 'this is content for ${TEMPLATE_NAME}, now time is ${CURRENT_TIME}';  // the ${...} string will be replaced later
		}
		$resp = $client->templateCreate($templateName, $templateContent);
		$tplId = $resp->getTemplateId();
		$this->assertEquals('200', $resp->getHttpStatusCode());
    	$this->assertNotEmpty($resp->getTemplateId());
		echo "we create a SMS template, the templateId=${tplId}.\n";  	
    	return $resp->getTemplateId();
    }
    
    protected function setTplStatus($tplId, $status='VALID'){
    	//set SMS tempalte status to VALID
		$client = SmsClient::getInstance();
		$resp = $client->templateUpdate($tplId, null, null, $status);
		echo "we set $tplId status to " . $status . ".\n";
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    }
    
    protected function sendMsg($tplId, array $receiverList, array $contentVarMap){
		$client = SmsClient::getInstance();
		$resp = $client->messageSend($tplId, $receiverList, $contentVarMap);
		echo "we send message to '" .implode(',', $receiverList). "',\n";
		echo "    send count: " . $resp->getSendCount() . "\n";
		echo "    success count: " . $resp->getSuccessCount() . "\n";
		echo "    fail list: " . json_encode($resp->getFailList()) . "\n";
		$this->assertEquals('200',  $resp->getHttpStatusCode());
		$this->assertEquals(count($receiverList), $resp->getSuccessCount());
    	$this->assertEquals(count($receiverList), $resp->getSendCount());
		return $resp->getMessageId();
	}
}