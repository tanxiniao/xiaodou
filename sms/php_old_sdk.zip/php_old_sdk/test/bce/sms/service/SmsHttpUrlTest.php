 <?php
/**
 * @file SmsHttpUrlTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../baidubce/services/sms/SmsClient.php');

use baidubce\sms\service\SmsHttpUrl;
use baidubce\sms\util\Constant;

class SmsHttpUrlTest extends PHPUnit_Framework_TestCase {
    public function setUp(){
    }
    public function tearDown(){}

    /**
     * 测试正常流程
     */
    public function testUrlResolve_Normal(){
    	$domain='baidu.com';
    	$protocol=Constant::SMS_HTTP_PROTOCOL_HTTP;
    	$uri='/' . SMS_API_VERSION . '/service';
    	$queryString='k1=v1&k2=v2';
    	$expect = $protocol . '://' . $domain . $uri . '?' . $queryString;
    	$res = SmsHttpUrl::urlResolve($domain, $protocol, $uri, $queryString);
    	$this->assertEquals($expect,$res);
    }
    
    /**
     * 测试domain带http前缀
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testUrlResolve_DomainWithHttpPrefix(){
    	$domain='http://baidu.com';
    	$protocol=Constant::SMS_HTTP_PROTOCOL_HTTP;
    	$uri='/v1/service';
    	$queryString='k1=v1&k2=v2';
    	$res = SmsHttpUrl::urlResolve($domain, $protocol, $uri, $queryString);
    }
    
    /**
     * 测试domain带https前缀
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testUrlResolve_DomainWithHttpsPrefix(){
    	$domain='https://baidu.com';
    	$protocol=Constant::SMS_HTTP_PROTOCOL_HTTP;
    	$uri='/v1/service';
    	$queryString='k1=v1&k2=v2';
    	$res = SmsHttpUrl::urlResolve($domain, $protocol, $uri, $queryString);
    }
    
    /**
     * 测试protocol为空
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testUrlResolve_ProtocolEmpty(){
    	$domain='baidu.com';
    	$protocol='';
    	$uri='/v1/service';
    	$queryString='k1=v1&k2=v2';
    	$res = SmsHttpUrl::urlResolve($domain, $protocol, $uri, $queryString);
    }
    
    /**
     * 测试protocol不存在
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testUrlResolve_ProtocolUnvalid(){
    	$domain='baidu.com';
    	$protocol='notExistProtocol';
    	$uri='/v1/service';
    	$queryString='k1=v1&k2=v2';
    	$res = SmsHttpUrl::urlResolve($domain, $protocol, $uri, $queryString);
    }
    
    /**
     * querystring为空
     */
    public function testUrlResolve_QueryStringEmpty(){
    	$domain='baidu.com';
    	$protocol=Constant::SMS_HTTP_PROTOCOL_HTTP;
    	$uri='/' . SMS_API_VERSION . '/service';
    	$queryString='';
    	$res = SmsHttpUrl::urlResolve($domain, $protocol, $uri, $queryString);
    	$expect = $protocol . '://' . $domain . $uri;
    	$this->assertEquals($expect,$res);
    }
    
    /**
     * uri为空
     */
    public function testUrlResolve_UriEmpty(){
    	$domain='baidu.com';
    	$protocol=Constant::SMS_HTTP_PROTOCOL_HTTP;
    	$uri='/v1';
    	$queryString='k1=v1&k2=v2';
    	$res = SmsHttpUrl::urlResolve($domain, $protocol, $uri, $queryString);
    	$expect = $protocol . '://' . $domain . '/' . SMS_API_VERSION . '?' . $queryString;
    	$this->assertEquals($expect,$res);
    }
    /**
     * 正常流程
     */
    public function testQueryStringResolve_Normal(){
    	$queryStringArray = array(
    			'k1' => 'v1',
    			'k2' => 'v2'
    	);
    	$res = SmsHttpUrl::queryStringResolve($queryStringArray);
    	$expect = 'k1=v1&k2=v2';
    	$this->assertEquals($expect,$res);
    }
    /**
     * queryString为空
     */
    public function testQueryStringResolve_Empty(){
    	$queryStringArray = array(
    	);
    	$res = SmsHttpUrl::queryStringResolve($queryStringArray);
    	$this->assertEmpty($res);
    }
    
    /**
     * queryString有value为空
     */
    public function testQueryStringResolve_ValueEmpty(){
    	$queryStringArray = array(
    			'k1' => '',
    			'k2' => 'v2'
    	);
    	$res = SmsHttpUrl::queryStringResolve($queryStringArray);
    	$expect = 'k1=&k2=v2';
    	$this->assertEquals($expect, $res);
    }
}
 