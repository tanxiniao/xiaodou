 <?php
/**
 * @file SmsBaseTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../baidubce/services/sms/SmsClient.php');

use baidubce\sms\util\SmsOptions;

class SmsBaseTest extends PHPUnit_Framework_TestCase {
    public function setUp(){
    }
    public function tearDown(){}
    
    /**
     * 测试基本配置是否存在
     */
    public function testConfig_Normal(){
    	$res = SmsOptions::getDefaultOptions(SmsOptions::SECURE_AK_KEY);
    	$this->assertNotEmpty($res);
    	$this->assertTrue(is_string($res), 'response must be a string.');
    }
    
    /**
     * 测试获取整个配置
     */
    public function testConfig_All(){
    	$res = SmsOptions::getDefaultOptions();
    	$this->assertNotEmpty($res);
    	$this->assertTrue(is_array($res), 'response must be an array.');
    }
    
}
 