 <?php
/**
 * @file AutoLoaderTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../baidubce/services/sms/util/AutoLoader.php');
require_once(__DIR__ . '/../../../../baidubce/services/sms/SmsConfig.php');

use baidubce\sms\util\SmsOptions;

class AutoLoaderTest extends PHPUnit_Framework_TestCase {
    public function setUp(){
    }
    public function tearDown(){}
    
    /**
     * 测试正常逻辑
     */
    public function test_AutoloaderNormal(){
    	$res = SmsOptions::getDefaultOptions();
    }
}
 