 <?php
/**
 * @file RegexUtilTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../baidubce/services/sms/SmsClient.php');

use baidubce\sms\util\RegexUtil;

class RegexUtilTest extends PHPUnit_Framework_TestCase {
    public function setUp(){
    }
    public function tearDown(){}
    
    /**
     * 测试正常逻辑
     */
    public function testCheckMobileNumber_Normal(){
    	$res = RegexUtil::checkMobileNumber('12345678901');
    	$this->assertTrue($res, 'mobile number count must be 11!');
    }
    
    /**
     * 测试为空
     */
    public function testCheckMobileNumber_Empty(){
    	$res = RegexUtil::checkMobileNumber('');
    	$this->assertFalse($res, 'mobile number can not be empty');
    }
    /**
     * 测试中间包含11个数字
     */
    public function testCheckMobileNumber_ContainNumber(){
    	$res = RegexUtil::checkMobileNumber('asd12345678901asd');
    	$this->assertFalse($res);
    }
    /**
     * 测试长度超长
     */
    public function testCheckMobileNumber_More(){
    	$res = RegexUtil::checkMobileNumber('123456789012');
    	$this->assertFalse($res);
    }
}
 