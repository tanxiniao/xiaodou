 <?php
/**
 * @file sms_system_test.php
 * @author wanglinqing01
 * @date 2014/10/13
 * @brief sms system test
 **/

require_once(__DIR__ . '/../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/BaseCase.php');

use baidubce\sms\SmsClient;

class SmsClientTest extends BaseCase {
    public function setUp(){
    	sleep(1);
    }
    
    public function tearDown(){
    	
    }
    
    /**
     * post message normal
     */
    public function test_msg_post_normal(){
    	//create tpl
    	$now = time();
    	$tplName = 'smstpl_sendmsg' . $now;    // template name can not be more than 32 characters in length
    	$tplId = $this->newTpl($tplName);
 
    	//approve tpl
    	$this->setTplStatus($tplId); 
		
		//send msg
		$client = SmsClient::getInstance();
		$receiverList = array('13000000000', '18811086572');
		$contentVarMap = array('TEMPLATE_NAME'=>$tplName, 'CURRENT_TIME'=>$now);
		$resp = $client->messageSend($tplId, $receiverList, $contentVarMap);
		echo "we send message to '" . implode(',', $receiverList) . "',\n";
		echo "    send count: " . $resp->getSendCount() . "\n";
		echo "    success count: " . $resp->getSuccessCount() . "\n";
		echo "    fail list: " . json_encode($resp->getFailList()) . "\n";
		$this->assertEquals('200',  $resp->getHttpStatusCode());
		$this->assertEquals(count($receiverList), $resp->getSuccessCount());
    	$this->assertEquals(count($receiverList), $resp->getSendCount());
    }
    
    public function test_msg_get_normal(){
    	//create tpl
    	$now = time();
    	$tplName = 'smstpl_getmsg' . $now;    // template name can not be more than 32 characters in length
    	$tplId = $this->newTpl($tplName);
 
    	//approve tpl
    	$this->setTplStatus($tplId); 
		
		//send msg
		$receiverList = array('18811086572');
		$contentVarMap = array('TEMPLATE_NAME'=>$tplName, 'CURRENT_TIME'=>$now);
		$msgId = $this->sendMsg($tplId, $receiverList, $contentVarMap);
    	
    	//get msginfo
    	$client = SmsClient::getInstance();
    	$resp = $client->messageInfo($msgId); 
    	$this->assertEquals($msgId, $resp->getMessageId());
    }
    
    public function test_tpl_post_normal(){
    	$client = SmsClient::getInstance();
    	$now = time();
    	$tplName = 'smstpl_post_' . $now;    // template name can not be more than 32 characters in length
		$tplContent = 'this is content for ${TEMPLATE_NAME}, now time is ${CURRENT_TIME}';  // the ${...} string will be replaced later
		$resp = $client->templateCreate($tplName, $tplContent);
		$tplId = $resp->getTemplateId();
		$this->assertEquals('200', $resp->getHttpStatusCode());
    	$this->assertNotEmpty($tplId);
		echo "we create a SMS template, the templateId=${tplId}.\n"; 
    }
    
    public function test_tpl_del_normal(){
    	//create tpl
    	$now = time();
    	$tplName = 'smstpl_del_' . $now;    // template name can not be more than 32 characters in length
    	$tplId = $this->newTpl($tplName);
    	
    	//del tpl
    	$client = SmsClient::getInstance();
    	$resp = $client->templateDelete($tplId);
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    }
    
    public function test_tpl_get_normal(){
    	//create tpl
    	$now = time();
    	$tplName = 'smstpl_get_' . $now;    // template name can not be more than 32 characters in length
    	$tplId = $this->newTpl($tplName);
    	
    	//get tpl
    	$client = SmsClient::getInstance();
    	$resp = $client->templateInfo($tplId);
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    	$this->assertNotNull($resp);
    	$tempInfo = $resp->getTemplateInfo();
    	$this->assertEquals($tplId, $tempInfo['templateId']);
		$this->assertEquals($tplName, $tempInfo['name']);
		$this->assertEquals('PROCESSING', $tempInfo['status']);
    }
    
    public function test_tpllist_get_normal(){
    	$client = SmsClient::getInstance();
    	$resp = $client->templateList();
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    	$tempInfo = $resp->getTemplateList();
    	$this->assertNotNull($tempInfo);
    }
    
    public function test_quota_get_normal(){
    	$client = SmsClient::getInstance();
    	$resp = $client->quotaInfo();
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    	$this->assertTrue(is_array($resp->getRawRetData()));    	
    }
    
    public function test_receiver_get_normal(){
    	$client = SmsClient::getInstance();
    	$phnoneNumber = '18811086572';
    	$resp = $client->receiverInfo($phnoneNumber);
    	$this->assertEquals(200, $resp->getHttpStatusCode());
		$receivedToday = $resp->getReceiveCountToday();
		
		//send msg
		//create tpl
    	$now = time();
    	$tplName = 'smstpl_getreceiver' . $now;
    	$tplId = $this->newTpl($tplName);
    	//approve tpl
    	$this->setTplStatus($tplId); 
		//send msg
		$receiverList = array('18811086572');
		$contentVarMap = array('TEMPLATE_NAME'=>$tplName, 'CURRENT_TIME'=>$now);
		$msgId = $this->sendMsg($tplId, $receiverList, $contentVarMap);
		
		//get receiver
		$receivedToday = $receivedToday + 1;
		$resp = $client->receiverInfo($phnoneNumber);
    	$this->assertEquals(200, $resp->getHttpStatusCode());
		$this->assertEquals($receivedToday, $resp->getReceiveCountToday());		
    }
}
 