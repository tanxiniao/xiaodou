use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceIllegalArgumentException.php');
use baidubce\sms\model\request\BlacklistPostCommand;

class BlacklistPostCommandTest extends PHPUnit_Framework_TestCase {
    public function setUp(){}
    public function tearDown(){}

    /**
     * add user to black list
     */
    public function testBlacklistPost_Normal(){
    	$command = new BlacklistPostCommand();
    	$command->setUserId(time());
    	$command->setTimeout(1000);
    	$response = $command->execute();
    	//断言状态码是200
    	$this->assertEquals(200, $response->getHttpStatusCode());
    }
    
    /**
     * empty timeout
     */
    public function testBlacklistPost_EmptyTimeout(){
    	$command = new BlacklistPostCommand();
    	$command->setUserId(time().'1');
    	$response = $command->execute();
    	//断言状态码是200
    	$this->assertEquals(200, $response->getHttpStatusCode());
    }
    
    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testBlacklistPost_TimeoutNotInt(){
    	$command = new BlacklistPostCommand();
    	$command->setUserId(time().'1');
    	//timeout is string
		$command->setTimeout('2000');
    	$response = $command->execute();
		
		$command->setUserId(time().'2');
    	//timeout is float
		$command->setTimeout(2000.1);
    	$response = $command->execute();
    }
    
    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testBlacklistPost_EmptyUid(){
    	$command = new BlacklistPostCommand();
    	$response = $command->execute();
    }
}