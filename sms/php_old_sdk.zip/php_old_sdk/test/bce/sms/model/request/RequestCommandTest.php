 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceRuntimeException.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceIllegalArgumentException.php');
use baidubce\sms\model\request\RequestCommand;
class RequestCommandTest extends PHPUnit_Framework_TestCase {
    public function setUp(){}
    public function tearDown(){}

    /**
     * test restful uri assemble
     */
    public function testGetRestfulUri_Normal(){
    	//value没有空格的情况
    	$mockClass = new MockClass('/message/{messageid}');
    	$mockClass->putRestParam('messageid', '1');
    	$restUri = $mockClass->getRestfulUri();
    	$expect = '/' . SMS_API_VERSION . '/message/1';
    	$this->assertEquals($expect, $restUri);
    }
    /**
     * test restful uri assemble, with space
     */
    public function testGetRestfulUri_WithSpace(){
    	//value没有空格的情况
    	$mockClass = new MockClass('/message/{  messageid }');
    	$mockClass->putRestParam('messageid', '1');
    	$restUri = $mockClass->getRestfulUri();
    	$expect = '/' . SMS_API_VERSION . '/message/1';
    	$this->assertEquals($expect, $restUri);
    }
    /**
     * test restful uri assemble, empty uri
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testGetRestfulUri_EmptyUri(){
    	//value没有空格的情况
    	$mockClass = new MockClass('  ');
    }
    
    /**
     * test restful uri assemble, null uri
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testGetRestfulUri_NullUri(){
    	//value没有空格的情况
    	$mockClass = new MockClass(null);
    }
    /**
     * test get command normal
     */
    public function testGetCommand_Normal(){
    	$cmd = RequestCommand::getCommand("mockClass");
    	$this->assertEquals('MockClass', get_class($cmd));
    }
    
    /**
     * test get command normal
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testGetCommand_NotExist(){
    	$cmd = RequestCommand::getCommand("notExistClassName");
    }
    
    /**
     * test get command normal
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testGetCommand_NotValidInstance(){
    	$cmd = RequestCommand::getCommand("RequestCommandTest");
    }
}

class MockClass extends RequestCommand{
	public function __construct($restfulUri='/'){
		parent::__construct($restfulUri);
	}
	
	protected function execute(array $options=null){}
}