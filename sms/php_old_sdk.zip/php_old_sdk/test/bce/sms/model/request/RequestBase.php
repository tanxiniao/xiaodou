<?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
use baidubce\sms\model\request\TplPostCommand;
use baidubce\sms\model\request\TplPutCommand;
use baidubce\sms\model\request\MsgPostCommand;

abstract class RequestBase extends PHPUnit_Framework_TestCase {
	protected static $VARIABLE_NAME_DEFAULT = 'variable';
	protected static $TPL_NAME_MAX_LEN = 32;
	private $tplIndex = 0;
	
	protected function getPhoneNumberRandom($suffix='0'){
		return strval(time()).$suffix;
	}
	
	protected function getTplNameRandom($prefix){
		$name = $prefix . time() . ($this->tplIndex++);
		$len = strlen($name);
		if($len > self::$TPL_NAME_MAX_LEN){
			$name = substr($name, $len-self::$TPL_NAME_MAX_LEN, self::$TPL_NAME_MAX_LEN);
		}
		return $name;
	}
	
    protected function newTpl($name, $content=''){
    	//first we create tpl here
    	$command = new TplPostCommand();
    	$command->setName($name);
    	if(empty($content)){
    		$content = 'this is tempalte content, add ${'. self::$VARIABLE_NAME_DEFAULT.'} here.';
    	}
    	$command->setContent($content);
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    	$this->assertNotEmpty($resp->getTemplateId());
    	return $resp->getTemplateId();
    }
    
    protected function setTplStatus($tplId, $status='VALID'){
    	//first we create tpl here
    	$command = new TplPutCommand();
    	$command->setTemplateId($tplId);
    	$command->setStatus($status);
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    }
    
    protected function sendMsg($tplId, array $receiver, array $contentVar){
		$msgPostObj = new MsgPostCommand();
		$msgPostObj->setTplId($tplId);
		foreach($receiver as $one){
			$msgPostObj->addReceiver($one);
		}
		foreach ($contentVar as $k=>$v){
			$msgPostObj->addContentVar($k, $v);
		}
		$resp = $msgPostObj->execute();
		$this->assertEquals(count($receiver), $resp->getSuccessCount());
		$this->assertEquals(count($receiver), $resp->getSendCount());
		return $resp->getMessageId();
	}
}