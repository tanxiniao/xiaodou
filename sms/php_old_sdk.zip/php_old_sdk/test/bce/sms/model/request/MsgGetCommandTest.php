use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/RequestBase.php');
use baidubce\sms\model\request\MsgGetCommand;
use baidubce\sms\model\request\QuotaPutCommand;

class MsgGetCommandTest extends RequestBase{
    public function setUp(){
		$command = new QuotaPutCommand();
    	$command->setReceiveQuota(10000);
    	$command->setSendQuota(20000);
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
	}
    public function tearDown(){}

    /**
     * test restful uri assemble
     */
    public function testMsgGet_Normal(){
    	//建立模板并审批
		$tplId = $this->newTpl(__CLASS__.time());
    	$this->setTplStatus($tplId, 'VALID');
    	
    	$msgId = $this->sendMsg($tplId, array($this->getPhoneNumberRandom('0'),$this->getPhoneNumberRandom('1')), array(self::$VARIABLE_NAME_DEFAULT=>'JDMall'));
    	//value没有空格的情况
    	$command = new MsgGetCommand();
    	$command->setMessageId($msgId);
    	$resp = $command->execute();
    	
    	$this->assertEquals($msgId, $resp->getMessageId());
    }
    
	/**
	 * msgId不存在，会返回异常
	 * @expectedException baidubce\exception\BceServiceException
	 */
	public function testMsgGet_msgIdNotExist(){
    	$msgId = time();
		$command = new MsgGetCommand();
    	$command->setMessageId($msgId);
    	$resp = $command->execute();
// 		//返回receiver数组为空
// 		echo count($resp->getReceiver());
//     	$this->assertEquals(0, count($resp->getReceiver()));
    }
	
    /**
     * test post with empty id
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testMsgPost_EmptyTplId(){
    	$command = new MsgGetCommand();
    	$resp = $command->execute();
    }
}