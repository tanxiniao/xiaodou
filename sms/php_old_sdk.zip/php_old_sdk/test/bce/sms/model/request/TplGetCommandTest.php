use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceIllegalArgumentException.php');
use baidubce\sms\model\request\TplGetCommand;
use baidubce\sms\model\request\TplPostCommand;
use baidubce\sms\model\request\TplPutCommand;

class TplGetCommandTest extends PHPUnit_Framework_TestCase {
    public function setUp(){
    }
    public function tearDown(){
    }

    /**
     * test get tpl
     */
    public function testTplGet_Normal(){
    	//first we create tpl here
    	$command0 = new TplPostCommand();
		$tplName = 'Tpl_'.time();
    	$command0->setName($tplName);
    	$command0->setContent('this is tempalte content, add ${variable} here.');
    	$resp0 = $command0->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp0->getHttpStatusCode());
    	$this->assertNotEmpty($resp0->getTemplateId());
    	$tplId = $resp0->getTemplateId();
    	
		//get tpl info
    	$command1 = new TplGetCommand();
    	$command1->setTemplateId($tplId);
    	$resp1 = $command1->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp1->getHttpStatusCode());
    	$tempInfo = $resp1->getTemplateInfo();
    	$this->assertNotNull($tempInfo);
    	$this->assertEquals($tplId, $tempInfo['templateId']);
		$this->assertEquals($tplName, $tempInfo['name']);
		$this->assertEquals('this is tempalte content, add ${variable} here.', $tempInfo['content']);
		$this->assertEquals('PROCESSING', $tempInfo['status']);
		
		//set tpl status valid
    	$command2 = new TplPutCommand();
    	$command2->setTemplateId($tplId);
    	$command2->setName($tplName);
    	$command2->setStatus('VALID');
    	$resp2 = $command2->execute();
    	$this->assertEquals('200', $resp2->getHttpStatusCode());
		//get tpl info
		$command1->setTemplateId($tplId);
    	$resp1 = $command1->execute();
    	$this->assertEquals('200', $resp1->getHttpStatusCode());
    	$tempInfo = $resp1->getTemplateInfo();
		$this->assertEquals('VALID', $tempInfo['status']);

		//set tpl status unvalid
		$command2->setStatus('UNVALID');
    	$resp2 = $command2->execute();
    	$this->assertEquals('200', $resp2->getHttpStatusCode());
		//get tpl info
		$command1->setTemplateId($tplId);
    	$resp1 = $command1->execute();
    	$this->assertEquals('200', $resp1->getHttpStatusCode());
    	$tempInfo = $resp1->getTemplateInfo();
		$this->assertEquals('UNVALID', $tempInfo['status']);
    }
    
    /**
     * test get tpl with empty id
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testTplGet_EmptyId(){
    	$command = new TplGetCommand();
    	$resp = $command->execute();
    }
	
	/**
     * test get tpl with unexist id
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testTplGet_IdNotExist(){
    	$command = new TplGetCommand();
		$tplId = time();
		$command->setTemplateId($tplId);
		$resp = $command->execute();
// 		$this->assertFalse(false,$resp->isOk());
// 		$this->assertEquals("no records in database",$resp->getErrorMessage());
    }
}