use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceIllegalArgumentException.php');
use baidubce\sms\model\request\UserBlacklistGetCommand;
use baidubce\sms\model\request\BlacklistPostCommand;

class UserBlacklistGetCommandTest extends PHPUnit_Framework_TestCase {
    public function setUp(){}
    public function tearDown(){}

    /**
	* 用户不在黑名单中
     */
    public function testUserBlacklistGet_notBlacklist_Normal(){
    	$command = new UserBlacklistGetCommand();
    	$uid = time();
		$command->setUserId($uid);
    	$response = $command->execute();
    	//断言状态码是200,用户不在黑名单中
    	$statusCode = $response->getHttpStatusCode();
    	$this->assertEquals(200, $statusCode);
    	$this->assertFalse($response->isInBlackList());
    }
	
	/**
	*用户在黑名单中
	*/
	public function testUserBlacklistGet_isBlacklist_Normal(){
		$command = new BlacklistPostCommand();
		$uid = time();
		$command->setUserId($uid);
    	$response = $command->execute();
		$this->assertEquals(200, $response->getHttpStatusCode());
		$command = new UserBlacklistGetCommand();
		$command->setUserId($uid);
		$response = $command->execute();
    	//断言状态码是200,用户在黑名单中
    	$statusCode = $response->getHttpStatusCode();
    	$this->assertEquals(200, $statusCode);
    	$this->assertTrue($response->isInBlackList());
    }
	
    
    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testUserBlacklistGet_EmptyUserId(){
    $command = new UserBlacklistGetCommand();
    $response = $command->execute();
    }
}