use baidubce\sms\model\request\ReceiverPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceIllegalArgumentException.php');
require_once(__DIR__ . '/RequestBase.php');
use baidubce\sms\model\request\ReceiverGetCommand;
use baidubce\sms\model\request\MsgPostCommand;
use baidubce\sms\model\request\QuotaPutCommand;

class ReceiverGetCommandTest extends RequestBase{
    public function setUp(){
		$command = new QuotaPutCommand();
    	$command->setReceiveQuota(10000);
    	$command->setSendQuota(20000);
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
	}
    public function tearDown(){}

    /**
     */
    public function testReceiverGet_Normal(){
    	//查询
		$phoneNum = $this->getPhoneNumberRandom();
		$command = new ReceiverGetCommand();
    	$command->setPhoneNumber($phoneNum);
    	$resp = $command->execute();
    	$this->assertEquals(200, $resp->getHttpStatusCode());
		$receivedToday = $resp->getReceiveCountToday();
		
		//发送短信
		$tplId = $this->newTpl(__CLASS__.time());
    	$this->setTplStatus($tplId, 'VALID');
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setTplId($tplId);
    	$msgPostObj->addReceiver($phoneNum);
    	$msgPostObj->addContentVar(self::$VARIABLE_NAME_DEFAULT, 'JDmall');
    	$resp = $msgPostObj->execute();
    	$this->assertEquals(1, $resp->getSuccessCount());
    	$this->assertEquals(1, $resp->getSendCount());
		
		//查询
    	$resp = $command->execute();
    	$this->assertEquals(200, $resp->getHttpStatusCode());
		$receivedToday = $receivedToday + 1;
		$this->assertEquals($receivedToday, $resp->getReceiveCountToday());
		
    }
    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testReceiverPost_EmptyPhoneNumber(){
    	$command = new ReceiverGetCommand();
    	$resp = $command->execute();
    }
    
    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testReceiverPost_NotNumber(){
    	$command = new ReceiverGetCommand();
    	$command->setPhoneNumber('asdf1234');
    	$resp = $command->execute();
    }
    
}