use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceIllegalArgumentException.php');
use baidubce\sms\model\request\TplPutCommand;
use baidubce\sms\model\request\TplPostCommand;
use baidubce\sms\model\request\TplGetCommand;

class TplPutCommandTest extends PHPUnit_Framework_TestCase {
    public function setUp(){}
    public function tearDown(){}

    /**
     * test modify tpl
     */
    public function testTplPut_Normal(){
    	$tplId = $this->newTpl();
    	$command0 = new TplPutCommand();
    	$command0->setTemplateId($tplId);
		$newName = __CLASS__.time().'1';
    	$command0->setName($newName);
    	$command0->setContent('this is a template');
    	$command0->setStatus('VALID');
    	$resp0 = $command0->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp0->getHttpStatusCode());
		
		//check data, get tpl info and compare
    	$command1 = new TplGetCommand();
    	$command1->setTemplateId($tplId);
    	$resp1 = $command1->execute();
    	$this->assertEquals('200', $resp1->getHttpStatusCode());
    	$tempInfo = $resp1->getTemplateInfo();
    	$this->assertNotNull($tempInfo);
    	$this->assertEquals($tplId, $tempInfo['templateId']);
		$this->assertEquals($newName, $tempInfo['name']);
		$this->assertEquals('this is a template', $tempInfo['content']);
		$this->assertEquals('VALID', $tempInfo['status']);
    }
	
	/**
     * test modify tpl, all param but tplId not exist
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testTplPut_allParamTplIdNotExist(){
    	$command0 = new TplPutCommand();
		$tplId = time();
		$command0->setTemplateId('smsTpl:'.$tplId);
		$newName = __CLASS__.time().'3';
    	$command0->setName($newName);
    	$command0->setContent('this is a template');
    	$command0->setStatus('VALID');
    	$resp0 = $command0->execute();
// 		//assert
// 		$this->assertFalse($resp0->isOk());
// 		$this->assertEquals("no records in database",$resp0->getErrorMessage());
    }
	
	/**
     * test modify tpl, all param but tplId not exist
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testTplPut_partParam_TplIdNotExist(){
    	$command0 = new TplPutCommand();
		$tplId = time();
		$command0->setTemplateId('smsTpl:'.$tplId);
		$command0->setContent('this is a template');
    	$resp0 = $command0->execute();
    	//assert
		$this->assertFalse($resp0->isOk());
		$this->assertEquals("no records in database",$resp0->getErrorMessage());
    }
	
	/**
     * test modify tpl, only TplId
	 * @expectedException baidubce\exception\BceServiceException
     */
    public function testTplPut_onlyTplId(){
    	$tplId = $this->newTpl();
    	$command0 = new TplPutCommand();
		$command0->setTemplateId('smsTpl:'.$tplId);
		$resp0 = $command0->execute();
    }
	
	/**
     * test modify tpl, part param
     */
    public function testTplPut_partParam(){
    	//part param,create tpl
		$command = new TplPostCommand();
		$command->setName(__CLASS__.time().'6');
		$command->setContent('this is template content, add ${variable} here.');
		$resp = $command->execute();
		//assert 200 ok
		$this->assertEquals('200', $resp->getHttpStatusCode());
		$this->assertNotEmpty($resp->getTemplateId());
		$tplId = $resp->getTemplateId();
		
		//update content
		$command0 = new TplPutCommand();
    	$command0->setContent('this is a template');
		$command0->setTemplateId($tplId);
		$resp0 = $command0->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp0->getHttpStatusCode());
		
		//check data, get tpl info and compare
    	$command1 = new TplGetCommand();
    	$command1->setTemplateId($tplId);
    	$resp1 = $command1->execute();
    	$this->assertEquals('200', $resp1->getHttpStatusCode());
    	$tempInfo = $resp1->getTemplateInfo();
    	$this->assertNotNull($tempInfo);
    	$this->assertEquals($tplId, $tempInfo['templateId']);
		$this->assertEquals('this is a template', $tempInfo['content']);
		$this->assertEquals('PROCESSING', $tempInfo['status']);
	
    }
	
	/**
     * test modify tpl, part param and name duplicate
	 * @expectedException baidubce\exception\BceServiceException
     */
    public function testTplPut_partParam_nameDuplicate(){
    	//part param,create tpl
		$command = new TplPostCommand();
		$tplName = __CLASS__.time().'7';
		$command->setName($tplName);
		$command->setContent('this is template1 content.');
		$resp = $command->execute();
		$this->assertEquals('200', $resp->getHttpStatusCode());
		$this->assertNotEmpty($resp->getTemplateId());
		$tplId = $resp->getTemplateId();
		
		//create another tpl
		$tplName0 = __CLASS__.time().'8';
		$command->setName($tplName0);
		$command->setContent('this is template2 content.');
		$resp0 = $command->execute();
		$this->assertEquals('200', $resp0->getHttpStatusCode());
		$this->assertNotEmpty($resp0->getTemplateId());
		$tplId = $resp0->getTemplateId();
		
		//update name
		$command1 = new TplPutCommand();
		$command1->setTemplateId($tplId);
    	$command1->setName($tplName);
		$resp1 = $command1->execute();		
    }
	
    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testTplPut_EmptyTplId(){
    	$command = new TplPutCommand();
    	$command->execute();
    }
    
    private function newTpl(){
		//first we create tpl here
		$command = new TplPostCommand();
		$command->setName(__CLASS__.time());
		$command->setContent('this is template content, add ${variable} here.');
		$resp = $command->execute();
		//assert 200 ok
		$this->assertEquals('200', $resp->getHttpStatusCode());
		$this->assertNotEmpty($resp->getTemplateId());
		return $resp->getTemplateId();
	}
}