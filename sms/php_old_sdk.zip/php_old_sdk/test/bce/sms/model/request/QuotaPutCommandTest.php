use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceIllegalArgumentException.php');
use baidubce\sms\model\request\QuotaPutCommand;
use baidubce\sms\model\request\QuotaGetCommand;

class QuotaPutCommandTest extends PHPUnit_Framework_TestCase {
    public function setUp(){}
    public function tearDown(){}

    /**
     * test modify quota
     */
    public function testQuotaPut_Normal(){
    	$command = new QuotaPutCommand();
    	$command->setReceiveQuota(10000);
    	$command->setSendQuota(20000);
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
		
		$command = new QuotaGetCommand();
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
		$this->assertEquals(10000,$resp->getReceiveQuota());
		$this->assertEquals(20000,$resp->getSendQuota());
    }
	
	/**
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testQuotaPut_NoParam(){
    	$command = new QuotaPutCommand();
    	$resp = $command->execute();
		//var_dump($resp->isOk());
		$this->assertFalse($resp->isOk());
		$this->assertEquals("no parameters, program takes at lease one parameter",$resp->getErrorMessage());
    }
	
    /**
     * set sendQuota
     */
    public function testQuotaPut_EmptyReceive(){
    	//查询初始配额
		$command0 = new QuotaGetCommand();
    	$resp0 = $command0->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp0->getHttpStatusCode());
		//$orgSendQuota = $resp0->getSendQuota();
		$orgReceiveQuota = $resp0->getReceiveQuota();
		
		//set send quota
		$command1 = new QuotaPutCommand();
    	$command1->setSendQuota(20);
    	$resp1 = $command1->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp1->getHttpStatusCode());
		
		//check data
		$resp0 = $command0->execute();
    	$this->assertEquals('200', $resp0->getHttpStatusCode());
		$this->assertEquals(20,$resp0->getSendQuota());
		$this->assertEquals($orgReceiveQuota,$resp0->getReceiveQuota());		
    }
    /**
	 *set reveive quota 
     */
    public function testQuotaPut_EmptySend(){
    	//查询初始配额
		$command0 = new QuotaGetCommand();
    	$resp0 = $command0->execute();
    	$this->assertEquals('200', $resp0->getHttpStatusCode());
		$orgSendQuota = $resp0->getSendQuota();
		//$orgReceiveQuota = $resp0->getReceiveQuota();
		
		$command1 = new QuotaPutCommand();
    	$command1->setReceiveQuota(10);
    	$resp1 = $command1->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp1->getHttpStatusCode());
		
		//check data
		$resp0 = $command0->execute();
    	$this->assertEquals('200', $resp0->getHttpStatusCode());
		$this->assertEquals($orgSendQuota,$resp0->getSendQuota());
		$this->assertEquals(10,$resp0->getReceiveQuota());
    }
    
    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testQuotaPut_NotNumber(){
    	$command = new QuotaPutCommand();
    	$command->setReceiveQuota('100');
    	$command->setSendQuota('200');
    	$resp = $command->execute();
    }
}