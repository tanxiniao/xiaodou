use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
use baidubce\sms\model\request\TplGetListCommand;

class TplGetListCommandTest extends PHPUnit_Framework_TestCase {
    public function setUp(){
    }
    public function tearDown(){
    }

    /**
     * test get tpl
     */
    public function testTplGetList_Normal(){
    	$command = new TplGetListCommand();
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    	$tempInfo = $resp->getTemplateList();
    	$this->assertNotNull($tempInfo);
    }
}