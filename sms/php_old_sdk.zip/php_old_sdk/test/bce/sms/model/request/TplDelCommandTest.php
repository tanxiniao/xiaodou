use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
use baidubce\sms\model\request\TplDelCommand;
use baidubce\sms\model\request\TplPostCommand;

class TplDelCommandTest extends PHPUnit_Framework_TestCase {
    public function setUp(){
    }
    public function tearDown(){}

    /**
     * test delete tpl
     */
    public function testTplDel_Normal(){
    	$tplId = $this->newTpl();
    	$command = new TplDelCommand();
		$command->setTemplateId($tplId);
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    }
    
    private function newTpl(){
    	//first we create tpl here
    	$command = new TplPostCommand();
    	$command->setName(__CLASS__.time());
    	$command->setContent('this is tempalte content, add ${variable} here.');
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    	$this->assertNotEmpty($resp->getTemplateId());
    	return $resp->getTemplateId();
    }
    
    /**
     * test delete tpl
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testTplDel_NoTplId(){
    	$command = new TplDelCommand();
    	$command->setTemplateId('notexistid');
    	$resp = $command->execute();
    	//assert 400 ok
    	$this->assertEquals('400', $resp->getHttpStatusCode());
		$this->assertEquals('template does not exist', $resp->getErrorMessage());
    }
	
	/**
     * test get tpl with empty id
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testTplDel_EmptyId(){
    	$command = new TplDelCommand();
    	$resp = $command->execute();
    }
}