use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceIllegalArgumentException.php');
use baidubce\sms\model\request\TplPostCommand;

class TplPostCommandTest extends PHPUnit_Framework_TestCase {
    public function setUp(){}
    public function tearDown(){}

    /**
     * test create tpl
     */
    public function testTplPost_Normal(){
    	$tplPostObj = new TplPostCommand();
    	$tplPostObj->setName('TemplateName'.time());
    	$tplPostObj->setContent('this is tempalte content, add ${variable} here.');
    	$resp = $tplPostObj->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    	$this->assertNotEmpty($resp->getTemplateId());
		var_dump($resp->getTemplateId());
    }
	
	/**
     * test create tpl,tplName duplicate
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testTplPost_tplNameDuplic(){
    	$tplPostObj = new TplPostCommand();
		$tplName = 'TplName'.time();
    	$tplPostObj->setName($tplName);
    	$tplPostObj->setContent('this is tempalte content, add ${variable} here.');
    	$resp = $tplPostObj->execute();
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    	$this->assertNotEmpty($resp->getTemplateId());
		//create another tpl with the same tplName
		$tplPostObj->setContent('this is another tempalte with the same tplName.');
    	$resp = $tplPostObj->execute();
//     	$this->assertEquals('400', $resp->getHttpStatusCode());
//     	$this->assertNotEmpty('template name exists', $resp->getErrorMessage());
    }
	
	/**
     * test create tpl,tplName is too long 
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testTplPost_tplNameTooLong(){
    	$tplPostObj = new TplPostCommand();
		$tplName = 'TplNameTplNameTplNameTplNameTplName';
    	$tplPostObj->setName($tplName);
    	$tplPostObj->setContent('this is tempalte content, add ${variable} here.');
    	$resp = $tplPostObj->execute();
    	$this->assertEquals('400', $resp->getHttpStatusCode());
    	$this->assertNotEmpty('parameter validate error: the length of smsTplName=TplNameTplNameTplNameTplNameTplName is longer than 32', $resp->getErrorMessage());
    }
	
	/**
     * test create tpl,tplContent is too long 
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testTplPost_tplContentTooLong(){
    	$tplPostObj = new TplPostCommand();
    	$tplPostObj->setName('TplName'.time().'1');
		$tplContent = 'This is a Tpl,This is a Tpl,This is a Tpl,This is a Tpl,This is a Tpl,This is a Tpl';
    	$tplPostObj->setContent($tplContent);
    	$resp = $tplPostObj->execute();
    	$this->assertEquals('400', $resp->getHttpStatusCode());
    	$this->assertNotEmpty('parameter validate error: the length of smsTplContent=This is a Tpl,This is a Tpl,This is a Tpl,This is a Tpl,This is a Tpl,This is a Tpl is longer than 70', $resp->getErrorMessage());
    }
	
	/**
     * test param error type, but sdk transfer it to str 
     */
    public function testTplPost_errorType(){
    	$tplPostObj = new TplPostCommand();
    	$tplPostObj->setName(time());
    	$tplPostObj->setContent(time()+1);
    	$resp = $tplPostObj->execute();
		$this->assertEquals('200', $resp->getHttpStatusCode());
    }
	
	/**
     * test miss name
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testTplPost_missName(){
    	$tplPostObj = new TplPostCommand();
    	$tplPostObj->setContent('this is tempalte content, add ${variable} here.');
    	$resp = $tplPostObj->execute();
    }
	
	/**
     * test miss content
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testTplPost_missContent(){
    	$tplPostObj = new TplPostCommand();
    	$tplPostObj->setName('TemplateName'.time());
    	$resp = $tplPostObj->execute();
    }
	
    /**
     * test empty name
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testTplPost_NameEmpty(){
    	$tplPostObj = new TplPostCommand();
    	$tplPostObj->setName('');
    	$tplPostObj->setContent('this is tempalte content, add ${variable} here.');
    	$resp = $tplPostObj->execute();
    }
    
    /**
     * test empty content
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testTplPost_ContentEmpty(){
    	$tplPostObj = new TplPostCommand();
    	$tplPostObj->setName('TemplateName'.time());
    	$tplPostObj->setContent('');
    	$resp = $tplPostObj->execute();
    }
	
	/**
     * test empty param
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testTplPost_allParamEmpty(){
    	$tplPostObj = new TplPostCommand();
    	$tplPostObj->setName('');
    	$tplPostObj->setContent('');
    	$resp = $tplPostObj->execute();
    }
	
	/**
     * test empty param
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testTplPost_allParamNull(){
    	$tplPostObj = new TplPostCommand();
    	//$tplPostObj->setName(null);
    	//$tplPostObj->setContent(null);
    	$resp = $tplPostObj->execute();
    }
}