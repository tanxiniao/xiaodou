<?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceRuntimeException.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceIllegalArgumentException.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceServiceException.php');
use baidubce\sms\model\request\BlacklistGetCommand;
use baidubce\sms\model\request\BlacklistPostCommand;
use baidubce\sms\util\SmsOptions;

class BlacklistGetCommandTest extends PHPUnit_Framework_TestCase {
    public function setUp(){}
    public function tearDown(){}

    /**
     * 获取黑名单信息
     */
    public function testBlacklistGet_Normal(){
    	$blacklistPostObj = new BlacklistGetCommand();
    	$response = $blacklistPostObj->execute();
    	//断言状态码是200
    	$statusCode = $response->getHttpStatusCode();
    	$this->assertEquals(200, $statusCode);
    	$this->assertTrue(is_array($response->getBlacklist()));
    }
	
	public function testBlacklistGet_ErrParam(){
    	//add blacklist
		$command = new BlacklistPostCommand();
		$uid = time();
    	$userId = $command->setUserId($uid);
		$response = $command->execute();
    	//断言状态码是200
    	$this->assertEquals(200, $response->getHttpStatusCode());
		
		$blacklistPostObj = new BlacklistGetCommand();
    	$response = $blacklistPostObj->execute($userId);
    	//断言状态码是200,sdk不生效
    	$statusCode = $response->getHttpStatusCode();
		$this->assertEquals(200, $statusCode);
    }
    
    /**
     * 权限错误，会直接抛出BceServiceException
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testBlacklistGet_AuthFail(){
    	$options = SmsOptions::getDefaultOptions();
    	$options[SmsOptions::SECURE_AK_KEY] = 'notValidAk';
    	$options[SmsOptions::SECURE_SK_KEY] = 'notValidSk';
    	$blacklistPostObj = new BlacklistGetCommand();
    	$response = $blacklistPostObj->execute($options);
//     	//断言状态码是200
//     	$statusCode = $response->getHttpStatusCode();
//     	$this->assertEquals(401, $statusCode);
//     	$this->assertNotEmpty($response->getErrorCode());
//     	$this->assertNotEmpty($response->getErrorMessage());
//     	$this->assertNotEmpty($response->getRequestId());
    }
    
    /**
     * AK/SK为空时抛出异常
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testBlacklistGet_EmptyAkSk(){
    	$options = SmsOptions::getDefaultOptions();
    	$options[SmsOptions::SECURE_AK_KEY] = '';
    	$options[SmsOptions::SECURE_SK_KEY] = '';
    	$blacklistPostObj = new BlacklistGetCommand();
    	$response = $blacklistPostObj->execute($options);
    }
    
    /**
     * HOST为空时抛出异常
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testBlacklistGet_EmptyHost(){
    	$options = SmsOptions::getDefaultOptions();
    	$options[SmsOptions::HTTP_DOMAIN_HOST_KEY] = '';
    	$blacklistPostObj = new BlacklistGetCommand();
    	$response = $blacklistPostObj->execute($options);
    }
}