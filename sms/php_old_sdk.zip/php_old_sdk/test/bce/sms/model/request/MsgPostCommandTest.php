use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
require_once(__DIR__ . '/../../../../../baidubce/exception/BceIllegalArgumentException.php');
require_once(__DIR__ . '/RequestBase.php');
use baidubce\sms\model\request\MsgPostCommand;
use baidubce\sms\model\request\QuotaPutCommand;

class MsgPostCommandTest extends RequestBase{
    public function setUp(){
    }
    public function tearDown(){}

    /**
     * test restful uri assemble, single receiver
     */
    public function testMsgPost_Normal(){
    	//create tpl and approve
		$tplId = $this->newTpl(__FUNCTION__.time());
    	$this->setTplStatus($tplId, 'VALID');
    	
		//value没有空格的情况
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setTplId($tplId);
    	$msgPostObj->addReceiver(time().'5');
    	$msgPostObj->addContentVar(self::$VARIABLE_NAME_DEFAULT, 'JDmall');
    	$resp = $msgPostObj->execute();
		$this->assertEquals('200', $resp->getHttpStatusCode());
    	$this->assertEquals(1, $resp->getSuccessCount());
    	$this->assertEquals(1, $resp->getSendCount());
    }
    
    /**
     * test restful uri assemble, receiver list
     */
    public function testMsgPost_ReceiverListNormal(){
    	$receiverList = array(
    			$this->getPhoneNumberRandom('0'),
    			$this->getPhoneNumberRandom('1'),
    			$this->getPhoneNumberRandom('2')
    	);
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setReceiver($receiverList);
    	$resReceivers = $msgPostObj->getReceiver();
    	$this->assertTrue(is_array($resReceivers));
    	$this->assertEquals(3, count($resReceivers));
		
		//create tpl and approve
		$tplId = $this->newTpl($this->getTplNameRandom(__FUNCTION__));
    	$this->setTplStatus($tplId, 'VALID');
    	
		//check actual sendcount
    	$msgPostObj1 = new MsgPostCommand();
    	$msgPostObj1->setTplId($tplId);
    	$msgPostObj1->addContentVar(self::$VARIABLE_NAME_DEFAULT, 'JDmall');
		$msgPostObj1->setReceiver($receiverList);  
    	$resp1 = $msgPostObj1->execute();
		$this->assertEquals('200', $resp1->getHttpStatusCode());
    	$this->assertEquals(3, $resp1->getSuccessCount());
    	$this->assertEquals(3, $resp1->getSendCount());
    }
	
    /**
     * test restful uri assemble, receiver duplicate
     */
    public function testMsgPost_ReceiverListDuplicate(){
    	//receiver duplicate
    	$ph1 = $this->getPhoneNumberRandom('3');
    	$ph2 = $this->getPhoneNumberRandom('4');
		$receiverList = array(
    			$ph1,
    			$ph1,
    			$ph2
    	);
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setReceiver($receiverList);
    	$resReceivers = $msgPostObj->getReceiver();
    	$this->assertTrue(is_array($resReceivers));
    	$this->assertEquals(2, count($resReceivers));
		
		//create tpl and approve
		$tplId = $this->newTpl($this->getTplNameRandom(__FUNCTION__));
    	$this->setTplStatus($tplId, 'VALID');
    	
		//check actual sendcount
    	$msgPostObj1 = new MsgPostCommand();
    	$msgPostObj1->setTplId($tplId);
    	$msgPostObj1->addContentVar(self::$VARIABLE_NAME_DEFAULT, 'JDmall');
		$msgPostObj1->setReceiver($receiverList);  
    	$resp1 = $msgPostObj1->execute();
		$this->assertEquals('200', $resp1->getHttpStatusCode());
    	$this->assertEquals(2, $resp1->getSuccessCount());
    	$this->assertEquals(2, $resp1->getSendCount());
    }
    
    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testMsgPost_ReceiverListHaveUnvalid(){
    	//create tpl and approve
		$tplId = $this->newTpl($this->getTplNameRandom(__FUNCTION__));
    	$this->setTplStatus($tplId, 'VALID');
		
		$receiverList = array(
    			'13000000000',
    			'13000000000',
    			'asdf'
    	);
    	$msgPostObj = new MsgPostCommand();
		$msgPostObj->setTplId($tplId);
    	$msgPostObj->addContentVar(self::$VARIABLE_NAME_DEFAULT, 'JDmall');
    	$msgPostObj->setReceiver($receiverList);
		$msgPostObj->execute();    	
    }
    
    /**
	 * empty receiverList 
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testMsgPost_ReceiverListEmpty(){
    	$receiverList = array(
    	);
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setReceiver($receiverList);
    }
    
	/**
	 * empty receiverList null 
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testMsgPost_ReceiverListNull(){
    	//create tpl and approve
		$tplId = $this->newTpl($this->getTplNameRandom(__FUNCTION__));
    	$this->setTplStatus($tplId, 'VALID');
		//send msg
    	$msgPostObj = new MsgPostCommand();
		$msgPostObj->setTplId($tplId);
    	$msgPostObj->addContentVar(self::$VARIABLE_NAME_DEFAULT, 'JDmall');
		$msgPostObj->execute();
    }
	
    /**
	 * content param more then 1
     */
    public function testMsgPost_ContentVarNormal(){
    	$contentVarMap = array(
    			'k1' => 'v1',
    			'k2' => 'v2',
    			'k3' => 'v3'
    	);
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setContentVar($contentVarMap);
    	$resContentVar = $msgPostObj->getContentVar();
    	$this->assertTrue(is_array($resContentVar));
    	$this->assertEquals(3, count($resContentVar));
    }
	
    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testMsgPost_ContentVarEmpty(){
    	$contentVarMap = array();
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setContentVar($contentVarMap);
    }
    
    /**
	 * content unvalid
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testMsgPost_ContentVarHaveUnvalid(){
    	$contentVarMap = array(
    			'k1' => 'v1',
    			'k2' => 'v2',
    			'k3' => ''
    	);
    	$msgPostObj = new MsgPostCommand();
		$msgPostObj->setTplId('asdf');
		$msgPostObj->addReceiver('13688016572');
    	$resp = $msgPostObj->setContentVar($contentVarMap);
    	$this->assertFalse($resp->isOk());
		$this->assertEquals("both contentVar's key and value can not be empty!",$resp->getErrorMessage());
		
    }
    
    /**
     * test post with empty id
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testMsgPost_EmptyTplId(){
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->addReceiver('13000010000');
    	$msgPostObj->addContentVar(self::$VARIABLE_NAME_DEFAULT, 'JDmall');
    	$msgPostObj->execute();
    }
    
    /**
     * test post with empty receiver
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testMsgPost_EmptyReceiver(){
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setTplId('asdf');
    	$msgPostObj->addContentVar(self::$VARIABLE_NAME_DEFAULT, 'JDmall');
    	$msgPostObj->execute();
    }
    
    /**
     * test post with empty content
     * @expectedException baidubce\exception\BceIllegalArgumentException
     */
    public function testMsgPost_EmptyContentVar(){
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setTplId('asdf');
    	$msgPostObj->addReceiver('13000000000');
    	$msgPostObj->execute();
    }
	
	/**
	 * @expectedException baidubce\exception\BceServiceException
	*/
	public function testMsgPost_unvalidTpl(){
    	//create tpl and approve
		$tplId = $this->newTpl(__FUNCTION__.time());
    	//$this->setTplStatus($tplId, 'VALID');
    	
		$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setTplId($tplId);
    	$msgPostObj->addReceiver('13100000000');
    	$msgPostObj->addContentVar(self::$VARIABLE_NAME_DEFAULT, 'JDmall');
    	$resp = $msgPostObj->execute();
// 		$this->assertEquals('400', $resp->getHttpStatusCode());
//     	$this->assertEquals("template is deleted or in process",$resp->getErrorMessage());
	}
	
	/**
	 * @expectedException baidubce\exception\BceServiceException
	*/
	public function testMsgPost_paramNumLessThenNeed(){
		//create tpl and approve
		$cont = 'this is tempalte content, 您在${APP}申请的验证码为${VID}.';
		$tplId = $this->newTpl(__FUNCTION__.time(),$cont);
    	$tplId = 'smsTpl:9aabe01332a74874aea21d448225e0e8';
		$this->setTplStatus($tplId, 'VALID');
		
		//send msg
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setTplId($tplId);
    	$msgPostObj->addReceiver('13716953216');
		$contentVarMap = array(
    			'APP' => 'JDmall'
    	);		
    	$msgPostObj->setContentVar($contentVarMap);
    	$resp = $msgPostObj->execute();
		var_dump($resp->isOk());
		//$this->assertEquals('200', $resp->getHttpStatusCode());
    	//$this->assertEquals(1, $resp->getSuccessCount());
    	//$this->assertEquals(1, $resp->getSendCount());

	}
	
	/**
	 * @expectedException baidubce\exception\BceServiceException
	*/
	public function testMsgPost_paramNumMoreThenNeed(){
		//create tpl and approve
		$cont = 'this is tempalte content, 您在${APP}申请的验证码为${VID}.';
		$tplId = $this->newTpl(__FUNCTION__.time(),$cont);
		$this->setTplStatus($tplId, 'VALID');
		
		//send msg
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setTplId($tplId);
    	$msgPostObj->addReceiver('13716953210');
		$contentVarMap = array(
    			'APP' => 'JDmall',
				'VID' => '123456',
				'key3' => 'v3'
    	);		
    	$msgPostObj->setContentVar($contentVarMap);
    	$resp = $msgPostObj->execute();
		var_dump($resp->isOk());
		$this->assertEquals('200', $resp->getHttpStatusCode());
    	$this->assertEquals(1, $resp->getSuccessCount());
    	$this->assertEquals(1, $resp->getSendCount());
	}
	
	/**
	 *receiver quota exceed
	 *@expectedException baidubce\exception\BceServiceException
	*/
	public function testMsgPost_receiverQuotaExceed(){
		//set Quota
		$command = new QuotaPutCommand();
    	$command->setReceiveQuota(2);
    	$command->setSendQuota(20000);
    	$resp = $command->execute();
    	$this->assertEquals('200', $resp->getHttpStatusCode());
		
		//create tpl and approve
		$cont = 'this is tempalte content, 您在${APP}申请的验证码为${VID}.';
		$tplId = $this->newTpl(__CLASS__.time(),$cont);
		$this->setTplStatus($tplId, 'VALID');
		
		//send msg
    	$msgPostObj = new MsgPostCommand();
    	$msgPostObj->setTplId($tplId);
    	$contentVarMap = array(
    			'APP' => 'JDmall',
				'VID' => '123456'
    	);		
    	$msgPostObj->setContentVar($contentVarMap);
		$phoneNum = $this->getPhoneNumberRandom('0');
		$msgPostObj->addReceiver($phoneNum);
		$resp = $msgPostObj->execute();
		$receiverList = array(
    			$phoneNum,
    			$phoneNum
    	);
		$msgPostObj->setReceiver($receiverList);
    	$resp = $msgPostObj->execute();
		$this->assertEquals('200', $resp->getHttpStatusCode()); //receiver quota
		$msgPostObj->addReceiver($phoneNum);
		$resp = $msgPostObj->execute();
		/*var_dump($resp->isOk());
		$this->assertEquals('400', $resp->getHttpStatusCode());
    	$this->assertEquals("all quota of phonenum limited.",$resp->getErrorMessage());
		
		//recover receive quota
    	$command->setReceiveQuota(1000);
    	$command->setSendQuota(20000);
    	$resp = $command->execute();
    	$this->assertEquals('200', $resp->getHttpStatusCode());*/
	}
}