use baidubce\sms\model\request\MsgPostCommand;
 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../../../baidubce/services/sms/SmsClient.php');
use baidubce\sms\model\request\QuotaGetCommand;
use baidubce\sms\model\request\QuotaPutCommand;

class QuotaGetCommandTest extends PHPUnit_Framework_TestCase {
    public function setUp(){}
    public function tearDown(){}

    /**
     * test get quota
     */
    public function testQuotaGet_Normal(){
    	$command = new QuotaGetCommand();
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
    	$this->assertTrue(is_array($resp->getRawRetData()));
    }
	
	public function testQuotaGet_Set_Normal(){
		//set quota
		$command = new QuotaPutCommand();
    	$command->setReceiveQuota(10);
    	$command->setSendQuota(2000);
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
		
		//get quota
		$command = new QuotaGetCommand();
    	$resp = $command->execute();
    	//assert 200 ok
    	$this->assertEquals('200', $resp->getHttpStatusCode());
		$this->assertEquals(10,$resp->getReceiveQuota());
		$this->assertEquals(2000,$resp->getSendQuota());
		
	}
}