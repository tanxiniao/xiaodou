 <?php
/**
 * @file SmsBaseTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../baidubce/services/sms/SmsClient.php');

use baidubce\sms\SmsClient;
use baidubce\sms\util\SmsOptions;

class SmsClientTest extends PHPUnit_Framework_TestCase {
    public function setUp(){
    }
    public function tearDown(){}
    
    /**
     */
    public function testClient_Normal(){
    	$client = SmsClient::getInstance();
    	$this->assertTrue($client instanceof SmsClient);
    }
    
    /**
     */
    public function testClient_SingleInstanceSame(){
    	$config = SmsClient::config();
	    $client_default_1 = SmsClient::getInstance($config);
	    $client_default_2 = SmsClient::getInstance($config);
	    $this->assertTrue($client_default_1 === $client_default_2);
    }
    
    /**
     */
    public function testClient_SingleInstanceNotSame(){
    $config = SmsClient::config();
    $client_default_1 = SmsClient::getInstance($config);
    $config[SmsOptions::SECURE_AK_KEY] = 'asdf';
    $client_default_2 = SmsClient::getInstance($config);
    $this->assertTrue($client_default_1 !== $client_default_2);
    }

}
 