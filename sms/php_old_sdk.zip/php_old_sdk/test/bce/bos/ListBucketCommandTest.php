<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-5
 * Time: 下午2:38
 */

define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/request/ListBuckets.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";

require_once __DIR__ . "/TestHelper.php";

use \ baidubce\bos\model\request\ListBuckets;
class ListBucketCommandTest extends PHPUnit_Framework_TestCase {
    private $list_bucket_command;

    public function setUp(){
        $this->list_bucket_command = new ListBuckets("ListBuckets");
    }
    public function tearDown(){}

    public function testGetRequest(){
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";

        $this->assertTrue(TestHelper::callFunction($this->list_bucket_command, "checkOptions", array($client_options, $options)));

        $request = TestHelper::callFunction($this->list_bucket_command, "getRequest", array($client_options, $options));
        $this->assertNotNull($request);

        $this->assertEquals("127.0.0.1:8080", $request->getHost());

        $this->assertEquals(\baidubce\http\HttpMethod::HTTP_GET, $request->getHttpMethod());
    }

}
 
