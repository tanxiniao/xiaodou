<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-15
 * Time: 下午2:32
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/PutObjectResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";

use baidubce\bos\model\response\PutObjectResponse;
class PutObjectResponseTest extends PHPUnit_Framework_TestCase {
    private $put_object_response;

    public function setUp(){
        $this->put_object_response = new PutObjectResponse("PutObjectResponse");
    }
    public function tearDown(){}

    public function testParseResponse(){
        $random = "";
        $raw_header = 'HTTP/1.1 200 OK';
        $response = TestHelper::callFunction($this->put_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $raw_header = 'ETag:1b2cf535f27731c974343645a3985328';
        $response = TestHelper::callFunction($this->put_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $raw_header = 'x-bce-request-id:0A49CE4060975EAC';
        $response = TestHelper::callFunction($this->put_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $result = TestHelper::callFunction($this->put_object_response, "parseResponse", array());
        $this->assertNull($result);

        $this->assertEquals("1b2cf535f27731c974343645a3985328",$this->put_object_response->getETag());
    }

}
 
