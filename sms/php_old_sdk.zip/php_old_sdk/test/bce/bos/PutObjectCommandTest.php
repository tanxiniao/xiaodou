<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-2
 * Time: 下午2:10
 */

define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/request/PutObject.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";

require_once __DIR__ . "/TestHelper.php";

use baidubce\bos\model\request\PutObject;

class PutObjectCommandTest extends PHPUnit_Framework_TestCase {
    private $put_object_command;

    public function setUp(){
        $this->put_object_command = new PutObject("PutObject");
    }
    public function tearDown(){}

    public function testCheckOptionsOk(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";

        $options[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] ="test-content";
        $options[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STREAM] = "";


        $this->assertTrue(TestHelper::callFunction($this->put_object_command, "checkOptions", array($client_options, $options)));
        $this->assertEquals("test-bucket", TestHelper::getAttribute($this->put_object_command, "bucket_name"));
        $this->assertEquals("test_object", TestHelper::getAttribute($this->put_object_command, "object_name"));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name not exist in object request
     */
    public function testCheckOptionsBucketNameNotSet(){
        $client_options = array();
        $options = array();

        TestHelper::callFunction($this->put_object_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name Illegal
     */
    public function testCheckOptionsBucketNameIllegal(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
        TestHelper::callFunction($this->put_object_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage object name not exist in object request
     */
    public function testCheckOptionsObjectNameNotSet(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test_bucket";
        TestHelper::callFunction($this->put_object_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage object name name Illegal
     */
    public function testCheckOptionsObjectNameIllegal(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "";
        TestHelper::callFunction($this->put_object_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage no object content input object
     */
    public function testCheckOptionsObjectContentStringAndObjectContentStreamNotSet(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
        $options["range"] = "bytes=0-100";

        TestHelper::callFunction($this->put_object_command, "checkOptions", array($client_options, $options));
    }

    public function testNeedHeaderIncludeInRequest() {
        $this->assertTrue(TestHelper::callFunction($this->put_object_command, "needHeaderIncludeInRequest", array("x-bce-meta-1")));
        $this->assertFalse(TestHelper::callFunction($this->put_object_command, "needHeaderIncludeInRequest", array("bucket-name")));
        $this->assertTrue(TestHelper::callFunction($this->put_object_command,"needHeaderIncludeInRequest", array("content-md5")));
        $this->assertTrue(TestHelper::callFunction($this->put_object_command,"needHeaderIncludeInRequest", array("content-length")));
        $this->assertTrue(TestHelper::callFunction($this->put_object_command,"needHeaderIncludeInRequest",array("content-type")));
    }

    public function testGetRequest(){
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
        $options[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] ="test-content";

        $options["content-Md5"] = "l0n60T1ucJKmM3xK";
        $options["content-length"] = "12";
        $options["content-type"] = "text/plain";
        $options["x-bce-meta-self"] = "test";
        $options["X-bce-content-sha256"] = "1eb79602419b148408";

        $this->assertTrue(TestHelper::callFunction($this->put_object_command, "checkOptions", array($client_options, $options)));

        $request = TestHelper::callFunction($this->put_object_command, "getRequest", array($client_options, $options));
        $this->assertNotNull($request);

        echo $request->getUri();
        $this->assertEquals("/v1/test-bucket/test_object", $request->getUri());
        echo $request->getHost();
        $this->assertEquals("127.0.0.1:8080", $request->getHost());

        $this->assertEquals(\baidubce\http\HttpMethod::HTTP_PUT, $request->getHttpMethod());
//
        $header = $request->getHeaders();
        var_dump($header);
        $this->assertEquals("127.0.0.1:8080", $header["host"]);
//        $this->assertEquals("l0n60T1ucJKmM3xK+dg3ZA", $header["content-md5"]);
        $this->assertEquals("12", $header["content-length"]);
        $this->assertEquals("text/plain", $header["content-type"]);
//        $this->assertEquals("1eb79602419b148408", $header["x-bce-content-sha256"]);
    }

}
 
