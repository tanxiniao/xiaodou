<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-14
 * Time: 下午8:48
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/ListObjectsResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";

use \baidubce\bos\model\response\ListObjectsResponse;
class ListObjectResponseTest extends PHPUnit_Framework_TestCase {
    private $list_Object_Response;

    public function setUp(){
        $this->list_Object_Response = new ListObjectsResponse("ListObjectsResponse");
    }
    public function tearDown(){}

    public function testParseResponse(){
        $string = $this->list_Object_Response->getOutputStream();

        $data = '{"name":"bucket","prefix": "","delimiter": "","marker": "fba9dede5f27731c9771645a39863328","maxKeys":"1000","isTruncated":"false","contents":[{"key": "my-image.jpg","lastModified": "2009-10-12T17:50:30Z","eTag":"fba9dede5f27731c9771645a39863328","size": "434234","owner":{"id": "encode_id","displayName": "mtd"}},{"key": "my-third-image.jpg","lastModified": "2009-10-12T17:50:30Z","eTag":"1b2cf535f27731c974343645a3985328","size": "64994","owner":{"id": "encode_id","displayName": "mtd"}}]}';
        $string->write($data);

        $response = TestHelper::callFunction($this->list_Object_Response, "parseResponse", array());
        $this->assertNull($response);

        $this->assertEquals("bucket",$this->list_Object_Response->getBucketName());
        $this->assertEquals("",$this->list_Object_Response->getDelimiter());
        $this->assertFalse($this->list_Object_Response->isTruncated());
        $this->assertEquals("fba9dede5f27731c9771645a39863328",$this->list_Object_Response->getMarker());
        $this->assertEquals("1000",$this->list_Object_Response->getMaxKeys());
        $this->assertEquals("",$this->list_Object_Response->getPrefix());

        $object_list = $this->list_Object_Response->getObjectList();
        $this->assertEquals("my-image.jpg",$object_list[0]->getObjectName());
        $this->assertEquals("",$object_list[0]->getPrefix());
        $this->assertEquals("fba9dede5f27731c9771645a39863328",$object_list[0]->getEtag());
        $this->assertEquals("encode_id",$object_list[0]->getOwnerId());
        $this->assertEquals("mtd",$object_list[0]->getOwnerName());
        $this->assertEquals("434234",$object_list[0]->getSize());

        $common_prefix_list = $this->list_Object_Response->getCommonPrefixList();
        $this->assertTrue(empty($common_prefix_list));
    }
}
 
