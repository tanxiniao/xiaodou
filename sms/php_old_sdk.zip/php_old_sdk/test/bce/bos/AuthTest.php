<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-25
 * Time: 下午7:13
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/auth/Auth.php";

require_once __BOS_CLIENT_ROOT . "/model/request/BosCommand.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";

use \baidubce\http\HttpMethod;

class AuthTest extends PHPUnit_Framework_TestCase {
    protected $auth;

    protected function setUp() {
        $this->auth = new \baidubce\auth\Auth("test_ak", "test_sk");
    }

    protected function tearDown() {}

    public function testConstruct()
    {
        $this->assertEquals("test_ak", $this->auth->getAccessKey());
        $this->assertEquals("test_sk", $this->auth->getAccessKeySecret());

        $signed_headers_keys= $this->auth->getSignedHeadersKeys();
        $this->assertEquals(4, count($signed_headers_keys));
        $this->assertTrue(array_key_exists("host", $signed_headers_keys));
        #$this->assertTrue(array_key_exists("content-length", $signed_headers_keys));
        $this->assertTrue(array_key_exists("content-type", $signed_headers_keys));
        #$this->assertTrue(array_key_exists("content-md5", $signed_headers_keys));
    }

    public function testGenerateAuthorization(){
        $response = new \baidubce\bos\model\request\BosCommand("auth");
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "10.58.144.56:8088";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "9aed84eced8a4cd8b20622352f345cd0";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "cbc3a456b9ff401cad2094193bab0413";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
        $request = TestHelper::callFunction($response, "getRequest", array($client_options,$options));
        $request->setHttpMethod(HttpMethod::HTTP_PUT);
        $result = TestHelper::callFunction($this->auth, "generateAuthorization", array($request));
        $this->assertContains("bce-auth-v1/test_ak/",$result);
    }
}

