<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-10
 * Time: 下午5:11
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/GetBucketAclResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";

use \baidubce\bos\model\response\GetBucketAclResponse;
class GetBucketAclResponseTest extends PHPUnit_Framework_TestCase {
    private $get_bucket_acl_response;

    public function setUp(){
        $this->get_bucket_acl_response = new GetBucketAclResponse("GetBucketAclResponse");
    }
    public function tearDown(){}

    public function testParseResponse(){
        $string = $this->get_bucket_acl_response->getOutputStream();

        $data = "{\"accessControlList\":[{\"grantee\":{\"displayName\":\"test_user\",\"id\":1},\"permission\":\"FULL_CONTROL\"},{ \"grantee\":{\"displayName\":\"AnonymousUser\",\"id\":0},\"permission\":\"READ\"}],\"owner\":{\"displayName\":\"test_user\",\"id\":1}}";

        $string->write($data);

        $response = TestHelper::callFunction($this->get_bucket_acl_response, "parseResponse", array());
        $this->assertNull($response);

        echo $this->get_bucket_acl_response->getOwnerName();
        $this->assertEquals("test_user",$this->get_bucket_acl_response->getOwnerName());
        $this->assertEquals(1,$this->get_bucket_acl_response->getOwnerId());

        $acl_array = $this->get_bucket_acl_response->getAcl();

        $this->assertEquals(1,$acl_array[0]->getGranteeId());
        $this->assertEquals("test_user",$acl_array[0]->getGranteeName());

        $this->assertEquals("FULL_CONTROL",$acl_array[0]->getPermission());

        $this->assertEquals(0,$acl_array[1]->getGranteeId());
        $this->assertEquals("AnonymousUser",$acl_array[1]->getGranteeName());

        $this->assertEquals("READ",$acl_array[1]->getPermission());

    }

}
 
