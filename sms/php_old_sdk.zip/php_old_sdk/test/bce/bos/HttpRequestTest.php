<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-17
 * Time: 下午6:07
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpRequest.php";
require_once __DIR__ . "/TestHelper.php";
use \baidubce\http\HttpRequest;

class HttpRequestTest extends PHPUnit_Framework_TestCase {
    protected $http_request;

    protected function setUp(){
        $this->http_request = new HttpRequest();
    }

    protected function tearDown(){}

    public function testFunctions(){
        TestHelper::callFunction($this->http_request, "setHost", array("test_host"));
        $this->assertEquals("test_host", TestHelper::callFunction($this->http_request, "getHost", array()));

        TestHelper::callFunction($this->http_request, "setQueryString", array("test_queryString"));
        $this->assertEquals("test_queryString", TestHelper::callFunction($this->http_request, "getQueryString", array()));

        TestHelper::callFunction($this->http_request, "setUri", array("test_uri"));
        $this->assertEquals("test_uri", TestHelper::callFunction($this->http_request, "getUri", array()));

        $test_array = array();
        $result = TestHelper::callFunction($this->http_request, "setHeaders", array($test_array));
        $this->assertEquals(0, count(TestHelper::callFunction($this->http_request, "getHeaders", array())));

        TestHelper::callFunction($this->http_request, "setInputStream", array("test"));
        $this->assertEquals("test", TestHelper::callFunction($this->http_request, "getInputStream", array()));

        TestHelper::callFunction($this->http_request, "setHttpMethod", array("test"));
        $this->assertEquals("test", TestHelper::callFunction($this->http_request, "getHttpMethod", array()));


        TestHelper::callFunction($this->http_request, "addHttpHeader", array("test_key","test_value"));
        $result = TestHelper::callFunction($this->http_request, "getHeaders", array());

        $this->assertEquals("test_value",$result["test_key"]);
    }
}
 
