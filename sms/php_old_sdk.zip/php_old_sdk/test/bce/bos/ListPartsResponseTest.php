<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-15
 * Time: 下午1:53
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/ListPartsResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";

use \baidubce\bos\model\response\ListPartsResponse;
class ListPartsResponseTest extends PHPUnit_Framework_TestCase {
    private $list_parts_response;

    public function setUp(){
        $this->list_parts_response = new ListPartsResponse("ListPartsResponse");
    }
    public function tearDown(){}

    public function testParseResponse(){
        $string = $this->list_parts_response->getOutputStream();

        $data = '{"bucket":"example-bucket","key":"example-object","uploadId":"XmcncyVcdS1tb3ZpZS5tMnRzEEEwbG9hZA","initiated":"2010-11-10T20:48:33Z","owner":{"id":"75aa570f8e7faeebf76c078efc7c6caea54ba06a","displayName":"someName"},"partNumberMarker":"1","nextPartNumberMarker":"3","maxParts":"2","isTruncated":"true","parts":[{"partNumber":"2","lastModified":"2010-11-10T20:48:34Z","eTag":"7778aef83f66abc1fa1e8477f296d394","size":"10485760"},{"partNumber":"3","lastModified":"2010-11-10T20:48:33Z","eTag":"aaaa18db4cc2f85cedef654fccc4a4x8","size":"10485760"}]}';
        $string->write($data);

        $response = TestHelper::callFunction($this->list_parts_response, "parseResponse", array());
        $this->assertNull($response);

        $this->assertEquals("example-bucket",$this->list_parts_response->getBucketName());
        $this->assertTrue($this->list_parts_response->getIsTruncated());
        $this->assertEquals("2",$this->list_parts_response->getMaxParts());
        $this->assertEquals("3",$this->list_parts_response->getNextPartNumberMarker());
        $this->assertEquals("example-object",$this->list_parts_response->getObjectName());
        $this->assertEquals("75aa570f8e7faeebf76c078efc7c6caea54ba06a",$this->list_parts_response->getOwnerId());
        $this->assertEquals("someName",$this->list_parts_response->getOwnerName());

        $parts_info = $this->list_parts_response->getPartInfo();
        $this->assertEquals("7778aef83f66abc1fa1e8477f296d394", $parts_info[0]->getEtag());
        $this->assertEquals("2", $parts_info[0]->getPartNumber());
        $this->assertEquals("10485760", $parts_info[0]->getSize());

        $this->assertEquals("10485760", $parts_info[1]->getSize());

        $this->assertEquals("1",$this->list_parts_response->getPartNumberMarker());
        $this->assertEquals("XmcncyVcdS1tb3ZpZS5tMnRzEEEwbG9hZA",$this->list_parts_response->getUploadId());
    }
}
 
