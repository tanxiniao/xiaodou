<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午5:09
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/request/CompleteMultipartUpload.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";

require_once __DIR__ . "/TestHelper.php";

use \baidubce\bos\model\request\CompleteMultipartUpload;
use \baidubce\bos\model\request\MultipartUploadPartId;

class CompleteMultipartUploadCommandTest extends PHPUnit_Framework_TestCase {
    private $complete_multipartUpload_command;

    public function setUp(){
        $this->complete_multipartUpload_command = new CompleteMultipartUpload("CompleteMultipartUpload");
    }
    public function tearDown(){}

    public function testCheckOptionsOk(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
        $options[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] ="test-content";
        $options[\baidubce\bos\util\BosOptions::UPLOAD_ID] ="test-uploadId";
        $options[\baidubce\bos\util\BosOptions::PART_LIST] = "test-part-list";

        $options[\baidubce\bos\util\BosOptions::PART_NUM] = 1;


        $this->assertTrue(TestHelper::callFunction($this->complete_multipartUpload_command, "checkOptions", array($client_options, $options)));
        $this->assertEquals("test-bucket", TestHelper::getAttribute($this->complete_multipartUpload_command, "bucket_name"));
        $this->assertEquals("test_object", TestHelper::getAttribute($this->complete_multipartUpload_command, "object_name"));
        $this->assertEquals("test-uploadId", TestHelper::getAttribute($this->complete_multipartUpload_command,"upload_id"));
        $this->assertEquals("test-part-list", TestHelper::getAttribute($this->complete_multipartUpload_command,"part_list"));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage miss upload id
     */
    public function testCheckOptionsUploadIdNotSet(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
        $options[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] ="test-content";
        TestHelper::callFunction($this->complete_multipartUpload_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage miss part list
     */
    public function testCheckOptionPartlistNotSet(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
        $options[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] ="test-content";
        $options[\baidubce\bos\util\BosOptions::UPLOAD_ID] ="test-uploadId";
        TestHelper::callFunction($this->complete_multipartUpload_command, "checkOptions", array($client_options, $options));
    }

    public function testNeedHeaderIncludeInRequest() {
        $this->assertTrue(TestHelper::callFunction($this->complete_multipartUpload_command, "needHeaderIncludeInRequest", array("x-bce-meta-1")));
        $this->assertTrue(TestHelper::callFunction($this->complete_multipartUpload_command, "needHeaderIncludeInRequest", array("x-bce-xx")));
        $this->assertTrue(TestHelper::callFunction($this->complete_multipartUpload_command, "needHeaderIncludeInRequest", array("content-length")));
        $this->assertTrue(TestHelper::callFunction($this->complete_multipartUpload_command, "needHeaderIncludeInRequest", array("content-md5")));
    }
    public function testGetRequest(){
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
        $options[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] ="test-content";
        $options[\baidubce\bos\util\BosOptions::UPLOAD_ID] ="test-uploadId";
        $options[\baidubce\bos\util\BosOptions::CONTENT_TYPE] ="text/plain;charset=us-ascii";

        $part_list = array();
        array_push($part_list, new MultipartUploadPartId("test", 1));
        $options[\baidubce\bos\util\BosOptions::PART_LIST] = $part_list;

        $this->assertTrue(TestHelper::callFunction($this->complete_multipartUpload_command, "checkOptions", array($client_options, $options)));

        $request = TestHelper::callFunction($this->complete_multipartUpload_command, "getRequest", array($client_options, $options));
        $this->assertNotNull($request);

        $this->assertEquals("127.0.0.1:8080", $request->getHost());
        $this->assertEquals(\baidubce\http\HttpMethod::HTTP_POST, $request->getHttpMethod());
        $result = $request->getQueryString();
        $this->assertEquals("test-uploadId", $result["uploadId"]);

        $header = $request->getHeaders();
        //$this->assertEquals("text/plain;charset=us-ascii", $header["Content-Type"]);
        //$this->assertEquals("127.0.0.1:8080", $header["Host"]);
        //$this->assertEquals(42, $header["Content-Length"]);
        $this->assertEquals("text/plain;charset=us-ascii", $header["content-type"]);
        $this->assertEquals("127.0.0.1:8080", $header["host"]);
        $this->assertEquals(42, $header["content-length"]);
    }

}
 
