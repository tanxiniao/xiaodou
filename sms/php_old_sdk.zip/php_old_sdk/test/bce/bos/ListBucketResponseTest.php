<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-14
 * Time: 上午11:17
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/ListBucketsResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";

use \baidubce\bos\model\response\ListBucketsResponse;
class ListBucketResponseTest extends PHPUnit_Framework_TestCase {
    private $list_bucket_response;

    public function setUp(){
        $this->list_bucket_response = new ListBucketsResponse("ListBucketsResponse");
    }
    public function tearDown(){}

    public function testParseResponse(){
        $string = $this->list_bucket_response->getOutputStream();

        $data = '{"owner":{"id":"encode_id","displayName":"BcsUser"},"buckets":[{"name":"bucket1","creationDate":"2012-02-03T16:45:09Z"},{"name":"bucket2","creationDate":"2013-02-03T16:41:58Z"}]}';
        $string->write($data);

        $response = TestHelper::callFunction($this->list_bucket_response, "parseResponse", array());
        $this->assertNull($response);

        $bucket_list = $this->list_bucket_response->getBucketList();
        $this->assertEquals("bucket1",$bucket_list[0]->getBucketName());
        $this->assertEquals("bucket2",$bucket_list[1]->getBucketName());

        $this->assertEquals("encode_id",$this->list_bucket_response->getOwnerId());
        $this->assertEquals("BcsUser",$this->list_bucket_response->getOwnerDisplayName());
    }

}
 
