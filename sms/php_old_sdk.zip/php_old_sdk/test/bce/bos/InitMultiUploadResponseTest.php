<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-14
 * Time: 上午11:09
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/InitiateMultipartUploadResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";

//use \bce\bos\response\InitMultiUploadResponse;
use baidubce\bos\model\response\InitiateMultipartUploadResponse;
class InitMultiUploadResponseTest extends PHPUnit_Framework_TestCase {
    private $init_multiUpload_response;

    public function setUp(){
        $this->init_multiUpload_response = new InitiateMultipartUploadResponse("InitiateMultipartUploadResponse");
    }
    public function tearDown(){}

    public function testParseResponse(){
        $string = $this->init_multiUpload_response->getOutputStream();

        $data = "{\"bucket\":\"test-bucket\",\"key\":\"test-object\",\"uploadId\":\"VXBsb2FkIElpZS5tMnRzIHVwbG9hZA\"}";
        $string->write($data);

        $response = TestHelper::callFunction($this->init_multiUpload_response, "parseResponse", array());
        $this->assertNull($response);

        echo $this->init_multiUpload_response->getBucketName();
        $this->assertEquals("test-bucket",$this->init_multiUpload_response->getBucketName());
        $this->assertEquals("test-object",$this->init_multiUpload_response->getObjectName());
        $this->assertEquals("VXBsb2FkIElpZS5tMnRzIHVwbG9hZA",$this->init_multiUpload_response->getUploadId());
    }
}
 
