<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-16
 * Time: 下午5:23
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/model/stream/BceStringOutputStream.php";
require_once __DIR__ . "/TestHelper.php";
use \baidubce\model\stream\BceStringOutputStream;

class BosStringOutputStreamTest extends PHPUnit_Framework_TestCase {
    protected $bos_string_output_stream;

    protected function setUp(){
        $this->bos_string_output_stream = new BceStringOutputStream();
    }

    protected function tearDown(){}

    public function testFunctions(){
        $data = '{"bucket": "test-bucket"}';
        $this->assertEquals(25,TestHelper::callFunction($this->bos_string_output_stream, "write", array($data)));

        $result =TestHelper::callFunction($this->bos_string_output_stream, "readAll", array());
        $this->assertEquals('{"bucket": "test-bucket"}',TestHelper::callFunction($this->bos_string_output_stream, "readAll", array()));

        $this->assertEquals(0,TestHelper::callFunction($this->bos_string_output_stream, "reserve", array($data)));
    }
}
 
