<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-10
 * Time: 上午9:35
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/CompleteMultipartUploadResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/model/stream/BceStringOutputStream.php";

use \baidubce\bos\model\response\CompleteMultipartUploadResponse;

class CompleteMultipartUploadResponseTest extends PHPUnit_Framework_TestCase {
    private $complete_multipart_upload_response;

    public function setUp(){
        $this->complete_multipart_upload_response = new CompleteMultipartUploadResponse("CompleteMultipartUploadResponseTest");
    }
    public function tearDown(){}

    public function testParseResponse(){
        $string = $this->complete_multipart_upload_response->getOutputStream();


        $data = "{\"location\":\"http://bcs.baidu.com/Bucket/Object\",\"bucket\":\"test-bucket\",\"key\":\"test-object\",\"eTag\":\"3858f62230ac3c915f300c664312c11f\"}";
        $string->write($data);

        $response = TestHelper::callFunction($this->complete_multipart_upload_response, "parseResponse", array());
        $this->assertNull($response);

        $this->assertEquals("test-bucket",$this->complete_multipart_upload_response->getBucketName());
        $this->assertEquals("http://bcs.baidu.com/Bucket/Object",$this->complete_multipart_upload_response->getLocation());
        $this->assertEquals("test-object",$this->complete_multipart_upload_response->getObjectName());
    }
}
 
