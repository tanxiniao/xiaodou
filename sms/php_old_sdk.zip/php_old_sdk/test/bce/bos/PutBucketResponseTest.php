<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-16
 * Time: 下午1:51
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/CreateBucketResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";

use baidubce\bos\model\response\CreateBucketResponse;
class PutBucketResponseTest extends PHPUnit_Framework_TestCase {
    private $put_bucket_response;

    public function setUp(){
        $this->put_bucket_response = new CreateBucketResponse("CreateBucketResponse");
    }
    public function tearDown(){}

    public function testGetLocation(){
        $random = "";
        $raw_header = 'HTTP/1.1 200 OK';
        $response = TestHelper::callFunction($this->put_bucket_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $raw_header = 'Location:/BucketRegion';
        $response = TestHelper::callFunction($this->put_bucket_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $this->assertEquals("/BucketRegion",TestHelper::callFunction($this->put_bucket_response, "getLocation", array()));
        echo TestHelper::callFunction($this->put_bucket_response, "getLocation", array());

    }
}
 
