<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-14
 * Time: 上午10:38
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/GetBucketConfigurationResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";

use \baidubce\bos\model\response\GetBucketConfigurationResponse;

class GetBucketConfigurationResponseTest extends PHPUnit_Framework_TestCase {
    private $get_bucket_configuration_response;

    public function setUp(){
        $this->get_bucket_configuration_response = new GetBucketConfigurationResponse("GetBucketConfigurationResponse");
    }

    public function tearDown(){}

    public function testParseResponse(){
        $string = $this->get_bucket_configuration_response->getOutputStream();

        $data ="{\"locationConstraint\":\"BucketRegion\"}";
        $string->write($data);

        $response = TestHelper::callFunction($this->get_bucket_configuration_response, "parseResponse", array());
        $this->assertNull($response);

        echo $this->get_bucket_configuration_response->getLocationConstraint();
        $this->assertEquals("BucketRegion",$this->get_bucket_configuration_response->getLocationConstraint());
    }

}
 
