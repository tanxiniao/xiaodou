<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-16
 * Time: 下午6:46
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/model/stream/BceStringInputStream.php";
require_once __DIR__ . "/TestHelper.php";

use \baidubce\model\stream\BceStringInputStream;

class BosStringInputStreamTest extends PHPUnit_Framework_TestCase {
    protected $bos_string_input_stream;

    protected function setUp(){
        $this->bos_string_input_stream = new BceStringInputStream( '{"bucket": "test-bucket"}');
    }

    protected function tearDown(){}

    public function testConstruct(){
        $this->assertEquals('{"bucket": "test-bucket"}', $this->bos_string_input_stream->readAll());
        $this->assertEquals(0, $this->bos_string_input_stream->GetPos());
        $this->assertEquals(25, $this->bos_string_input_stream->getSize());

        $size = 25;
        $result = TestHelper::callFunction($this->bos_string_input_stream, "read", array($size));
        $this->assertEquals('{"bucket": "test-bucket"}',$result);

        $pos = 3;
        $this->assertEquals(3,TestHelper::callFunction($this->bos_string_input_stream, "seek", array($pos)));
    }

    /**
     * @expectedException \baidubce\exception\BceStreamException
     * @expectedExceptionMessage seek across end of string stream
     */
    public function testSeekIllegal(){
        $pos = 100;
        $this->assertEquals(3,TestHelper::callFunction($this->bos_string_input_stream, "seek", array($pos)));
        TestHelper::callFunction($this->bos_string_input_stream, "seek", array($pos));
    }
}
 
