<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-14
 * Time: 上午10:48
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/GetObjectResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";

use \baidubce\bos\model\response\GetObjectResponse;

class GetObjectResponseTest extends PHPUnit_Framework_TestCase {
    private $get_object_response;

    public function setUp(){
        $options = array();

        $options[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STREAM] = "ObjectDataStream";
        $this->get_object_response = new GetObjectResponse($options);
    }

    public function tearDown(){}

    public function testParseResponse(){
        $random = "";
        $raw_header = 'HTTP/1.1 206 Partial Content';
        $response = TestHelper::callFunction($this->get_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);
        $raw_header = 'ETag:769dea2e840ad8fbacfb1beeaba58c10';
        $response = TestHelper::callFunction($this->get_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $raw_header = 'x-bce-request-id:47622117804B3E11';
        $response = TestHelper::callFunction($this->get_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $raw_header = 'Content-Range: bytes 0-9/44';
        $response = TestHelper::callFunction($this->get_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $raw_header = 'Content-Length:10';
        $response = TestHelper::callFunction($this->get_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $result = TestHelper::callFunction($this->get_object_response, "parseResponse", array());
        $this->assertNull($result);

        $this->assertEquals("769dea2e840ad8fbacfb1beeaba58c10",$this->get_object_response->getETag());
        $this->assertEquals("bytes 0-9/44",$this->get_object_response->getContentRange());
        $this->assertEquals("10",$this->get_object_response->getContentLength());

        $result = TestHelper::callFunction($this->get_object_response, "getContentStream", array());
        $this->assertEquals("ObjectDataStream",$result);

    }

    public function testGetObjectMeta(){
        $random = "";
        $raw_header = 'HTTP/1.1 200 OK';
        $response = TestHelper::callFunction($this->get_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $raw_header = 'ETag: 769dea2e840ad8fbacfb1beeaba58c10';
        $response = TestHelper::callFunction($this->get_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $raw_header = 'x-bce-request-id: 318BC8BC143432E5';
        $response = TestHelper::callFunction($this->get_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $raw_header = 'Content-Length: 434234';
        $response = TestHelper::callFunction($this->get_object_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $response = TestHelper::callFunction($this->get_object_response, "getObjectMeta", array());
        $this->assertEquals(0, count($response));
    }
}
 
