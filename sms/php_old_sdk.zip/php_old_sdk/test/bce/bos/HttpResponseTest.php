<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-17
 * Time: 下午6:25
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpResponse.php";
require_once __DIR__ . "/TestHelper.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/model/stream/BceStringOutputStream.php";

use \baidubce\http\HttpResponse;
use \baidubce\model\stream\BceStringOutputStream;
class HttpResponseTest extends PHPUnit_Framework_TestCase {
    protected $http_response;

    protected function setUp(){
        $stream = new BceStringOutputStream();
        $this->http_response = new HttpResponse($stream);
    }

    protected function tearDown(){}

    public function testConstruct(){
        $response = TestHelper::callFunction($this->http_response, "getHasRecvStatusLine", array());
        $this->assertFalse($response);
        $this->assertEquals(0, count(TestHelper::callFunction($this->http_response, "getHttpHeaders", array())));
    }

    public function testWriteBody(){
        $random = "";
        $raw_header = 'HTTP/1.1 206 Partial Content';
        $response = TestHelper::callFunction($this->http_response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $curl_handle = "";
        $data = '{"bucket": "test-bucket"}';
        TestHelper::callFunction($this->http_response, "writeBody", array($curl_handle,$data));

        $result = TestHelper::callFunction($this->http_response, "getOutputStream", array());
    }

    public function testWriteHeader(){
        $curl_handle = "";
        $raw_header_line = 'HTTP/1.1 200 OK';
        TestHelper::callFunction($this->http_response, "writeHeader", array($curl_handle, $raw_header_line));

        $raw_header_line = 'Content-Length: 197';
        $result = TestHelper::callFunction($this->http_response, "writeHeader", array($curl_handle, $raw_header_line));

        $result = TestHelper::callFunction($this->http_response, "getReasonPhrase", array());
        $this->assertEquals("OK",$result);

        $result = TestHelper::callFunction($this->http_response, "getHttpHeaders", array());
        $this->assertEquals(197, $result["Content-Length"]);

        print_r("++\n");
        $this->assertEquals(197, TestHelper::callFunction($this->http_response, "getResponseHeader", array("Content-Length")));
        $this->assertEquals("", TestHelper::callFunction($this->http_response, "getResponseHeader", array("?")));
        $this->assertEquals('HTTP/1.1', TestHelper::callFunction($this->http_response, "getHttpVersion", array()));


        $result = TestHelper::callFunction($this->http_response, "getHttpCode", array());
        $this->assertEquals(200, $result);

    }

    public function testHeaderNotSet(){
        $curl_handle = "";
        $raw_header_line = '';
        $result = TestHelper::callFunction($this->http_response, "writeHeader", array($curl_handle, $raw_header_line));
        $this->assertEquals(0,$result);
    }
}
 
