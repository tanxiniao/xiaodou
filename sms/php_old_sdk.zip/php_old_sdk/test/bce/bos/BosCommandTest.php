 <?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-1
 * Time: 下午2:49
 */

 define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

 require_once __BOS_CLIENT_ROOT . "/model/request/BosCommand.php";
 require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
 require_once __BOS_CLIENT_ROOT . "/BosRequest.php";

 require_once __DIR__ . "/TestHelper.php";

 use \baidubce\bos\model\request\BosCommand;
 use \baidubce\bos\service\BosRequest;
 use  \baidubce\http\HttpMethod;

class BosCommandTest extends PHPUnit_Framework_TestCase {
    private $bos_command;

    public function setUp(){
        $this->bos_command = new BosCommand("BosCommand");
    }

    public function tearDown(){}

    public function testGetRequest(){
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options["Content-type"] = "test";


        $this->assertTrue(TestHelper::callFunction($this->bos_command, "checkOptions", array($client_options, $options)));

        $request = TestHelper::callFunction($this->bos_command, "getRequest", array($client_options, $options));
        $this->assertNotNull($request);
        $this->assertEquals("/v1/", $request->getUri());

        $header = $request->getHeaders();
        var_dump($header);
        $this->assertEquals("127.0.0.1:8080", $header["host"]);
        $this->assertEquals("test", $header["content-type"]);
        echo  $header["expect"];
        $this->assertEquals('', $header["expect"]);
        $this->assertEquals('', $header["transfer-encoding"]);
    }

    public function testSetServiceClient(){
        $test_string = "test-client-service";
        $this->bos_command->setServiceClient($test_string);
    }

    public function testGetDefaultContentType(){
        $string = TestHelper::callFunction($this->bos_command, "getDefaultContentType", array(""));
        echo $string;
    }

    public function testGetContext(){
        $this->assertNull(TestHelper::callFunction($this->bos_command, "getContext", array("")));
    }

    public function testCheckOptions(){
        $client_options = array();
        $options = array();

        $this->assertTrue(TestHelper::callFunction($this->bos_command, "checkOptions", array($client_options, $options)));
    }

    public function testNeedHeaderIncludeInRequest(){
        $headerKey = array();
        $this->assertFalse(TestHelper::callFunction($this->bos_command, "needHeaderIncludeInRequest", array($headerKey)));
    }

    public  function  testAddAuthorization(){
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";

        //$request= new BosRequest($client_options);
        //$request->setHttpMethod(HttpMethod::HTTP_PUT);
        //$result = TestHelper::callFunction($this->bos_command, "addAuthorization", array($request, $client_options));
        $request= TestHelper::callFunction($this->bos_command, "getRequest", array($client_options,$options));
        $request->setHttpMethod(HttpMethod::HTTP_PUT);
        $result = TestHelper::callFunction($this->bos_command, "addAuthorization", array($request, $client_options));
    }
}
 
