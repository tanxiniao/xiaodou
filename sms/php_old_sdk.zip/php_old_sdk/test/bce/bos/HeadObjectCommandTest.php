<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-8
 * Time: 下午3:36
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/request/GetObjectMetadata.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";

use \baidubce\bos\model\request\GetObjectMetadata;
class HeadObjectCommandTest extends PHPUnit_Framework_TestCase {
    private $head_object_command;

    protected function setUp() {
        $this->head_object_command = new GetObjectMetadata("GetObjectMetadata");
    }
    protected function tearDown() {}

    public function testCheckOptionsOk(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";

        $this->assertTrue(TestHelper::callFunction($this->head_object_command, "checkOptions", array($client_options, $options)));
        $this->assertEquals("test-bucket", TestHelper::getAttribute($this->head_object_command, "bucket_name"));
        $this->assertEquals("test_object", TestHelper::getAttribute($this->head_object_command, "object_name"));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name not exist in object request
     */
    public function testCheckOptionsBucketNameNotSet(){
        $client_options = array();
        $options = array();

        TestHelper::callFunction($this->head_object_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name Illegal
     */
    public function testCheckOptionsBucketNameIllegal(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "&123";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
        TestHelper::callFunction($this->head_object_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage object name not exist in object request
     */
    public function testCheckOptionsObjectNameNotSet(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test_bucket";
        TestHelper::callFunction($this->head_object_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage object name name Illegal
     */
    public function testCheckOptionsObjectNameIllegal(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "";
        TestHelper::callFunction($this->head_object_command, "checkOptions", array($client_options, $options));
    }

    public function testGetRequest()
    {
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";

        $this->assertTrue(TestHelper::callFunction($this->head_object_command, "checkOptions", array($client_options, $options)));

        $request = TestHelper::callFunction($this->head_object_command, "getRequest", array($client_options, $options));
        $this->assertNotNull($request);

        echo $request->getUri();
        $this->assertEquals("/v1/test-bucket/test_object", $request->getUri());
        echo $request->getHost();
        $this->assertEquals("127.0.0.1:8080", $request->getHost());
        $this->assertEquals(0, count($request->getQueryString()));
        $this->assertEquals(\baidubce\http\HttpMethod::HTTP_HEAD, $request->getHttpMethod());

        $header = $request->getHeaders();
        $this->assertContains("127.0.0.1:8080", $header['host']);
    }

}
 
