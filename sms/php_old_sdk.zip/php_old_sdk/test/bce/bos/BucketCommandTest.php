<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-4
 * Time: 下午4:50
 */

define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/request/BucketCommand.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";

use \baidubce\bos\model\request\BucketCommand;

class BucketCommandTest extends PHPUnit_Framework_TestCase {
    private $bucket_command;
    public function setUp(){
        $this->bucket_command = new BucketCommand("PutObjectCommand");
    }
    public function tearDown(){}

    public function testCheckOptionsOk(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";

        $this->assertTrue(TestHelper::callFunction($this->bucket_command, "checkOptions", array($client_options, $options)));
        $this->assertEquals("test-bucket", TestHelper::getAttribute($this->bucket_command, "bucket_name"));
    }


    /**
     * @expectedException \baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name not exist in object request
     */
    public function testCheckOptionsBucketNameNotSet(){
        $client_options = array();
        $options = array();

        TestHelper::callFunction($this->bucket_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException \baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name Illegal
     */
    public function testCheckOptionsBucketNameIllegal(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "-123";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
        TestHelper::callFunction($this->bucket_command, "checkOptions", array($client_options, $options));
    }

    public function testGetRequest(){
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";

        $this->assertTrue(TestHelper::callFunction($this->bucket_command, "checkOptions", array($client_options, $options)));

        $request = TestHelper::callFunction($this->bucket_command, "getRequest", array($client_options, $options));
        $this->assertNotNull($request);

        echo $request->getUri();
        $this->assertEquals("/v1/test-bucket", $request->getUri());
    }
}
 
