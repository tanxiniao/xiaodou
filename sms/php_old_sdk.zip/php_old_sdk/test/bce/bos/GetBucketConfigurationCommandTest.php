<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-5
 * Time: 下午7:10
 */

define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/request/GetBucketConfiguration.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";

require_once __DIR__ . "/TestHelper.php";

use \baidubce\bos\model\request\GetBucketConfiguration;

class GetBucketConfigurationCommandTest extends PHPUnit_Framework_TestCase {
    private $get_bucket_configuration_command;

    public function setUp(){
        $this->get_bucket_configuration_command = new GetBucketConfiguration("GetBucketConfiguration");
    }
    public function tearDown(){}

    public function testCheckOptionsOk(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";

        $this->assertTrue(TestHelper::callFunction($this->get_bucket_configuration_command, "checkOptions", array($client_options, $options)));
        $this->assertEquals("test-bucket", TestHelper::getAttribute($this->get_bucket_configuration_command, "bucket_name"));
    }
    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name not exist in object request
     */
    public function testCheckOptionsBucketNameNotSet(){
        $client_options = array();
        $options = array();

        TestHelper::callFunction($this->get_bucket_configuration_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name Illegal
     */
    public function testCheckOptionsBucketNameIllegal(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "1+23";
        TestHelper::callFunction($this->get_bucket_configuration_command, "checkOptions", array($client_options, $options));
    }

    public function testGetRequest(){
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";

        $options["content-type"] = "text/plain";

        $this->assertTrue(TestHelper::callFunction($this->get_bucket_configuration_command, "checkOptions", array($client_options, $options)));

        $request = TestHelper::callFunction($this->get_bucket_configuration_command, "getRequest", array($client_options, $options));
        $this->assertNotNull($request);

        //$this->assertEquals("configuration=", $request->getQueryString());
        $qs = $request->getQueryString();
        $this->assertEquals("", $qs["configuration"]);
        $this->assertEquals(\baidubce\http\HttpMethod::HTTP_GET, $request->getHttpMethod());
    }

}
 
