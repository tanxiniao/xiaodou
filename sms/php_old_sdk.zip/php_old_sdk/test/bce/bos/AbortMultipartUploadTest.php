<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-8-26
 * Time: 下午7:11
 */

define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos/");

require_once __BOS_CLIENT_ROOT . "/model/request/AbortMultipartUpload.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";

use \baidubce\bos\model\request\AbortMultipartUpload;

class AbortMultipartUploadTest extends PHPUnit_Framework_TestCase {
    private $abort_multipartUpload;

    public function setUp(){
        $this->abort_multipartUpload = new AbortMultipartUpload("AbortMultipartUpload");
    }
    public function tearDown(){}

    public function testGetRequest(){
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
        $options[\baidubce\bos\util\BosOptions::UPLOAD_ID] ="test-uploadId";

        $request = TestHelper::callFunction($this->abort_multipartUpload, "getRequest", array($client_options, $options));
        $this->assertNotNull($request);

        echo $request->getUri();
        $this->assertEquals("/v1/", $request->getUri());
        echo $request->getHost();
        $this->assertEquals("127.0.0.1:8080", $request->getHost());

        $result = $request->getQueryString();
        var_dump($result);
        $this->assertNotNull($result);
        $this->assertEquals(\baidubce\http\HttpMethod::HTTP_DELETE, $request->getHttpMethod());

        $header = $request->getHeaders();
        $this->assertContains("127.0.0.1:8080", $header["host"]);
    }
}


