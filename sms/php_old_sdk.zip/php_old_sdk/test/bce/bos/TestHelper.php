<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-7-1
 * Time: 下午6:54
 */

class TestHelper {
    protected static function getMethod($class_name, $function_name) {
        $class = new ReflectionClass($class_name);
        $method = $class->getMethod($function_name);
        $method->setAccessible(true);
        return $method;
    }
    static function callFunction($obj, $function_name, array $function_arg) {
        $method = self::getMethod(get_class($obj), $function_name);

        return $method->invokeArgs($obj, $function_arg);
    }

    static function getAttribute($obj, $attribute) {
        return PHPUnit_Framework_Assert::readAttribute($obj, $attribute);
    }
} 