<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-16
 * Time: 下午8:48
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/BosResponse.php";
require_once __DIR__ . "/TestHelper.php";

require_once __BOS_CLIENT_ROOT . "/model/request/BosCommand.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/model/stream/BceStringOutputStream.php";

use \baidubce\bos\service\BosResponse;
use \baidubce\model\stream\BceStringOutputStream;


class BosResponseTest extends PHPUnit_Framework_TestCase {
    protected $bos_Response;

    protected function setUp(){
        $stream = new BceStringOutputStream();
        $this->bos_Response = new BosResponse($stream);
    }

    protected function tearDown(){}

    public function testParseResponse(){
        $random = "";
        $raw_header = 'HTTP/1.1 206 Partial Content';
        $response = TestHelper::callFunction($this->bos_Response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);


        $raw_header = 'x-bce-request-id: 318BC8BC143432E5';
        $response = TestHelper::callFunction($this->bos_Response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $raw_header = 'x-bce-debug-id: 318BC8BC143432E1';
        $response = TestHelper::callFunction($this->bos_Response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        TestHelper::callFunction($this->bos_Response, "parseResponse", array());

        $this->assertEquals("318BC8BC143432E1",TestHelper::callFunction($this->bos_Response, "getDebugId", array()));
        $this->assertEquals("318BC8BC143432E5",TestHelper::callFunction($this->bos_Response, "getRequestId", array()));
    }

    public  function testGetErroMessage(){
        $this->assertEquals("",TestHelper::callFunction($this->bos_Response, "getErrorMessage", array()));
    }

    public function testWriteBody(){
        $random = "";
        $raw_header = 'HTTP/1.1 206 Partial Content';
        $response = TestHelper::callFunction($this->bos_Response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $curl_handle = "";
        $data = '{"bucket": "test-bucket"}';
        TestHelper::callFunction($this->bos_Response, "writeBody", array($curl_handle,$data));
    }

    public function  testWriteBodyIllegalData(){
        $random = "";
        $raw_header = 'HTTP/1.1 506 Partial Content';
        $response = TestHelper::callFunction($this->bos_Response, "writeHeader", array($random, $raw_header));
        $this->assertNotNull($response);

        $curl_handle = "";
        $data = '{"bucket": "test-bucket"}';
        TestHelper::callFunction($this->bos_Response, "writeBody", array($curl_handle,$data));
        $result = TestHelper::callFunction($this->bos_Response, "getErrorMessage", array());
        $this->assertEquals('{"bucket": "test-bucket"}',$result);

    }
}
 
