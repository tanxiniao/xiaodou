<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-8
 * Time: 下午7:37
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/request/ListMultipartUploads.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";

require_once __DIR__ . "/TestHelper.php";

use \baidubce\bos\model\request\ListMultipartUploads;
class ListMultipartUploadsCommandTest extends PHPUnit_Framework_TestCase {
    private $list_multipart_object_command;

    public function setUp(){
        $this->list_multipart_object_command = new ListMultipartUploads("ListMultipartUploads");
    }
    public function tearDown(){}

    public function testCheckOptionsOk(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";

        $options[\baidubce\bos\util\BosOptions::LIST_DELIMITER] = "test-delimiter";
        $options[\baidubce\bos\util\BosOptions::LIST_MARKER] = "test-marker";
        $options[\baidubce\bos\util\BosOptions::LIST_MAX_UPLOAD_SIZE] = 1000;
        $options[\baidubce\bos\util\BosOptions::LIST_PREFIX] = "test-prefix";

        $this->assertTrue(TestHelper::callFunction($this->list_multipart_object_command, "checkOptions", array($client_options, $options)));
        $this->assertEquals("test-bucket", TestHelper::getAttribute($this->list_multipart_object_command, "bucket_name"));
        $this->assertEquals("1000", TestHelper::getAttribute($this->list_multipart_object_command, "max_uploads"));
        $this->assertEquals("test-delimiter", TestHelper::getAttribute($this->list_multipart_object_command, "delimiter"));
        $this->assertEquals("test-marker", TestHelper::getAttribute($this->list_multipart_object_command, "marker"));
        $this->assertEquals("test-prefix", TestHelper::getAttribute($this->list_multipart_object_command, "prefix"));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name not exist in object request
     */
    public function testCheckOptionsBucketNameNotSet(){
        $client_options = array();
        $options = array();

        TestHelper::callFunction($this->list_multipart_object_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name Illegal
     */
    public function testCheckOptionsBucketNameIllegal(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "123&";
        TestHelper::callFunction($this->list_multipart_object_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage LIST_MAX_KEY_SIZE must less than 1000
     */
    public function testCheckOptionsMaxUploadSizeIllegal(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::LIST_MAX_UPLOAD_SIZE] = 10000;
        TestHelper::callFunction($this->list_multipart_object_command, "checkOptions", array($client_options, $options));
    }

    public function testGetRequest(){
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";

        $options[\baidubce\bos\util\BosOptions::LIST_DELIMITER] = "test-delimiter";
        $options[\baidubce\bos\util\BosOptions::LIST_MARKER] = "test-marker";
        $options[\baidubce\bos\util\BosOptions::LIST_MAX_UPLOAD_SIZE] = 1000;
        $options[\baidubce\bos\util\BosOptions::LIST_PREFIX] = "test-prefix";

        $this->assertTrue(TestHelper::callFunction($this->list_multipart_object_command, "checkOptions", array($client_options, $options)));

        $request = TestHelper::callFunction($this->list_multipart_object_command, "getRequest", array($client_options, $options));
        $this->assertNotNull($request);

        echo $request->getHost();
        $this->assertEquals("127.0.0.1:8080", $request->getHost());

        var_dump($request->getQueryString());
        $qs = $request->getQueryString();
        $this->assertEquals($qs["uploads"], "");
        $this->assertEquals($qs["delimiter"], "test-delimiter");
        $this->assertEquals($qs["keyMarker"], "test-marker");
        $this->assertEquals($qs["maxUploads"], 1000);
        $this->assertEquals($qs["prefix"], "test-prefix");
        //$this->assertContains("uploads=", $request->getQueryString());
        //$this->assertContains("delimiter=test-delimiter", $request->getQueryString());
        //$this->assertContains("keyMarker=test-marker", $request->getQueryString());
        //$this->assertContains("maxUploads=1000", $request->getQueryString());
        //$this->assertContains("prefix=test-prefix", $request->getQueryString());

        $this->assertEquals(\baidubce\http\HttpMethod::HTTP_GET, $request->getHttpMethod());

        $header = $request->getHeaders();
        //$this->assertContains("Host:127.0.0.1:8080", $header);
        $this->assertEquals("127.0.0.1:8080", $header["host"]);
    }



}
 
