<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-17
 * Time: 下午5:02
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";
require_once __DIR__ . "/TestHelper.php";
use \baidubce\http\HttpMethod;
class HttpMethodTest extends PHPUnit_Framework_TestCase {
    protected $http_method;

    protected function setUp(){
        $this->http_method = new HttpMethod();
    }

    protected function tearDown(){}

    public function testGetStringMethod(){
        $string_methods = array("PUT","GET","HEAD","POST","DELETE");
        $method = 0;
        foreach($string_methods as $string_method){
            TestHelper::callFunction($this->http_method, "getStringMethod", array($method + 1));
        }
    }
}
 
