<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-14
 * Time: 下午5:24
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/ListMultipartUploadsResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";

use \baidubce\bos\model\response\ListMultipartUploadsResponse;
class ListMultipartUploadsResponseTest extends PHPUnit_Framework_TestCase {
    private $list_multipart_Uploads_response;

    public function setUp(){
        $this->list_multipart_Uploads_response = new ListMultipartUploadsResponse("ListMultipartUploadsResponse");
    }
    public function tearDown(){}

    public function testParseResponse(){
        $string = $this->list_multipart_Uploads_response->getOutputStream();

        $data = '{"bucket":"bucket","keyMarker":"","delimiter":"","prefix":"","nextKeyMarker":"my-movie.m2ts","maxUploads":"3","isTruncated":"true","uploads": [{"key":"my-divisor","uploadId":"XMgbGlrZSBlbHZpbmcncyBgbHVjaw","owner":{"id":"75aa57f09aa0c8caeab4aeebf76c078efc7c6caea54ba06a","displayName":"OwnerDisplayName"},"initiated":"2010-11-10T20:48:33Z"},{"key":"my-movie.m2ts","uploadId":"VXmcncyBteS1tb3ZpZS5tMnRzIHVwbG9hZA","owner":{"id":"b1d16700c70b0b05597d7acd6a3f92be","displayName":"OwnerDisplayName"},"initiated":"2010-11-10T20:48:33Z"},{"key":"my-movie.m2ts","uploadId":"YW55IGlkZWEgd2h5IGVsdmluZydzIHVwbG9hZCBmYWlsZWQ","owner":{"id":"b1d16700c70b0b05597d7acd6a3f92be","displayName":"OwnerDisplayName"},"initiated":"2010-11-10T20:49:33Z"}]}';
        $string->write($data);

        $response = TestHelper::callFunction($this->list_multipart_Uploads_response, "parseResponse", array());
        $this->assertNull($response);

        $this->assertEquals("",$this->list_multipart_Uploads_response->getPrefix());
        $this->assertEquals("",$this->list_multipart_Uploads_response->getDelimiter());
        $this->assertEquals("bucket",$this->list_multipart_Uploads_response->getBucketName());
        $common_prefix_list = $this->list_multipart_Uploads_response->getCommonPrefixList();
        $this->assertEquals(0, count($common_prefix_list));

        $this->assertTrue($this->list_multipart_Uploads_response->getIsTruncated());
        $this->assertEquals("",$this->list_multipart_Uploads_response->getKeyMarker());
        $this->assertEquals(3,$this->list_multipart_Uploads_response->getMaxUploads());
        $this->assertEquals("my-movie.m2ts",$this->list_multipart_Uploads_response->getNextKeyMarker());

        $upload_list = $this->list_multipart_Uploads_response->getUploadList();

        $this->assertEquals("my-divisor",$upload_list[0]->getObjectName());
        $this->assertEquals("b1d16700c70b0b05597d7acd6a3f92be",$upload_list[1]->getOwnerId());
//        var_dump($upload_list[2]->getInitiatedTime());
        $this->assertEquals("YW55IGlkZWEgd2h5IGVsdmluZydzIHVwbG9hZCBmYWlsZWQ",$upload_list[2]->getUploadId());
    }
}
 
