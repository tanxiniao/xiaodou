<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-17
 * Time: 下午4:10
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/model/request/BosCommand.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/model/stream/BceStringOutputStream.php";

use \baidubce\bos\service\BosRequest;

class BosRequestTest extends PHPUnit_Framework_TestCase {
    protected $bos_request;

    protected function setUp(){
        $options = array();
        $options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $this->bos_request = new BosRequest($options);
    }

    protected function tearDown(){}

    public function testConstruct(){
        $this->assertEquals(1800,TestHelper::callFunction($this->bos_request, "getExpirationPeriodInSeconds", array()));
    }

    public function testSet(){
        TestHelper::callFunction($this->bos_request, "setBucketName", array("test_bucket"));
        TestHelper::callFunction($this->bos_request, "setObjectName", array("test_object"));
    }

    public function testGet(){
        TestHelper::callFunction($this->bos_request, "addQueryString", array("BUCKET","test_bucket"));
        $result = TestHelper::callFunction($this->bos_request, "getQueryString", array());
        $this->assertEquals("test_bucket",$result["BUCKET"]);
        $this->assertEquals('/v1/',TestHelper::callFunction($this->bos_request, "getUri", array()));

        TestHelper::callFunction($this->bos_request, "setBucketName", array("test_bucket"));
        $this->assertEquals('/v1/test_bucket',TestHelper::callFunction($this->bos_request, "getUri", array()));

        TestHelper::callFunction($this->bos_request, "setObjectName", array("test_object"));
        $this->assertEquals('/v1/test_bucket/test_object',TestHelper::callFunction($this->bos_request, "getUri", array()));
    }

    /**
     * @expectedException \RuntimeException
     * @expectedExceptionMessage unexpected funcation call BosRequest::setUri
     */
    public function testSetUri(){
        TestHelper::callFunction($this->bos_request, "setUri", array("uri"));
    }

    /**
     * @expectedException \RuntimeException
     * @expectedExceptionMessage unexpected funcation call BosRequest::setQueryString
     */
    public function testSetQueryString(){
        TestHelper::callFunction($this->bos_request, "setQueryString", array("query_string"));
    }
}
 
