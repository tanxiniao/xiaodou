<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午1:28
 */

define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/request/ListObjects.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";

require_once __DIR__ . "/TestHelper.php";

use \baidubce\bos\model\request\ListObjects;;

class ListObjectCommandTest extends PHPUnit_Framework_TestCase {
    private $list_object_command;

    public function setUp(){
        $this->list_object_command = new ListObjects("ListObjects");
    }
    public function tearDown(){}

    public function testCheckOptionsOk(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::LIST_DELIMITER] = "/";
        $options[\baidubce\bos\util\BosOptions::LIST_MARKER] = "/";
        $options[\baidubce\bos\util\BosOptions::LIST_MAX_KEY_SIZE] = 100;
        $options[\baidubce\bos\util\BosOptions::LIST_PREFIX] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::LIST_MAX_UPLOAD_SIZE] = 100;

        $this->assertTrue(TestHelper::callFunction($this->list_object_command, "checkOptions", array($client_options, $options)));
        $this->assertEquals("test-bucket", TestHelper::getAttribute($this->list_object_command, "bucket_name"));
        $this->assertEquals("/", TestHelper::getAttribute($this->list_object_command, "delimiter"));
        $this->assertEquals("/", TestHelper::getAttribute($this->list_object_command, "marker"));
        $this->assertEquals("100",TestHelper::getAttribute($this->list_object_command, "max_keys"));
        $this->assertEquals("test-bucket",TestHelper::getAttribute($this->list_object_command, "prefix"));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name not exist in object request
     */
    public function testCheckOptionsBucketNameNotSet(){
        $client_options = array();
        $options = array();

        TestHelper::callFunction($this->list_object_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage bucket name Illegal
     */
    public function testCheckOptionsBucketNameIllegal(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "";
        TestHelper::callFunction($this->list_object_command, "checkOptions", array($client_options, $options));
    }

    /**
     * @expectedException baidubce\exception\BceIllegalArgumentException
     * @expectedExceptionMessage LIST_MAX_KEY_SIZE must less than 1000
     */
    public function testCheckOptionsMaxKeySizeIllegal(){
        $client_options = array();
        $options = array();

        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::LIST_MAX_KEY_SIZE] = -1;
        $options[\baidubce\bos\util\BosOptions::LIST_MAX_UPLOAD_SIZE] = 100;
        TestHelper::callFunction($this->list_object_command, "checkOptions", array($client_options, $options));

        $options[\baidubce\bos\util\BosOptions::LIST_MAX_KEY_SIZE] = 1200;
        TestHelper::callFunction($this->list_object_command, "checkOptions", array($client_options, $options));
    }

    public function testGetRequest(){
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::LIST_MAX_KEY_SIZE] = 0;
        $options[\baidubce\bos\util\BosOptions::LIST_MARKER] = "/";
        $options[\baidubce\bos\util\BosOptions::LIST_DELIMITER] = "/";
        $options[\baidubce\bos\util\BosOptions::LIST_PREFIX] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::LIST_MAX_UPLOAD_SIZE] = 100;

        $this->assertTrue(TestHelper::callFunction($this->list_object_command, "checkOptions", array($client_options, $options)));

        $request = TestHelper::callFunction($this->list_object_command, "getRequest", array($client_options, $options));
        $this->assertNotNull($request);

        $this->assertEquals("127.0.0.1:8080", $request->getHost());

        $result = $request->getQueryString();
        var_dump($result);
        $this->assertEquals(0, $result["maxKeys"]);
        $this->assertEquals("/", $result["marker"]);
        $this->assertEquals("test-bucket", $result["prefix"]);
        $this->assertEquals("/", $result["delimiter"]);
        $this->assertEquals(\baidubce\http\HttpMethod::HTTP_GET, $request->getHttpMethod());

        $header = $request->getHeaders();
        $this->assertEquals("127.0.0.1:8080", $header['host']);
    }





}
 
