<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-10
 * Time: 下午4:27
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/response/CopyObjectResponse.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";
require_once __DIR__ . "/TestHelper.php";
require_once __BOS_CLIENT_ROOT . "/BosRequest.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/http/HttpMethod.php";
require_once dirname(dirname(__BOS_CLIENT_ROOT)) . "/model/stream/BceStringOutputStream.php";

use \baidubce\bos\model\response\CopyObjectResponse;

class CopyObjectResponseTest extends PHPUnit_Framework_TestCase {
    private $copy_object_response;

    public function setUp(){
        $this->copy_object_response = new CopyObjectResponse("CopyObjectResponse");
    }
    public function tearDown(){}

    public function testParseResponse(){
        $string = $this->copy_object_response->getOutputStream();


        $data = "{\"lastModified\":\"2009-10-28T22:32:00\",\"eTag\":\"3858f62230ac3c915f300c664312c11f\"}";
        $string->write($data);

        $response = TestHelper::callFunction($this->copy_object_response, "parseResponse", array());
        $this->assertNull($response);

        $this->assertEquals("3858f62230ac3c915f300c664312c11f",$this->copy_object_response->getDestEtag());
    }
}
 
