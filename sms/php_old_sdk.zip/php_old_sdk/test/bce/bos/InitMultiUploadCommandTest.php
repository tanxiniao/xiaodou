<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午3:09
 */
define('__BOS_CLIENT_ROOT', dirname(dirname(dirname(__DIR__))). "/baidubce/services/bos");

require_once __BOS_CLIENT_ROOT . "/model/request/InitiateMultipartUpload.php";
require_once __BOS_CLIENT_ROOT . "/util/BosOptions.php";

require_once __DIR__ . "/TestHelper.php";

use \baidubce\bos\model\request\InitiateMultipartUpload;
class InitMultiUploadCommandTest extends PHPUnit_Framework_TestCase {
    private $init_multipart_upload_command;

    public function setUp(){
        $this->init_multipart_upload_command = new InitiateMultipartUpload("InitiateMultipartUpload");
    }
    public function tearDown(){}

    public function testGetRequest(){
        $client_options = array();
        $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "127.0.0.1:8080";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "test_ak";
        $client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "test_sk";
        $client_options["content-type"] = "type";

        $options = array();
        $options[\baidubce\bos\util\BosOptions::BUCKET] = "test-bucket";
        $options[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";

        $options["content-length"] = "2048";

        $this->assertTrue(TestHelper::callFunction($this->init_multipart_upload_command, "checkOptions", array($client_options, $options)));

        $request = TestHelper::callFunction($this->init_multipart_upload_command, "getRequest", array($client_options, $options));
        $this->assertNotNull($request);

       var_dump($request->getQueryString()) ;
        $result = $request->getQueryString();

        $this->assertEquals("", $result["uploads"]);
        $this->assertEquals(\baidubce\http\HttpMethod::HTTP_POST, $request->getHttpMethod());

        $header = $request->getHeaders();
        $this->assertEquals("0", $header["content-length"]);
    }

}
 
