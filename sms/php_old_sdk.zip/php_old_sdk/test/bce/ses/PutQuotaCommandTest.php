<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午2:46
 */

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
// use baidubce\ses\model\request\DeleteRecipientBlacklist;

class PutQuotaCommandTest extends PHPUnit_Framework_TestCase {

    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    public function testPutQuotaCommandTest_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$maxPerDay = 300;
		$maxPerSecond = 5;
    	$response = $ses_client->putQuota($maxPerDay, $maxPerSecond);
        $this->assertEquals(200, $response->getHttpCode());
		//check data
		$response = $ses_client->getQuota();
        $this->assertEquals(200, $response->getHttpCode());
		$this->assertEquals($maxPerDay, $response->getMaxPerDay());
		$this->assertEquals($maxPerSecond, $response->getMaxPerSecond());
    }
    
    /**
	 *set maxPerSecond
     */
    public function testPutQuotaCommandTest_EmptyMaxPerDay(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$response = $ses_client->getQuota();
        $this->assertEquals(200, $response->getHttpCode());
		$oldMaxPerDay = $response->getMaxPerDay();
		
		//set quota
    	$maxPerDay = '';
		$maxPerSecond = 2;
    	$response = $ses_client->putQuota($maxPerDay, $maxPerSecond);
        $this->assertEquals(200, $response->getHttpCode());
		
		sleep(1);
		//check data
		$response = $ses_client->getQuota();
        $this->assertEquals(200, $response->getHttpCode());
		$this->assertEquals($oldMaxPerDay, $response->getMaxPerDay());
		$this->assertEquals($maxPerSecond, $response->getMaxPerSecond());
    }
    
    /**
     * empty value,keep old data
     */
    public function testPutQuotaCommandTest_EmptyMaxPerSecond(){
    	//get old data
		$ses_client = \baidubce\ses\SesClient::factory();
		$response = $ses_client->getQuota();
        $this->assertEquals(200, $response->getHttpCode());
		$oldMaxPerSecond = $response->getMaxPerSecond();
		
		//set quota
		$maxPerDay = 600;
    	$maxPerSecond = '';
    	$response = $ses_client->putQuota($maxPerDay, $maxPerSecond);
    	$this->assertEquals(200, $response->getHttpCode());
		
		sleep(1);
		//check data
		$response = $ses_client->getQuota();
        $this->assertEquals(200, $response->getHttpCode());
		$this->assertEquals($maxPerDay, $response->getMaxPerDay());
		$this->assertEquals($oldMaxPerSecond, $response->getMaxPerSecond());
    }
	
	/**
     * both empty,keep old data
     */
    public function testPutQuotaCommandTest_EmptyValue(){
    	//get old data
		$ses_client = \baidubce\ses\SesClient::factory();
		$response = $ses_client->getQuota();
        $this->assertEquals(200, $response->getHttpCode());
		$oldMaxPerDay = $response->getMaxPerDay();
		$oldMaxPerSecond = $response->getMaxPerSecond();
		
		//set quota
		$maxPerDay = '';
    	$maxPerSecond = '';
    	$response = $ses_client->putQuota($maxPerDay, $maxPerSecond);
    	$this->assertEquals(200, $response->getHttpCode());
		
		sleep(1);
		//check data
		$response = $ses_client->getQuota();
        $this->assertEquals(200, $response->getHttpCode());
		$this->assertEquals($oldMaxPerDay, $response->getMaxPerDay());
		$this->assertEquals($oldMaxPerSecond, $response->getMaxPerSecond());
    }
	
	/**
     * string type
     */
    public function testPutQuotaCommandTest_stringValue(){
		$ses_client = \baidubce\ses\SesClient::factory();		
		//set quota
		$maxPerDay = '123';
    	$maxPerSecond = '456';
    	$response = $ses_client->putQuota($maxPerDay, $maxPerSecond);
    	$this->assertEquals(200, $response->getHttpCode());
		
		sleep(1);
		//check data
		$response = $ses_client->getQuota();
        $this->assertEquals(200, $response->getHttpCode());
		$this->assertEquals($maxPerDay, $response->getMaxPerDay());
		$this->assertEquals($maxPerSecond, $response->getMaxPerSecond());
    }
	
	/**
     * invalid string type
	 * @expectedException baidubce\exception\BceServiceException
     */
    public function testPutQuotaCommandTest_invalidStrValue(){
		$ses_client = \baidubce\ses\SesClient::factory();		
		//set quota
		$maxPerDay = '123str';
    	$maxPerSecond = 'str456';
    	$response = $ses_client->putQuota($maxPerDay, $maxPerSecond);
    }
}
 