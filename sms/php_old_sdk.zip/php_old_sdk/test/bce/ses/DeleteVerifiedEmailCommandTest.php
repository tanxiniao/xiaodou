<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午2:46
 */

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
// use baidubce\ses\model\request\DeleteVerifiedEmail;

class DeleteVerifiedEmailCommandTest extends PHPUnit_Framework_TestCase {

    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    public function testDeleteVerifiedEmail_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	//verified email
    	$emailAddress = 'zhangxiang01@baidu.com';
    	$response = $ses_client->putVerifiedEmail($emailAddress);
    	$this->assertEquals(200, $response->getHttpCode());
    	//del email
    	$response = $ses_client->deleteVerifiedEmail($emailAddress);
        $this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 *email not exist
	 */
	public function testDeleteVerifiedEmail_notExistEmail(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$emailAddress = 'wanglinqing@com';
		//del email
    	$response = $ses_client->deleteVerifiedEmail($emailAddress);
        $this->assertEquals(200, $response->getHttpCode());
    }
    
    /**
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testDeleteVerifiedEmail_EmptyEmail(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->deleteVerifiedEmail();
    }
}
 