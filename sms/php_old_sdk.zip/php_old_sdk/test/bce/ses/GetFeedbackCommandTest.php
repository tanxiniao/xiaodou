 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
require_once(__DIR__ . '/../../../baidubce/services/ses/util/SesOptions.php');

use baidubce\ses\util\SesOptions;

class GetFeedbackCommand extends PHPUnit_Framework_TestCase {
    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    /**
     * normal
     */
    public function testGetFeedback_Normal(){
    	//set feedback
		$ses_client = \baidubce\ses\SesClient::factory();
		$type = 1;
		$enabled = true;
		$email = 'feedback@sample.com';
    	$response = $ses_client->putFeedback($type, $enabled, $email);
        $this->assertEquals(200, $response->getHttpCode());
		
		//check data
		$response = $ses_client->getFeedback();
        $this->assertEquals(1, $response->getType());
		$this->assertEquals(true, $response->getEnabled());
		$this->assertEquals($email, $response->getEmail());
    }
	
	public function testGetFeedback_setType(){
		$ses_client = \baidubce\ses\SesClient::factory();
		//set feedback
		$type = 3;
    	$response = $ses_client->putFeedback($type);
        $this->assertEquals(200, $response->getHttpCode());
		
		//check data
		$response = $ses_client->getFeedback();
        $this->assertEquals($type, $response->getType());
		$this->assertEquals(false, $response->getEnabled());
		//$this->assertEquals($email, $response->getEmail());
    }
	
	public function testGetFeedback_setEnabled(){
		$ses_client = \baidubce\ses\SesClient::factory();
		//set feedback
		$type = null;
		$enabled = true;
    	$response = $ses_client->putFeedback($type, $enabled);
        $this->assertEquals(200, $response->getHttpCode());
		
		//check data
		$response = $ses_client->getFeedback();
        $this->assertEquals(1, $response->getType());
		$this->assertEquals($enabled, $response->getEnabled());
		//$this->assertEquals($email, $response->getEmail());
    }
	
	public function testGetFeedback_setEmail(){
		$ses_client = \baidubce\ses\SesClient::factory();
		//set feedback
		$type = null;
		$enabled = null;
		$email = 'test@baidu.com';
    	$response = $ses_client->putFeedback($type, $enabled, $email);
        $this->assertEquals(200, $response->getHttpCode());
		
		//check data
		$response = $ses_client->getFeedback();
        $this->assertEquals(1, $response->getType());
		$this->assertEquals(false, $response->getEnabled());
		$this->assertEquals($email, $response->getEmail());
    }
    
    /**
     * 获取权限认证失败
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testGetFeedback_AuthFail(){
    	$config[SesOptions::ACCESS_KEY_ID] = 'notValidAk';
    	$config[SesOptions::ACCESS_KEY_SECRET] = 'notValidSk';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getFeedback();
    	//断言状态码是200
    	$statusCode = $response->getHttpCode();
    	$this->assertEquals(401, $statusCode);
//    	$this->assertNotEmpty($response->getErrorCode());
    	$this->assertNotEmpty($response->getErrorMessage());
    	$this->assertNotEmpty($response->getRequestId());
    }
    
    /**
     * AK/SK为空时抛出异常
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testGetFeedback_EmptyAkSk(){
    	$config[SesOptions::ACCESS_KEY_ID] = '';
    	$config[SesOptions::ACCESS_KEY_SECRET] = '';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getFeedback();
    }
    
    /**
     * HOST为空时抛出异常
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testGetFeedback_EmptyHost(){
    	$config[SesOptions::ENDPOINT] = '';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getFeedback();
    }
}