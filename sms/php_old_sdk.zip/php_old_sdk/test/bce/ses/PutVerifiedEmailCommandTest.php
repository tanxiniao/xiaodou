<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午2:46
 */

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
// use baidubce\ses\model\request\DeleteVerifiedEmail;

class PutVerifiedEmailCommandTest extends PHPUnit_Framework_TestCase {

    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    public function testPutVerifiedEmail_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$emailAddress = 'wanglinqing2010@126.com';
    	$response = $ses_client->putVerifiedEmail($emailAddress);
        $this->assertEquals(200, $response->getHttpCode());
    }
    
    /**
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testPutVerifiedEmail_EmptyEmailAddress(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->putVerifiedEmail();
    }
	
	/**
     * error email format
	 * @expectedException baidubce\exception\BceServiceException
     */
    public function testPutVerifiedEmail_errorEmailFormat(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$emailAddress = 'wanglinqing';
    	$response = $ses_client->putVerifiedEmail($emailAddress);
		$this->assertEquals(302, $response->getHttpCode());
    }
}
 