<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午2:46
 */

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
// use baidubce\ses\model\request\DeleteRecipientBlacklist;

class DeleteRecipientBlacklistCommandTest extends PHPUnit_Framework_TestCase {

    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    public function testDeleteRecipientBlacklist_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
    	$emailAddress = 'wanglinqing@baidu.com';
    	$response = $ses_client->putRecipientBlacklist($emailAddress);
    	$this->assertEquals(200, $response->getHttpCode());
    	
    	$response = $ses_client->deleteRecipientBlacklist($emailAddress);
        $this->assertEquals(200, $response->getHttpCode());
    }
    
	/**
	 *email not blacklist
	 */
	public function testDeleteRecipientBlacklist_emailNotBlacklist(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
    	$emailAddress = 'zhangxiang2014@126.com';
    	$response = $ses_client->deleteRecipientBlacklist($emailAddress);
        $this->assertEquals(200, $response->getHttpCode());
    }
	
    /**
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testDeleteRecipientBlacklist_EmptyEmailAddress(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->deleteRecipientBlacklist();
    }
}
 