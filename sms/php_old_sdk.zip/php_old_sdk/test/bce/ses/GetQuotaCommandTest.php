 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
require_once(__DIR__ . '/../../../baidubce/services/ses/util/SesOptions.php');

use baidubce\ses\util\SesOptions;

class GetQuotaCommand extends PHPUnit_Framework_TestCase {
    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    /**
     * 获取配额
     */
    public function testGetQuota_Normal(){
    	//get original quota
		$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->getQuota();
        $this->assertEquals(200, $response->getHttpCode());
		$maxPerDay = $response->getMaxPerDay();
		$maxPerSecond = $response->getMaxPerSecond();
		$usedToday = $response->getUsedToday();
		
		sleep(1);
		
		//send mail
		$from = 'wanglinqing2010@126.com';
		$subject = array('charset'=>3,'data'=>'get quota test');
		$message = array('text'=>array('charset'=>0,'data'=>'message quota test'));
		$toAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr);
		$this->assertEquals(200, $response->getHttpCode());
		
		sleep(1);
		//get quota
		$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->getQuota();
        $this->assertEquals(200, $response->getHttpCode());
		$usedToday = $usedToday + 1;
		$this->assertEquals($maxPerDay, $response->getMaxPerDay());
		$this->assertEquals($maxPerSecond, $response->getMaxPerSecond());
		$this->assertEquals($usedToday, $response->getUsedToday());
    }
    
    /**
     * 获取权限认证失败
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testGetQuota_AuthFail(){
    	$config[SesOptions::ACCESS_KEY_ID] = 'notValidAk';
    	$config[SesOptions::ACCESS_KEY_SECRET] = 'notValidSk';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getQuota();
    	//断言状态码是200
    	$statusCode = $response->getHttpCode();
    	$this->assertEquals(401, $statusCode);
//    	$this->assertNotEmpty($response->getErrorCode());
    	$this->assertNotEmpty($response->getErrorMessage());
    	$this->assertNotEmpty($response->getRequestId());
    }
    
    /**
     * AK/SK为空时抛出异常
	 * @expectedException baidubce\exception\BceServiceException
     */
    public function testGetQuota_EmptyAkSk(){
    	$config[SesOptions::ACCESS_KEY_ID] = '';
    	$config[SesOptions::ACCESS_KEY_SECRET] = '';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getQuota();
    	$statusCode = $response->getHttpCode();
    	$this->assertEquals(401, $statusCode);
    	//    	$this->assertNotEmpty($response->getErrorCode());
    	$this->assertNotEmpty($response->getErrorMessage());
    	$this->assertNotEmpty($response->getRequestId());
    }
    
    /**
     * HOST为空时抛出异常
     * @expectedException baidubce\exception\BceRuntimeException
    */ 
    public function testGetQuota_EmptyHost(){
    	$config[SesOptions::ENDPOINT] = '';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getQuota();
    	$statusCode = $response->getHttpCode();
    	$this->assertEquals(401, $statusCode);
    	//    	$this->assertNotEmpty($response->getErrorCode());
    	$this->assertNotEmpty($response->getErrorMessage());
    	$this->assertNotEmpty($response->getRequestId());
    }
}