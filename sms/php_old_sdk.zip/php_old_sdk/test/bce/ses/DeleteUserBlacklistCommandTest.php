<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午2:46
 */

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
// use baidubce\ses\model\request\DeleteUserBlacklist;

class DeleteUserBlacklistCommandTest extends PHPUnit_Framework_TestCase {

    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    public function testDeleteUserBlacklist_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
    	$userId = '56ce66dc36df46769094dfcdc5c688a4';
    	$response = $ses_client->putUserBlacklist($userId);
    	$this->assertEquals(200, $response->getHttpCode());
    	
    	$response = $ses_client->deleteUserBlacklist($userId);
        $this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 * userId not exist
	 */
	public function testDeleteUserBlacklist_uidNotExist(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$userId = '1234567890';
    	$response = $ses_client->deleteUserBlacklist($userId);
        $this->assertEquals(200, $response->getHttpCode());
    }
    
    /**
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testDeleteUserBlacklist_EmptyUserId(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->deleteUserBlacklist();
    }
}
 