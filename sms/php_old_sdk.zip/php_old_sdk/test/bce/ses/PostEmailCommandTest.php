<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午2:46
 */

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
// use baidubce\ses\model\request\DeleteRecipientBlacklist;

class PostEmailCommandTest extends PHPUnit_Framework_TestCase {

    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

	//认证邮箱：wanglinqing01@baidu.com   认证域名126.com
    public function testPostEmailCommandTest_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
		$from = 'wanglinqing01@baidu.com';
		$subject = array('charset'=>1,'data'=>'subject');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
		$ccAddr= array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
		$bccAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
		$priority = 1;
		$attachments= array(
		    'http://nj.bs.bae.baidu.com/mfb-pic-public/baidu无线密钥.txt',/*'http://nj.bs.bae.baidu.com/mfb-apk-public/b6083cdfde_v30_kirin_baiduzhidao_kirin.apk',*/  
		);
		
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
        $this->assertEquals(200, $response->getHttpCode());
    }
    
    /**
	 *empty attachments
     */
    public function testPostEmailCommandTest_EmptyAttachments(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
		$from = 'wanglinqing01@baidu.com';
		$subject = array('charset'=>1,'data'=>'subject');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'madboy87212@sina.com'));
		$ccAddr= array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'madboy87212@sina.com'));
		$bccAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'madboy87212@sina.com'));
		$priority = 1;
		$attachments = array();
		
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
        $this->assertEquals(200, $response->getHttpCode());
    }
    
    /**
     * @expectedException baidubce\exception\BceServiceException
	 * empty sender, error code 301
     */
    public function testPostEmailCommandTest_EmptySender(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
		$from = '';
		$subject = array('charset'=>1,'data'=>'subject');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'madboy87212@sina.com'));
		$ccAddr= array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'madboy87212@sina.com'));
		$bccAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'madboy87212@sina.com'));
		$priority = 1;
		$attachments = array();
		
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
		$this->assertEquals(301, $response->getHttpCode());
    }
    
    /**
     * @expectedException baidubce\exception\BceServiceException
	 * error code 302
     */
    public function testPostEmailCommandTest_EmptyReceiver(){
    	$ses_client = \baidubce\ses\SesClient::factory();

    	$from = 'zhangxiang01@baidu.com';
    	$subject = array('charset'=>1,'data'=>'subject');
    	$message = array('text'=>array('charset'=>1,'data'=>'message'));
    	$toAddr = array(array('addr'=>'madboy87212'));
    	$ccAddr= array();
    	$bccAddr = array();
    	$priority = 1;
    	$attachments = array();
    	
    	$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
		$this->assertEquals(302, $response->getHttpCode());
    }
	
	/**
     * @expectedException baidubce\exception\BceServiceException
	 * error code 302
     */
    public function testPostEmailCommandTest_ReceiverFormatInvalid(){
    	$ses_client = \baidubce\ses\SesClient::factory();

    	$from = 'zhangxiang01@baidu.com';
    	$subject = array('charset'=>1,'data'=>'subject');
    	$message = array('text'=>array('charset'=>1,'data'=>'message'));
    	$toAddr = array();
    	$ccAddr= array();
    	$bccAddr = array();
    	$priority = 1;
    	$attachments = array();
    	
    	$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
		$this->assertEquals(302, $response->getHttpCode());
    }
	
	/**
	 * sender not verified,error code 201
	 *@expectedException baidubce\exception\BceServiceException
	 */
	public function testPostEmailCommandTest_senderNotVerified(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
		$from = 'wanglinqingtest@baidu.com';
		$subject = array('charset'=>1,'data'=>'subject-senderNotVerified');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$ccAddr= array(array('addr'=>'wanglinqing01@baidu.com'));
		$bccAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$priority = 1;
		$attachments= array();
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
        $this->assertEquals(201, $response->getHttpCode());
		$this->assertEquals('Sender verified failed', $response->getErrorMessage());
    }
	
	/**
	 * sender domain not verified,error code 201
	 *@expectedException baidubce\exception\BceServiceException
	 */
	public function testPostEmailCommandTest_senderDomainNotVerified(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
		$from = 'wanglinqing2013@163.com';
		$subject = array('charset'=>1,'data'=>'subject-senderNotVerified');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$ccAddr= array(array('addr'=>'wanglinqing01@baidu.com'));
		$bccAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$priority = 1;
		$attachments= array();
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
        $this->assertEquals(201, $response->getHttpCode());
		$this->assertEquals('Sender verified failed', $response->getErrorMessage());
    }
	
	/**
	 * sender format not valid, error code 301
	 * add notes about exception
	 */
	public function testPostEmailCommandTest_senderFormatNotValid(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
		$from = 'wanglinqing2013';
		$subject = array('charset'=>1,'data'=>'subject-senderNotVerified');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$ccAddr= array(array('addr'=>'wanglinqing01@baidu.com'));
		$bccAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$priority = 1;
		$attachments= array();
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
        $this->assertEquals(301, $response->getHttpCode());
		$this->assertEquals('Sender verified failed', $response->getErrorMessage());
    }
	
	/**
	 *empty subject, error code 311
	 *@expectedException baidubce\exception\BceServiceException
	 */
	public function testPostEmailCommandTest_emptySubject(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
		$from = 'wanglinqing01@baidu.com';
		$subject = array('charset'=>1,'data'=>'');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
		$ccAddr= array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
		$bccAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
		$priority = 1;
		$attachments= array();
		
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
        $this->assertEquals(311, $response->getHttpCode());
		$this->assertEquals('Subject is NULL', $response->getErrorMessage());
    }
	
	/**
	 *more then one sender
	 *@expectedException baidubce\exception\BceServiceException
	 */
	public function testPostEmailCommandTest_moreSender(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
		$from = 'wanglinqing2010@126.com;wanglinqing01@baidu.com';
		$subject = array('charset'=>1,'data'=>'subject');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
		$ccAddr= array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
		$bccAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
		$priority = 1;
		$attachments= array();
		
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
    }
	
	/**
	 *receiver duplicate
	 */
	public function testPostEmailCommandTest_receiverDuplicate(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
		$from = 'wanglinqing01@baidu.com';
		$subject = array('charset'=>1,'data'=>'subject-receiverDulplicate');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'zhuimeng_2006jsj@126.com'),array('addr'=>'zhuimeng_2006jsj@126.com'));
		$ccAddr= array(array('addr'=>'wanglinqing2010@126.com'),array('addr'=>'wanglinqing2010@126.com'));
		$bccAddr = array(array('addr'=>'wanglinqing01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr);
		$this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 *include attachments
	 */
	public function testPostEmailCommandTest_attachments(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
		$from = 'wanglinqing01@baidu.com';
		$subject = array('charset'=>1,'data'=>'subject');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
		$ccAddr = array();
		$bccAddr = array();
		$priority = 1;
		$attachments= array(
		    'http://nj.bs.bae.baidu.com/mfb-pic-public/baidu无线密钥.txt',/*'http://nj.bs.bae.baidu.com/mfb-apk-public/b6083cdfde_v30_kirin_baiduzhidao_kirin.apk',*/  
		);
		
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
        $this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 * long long title
	 */
	public function testPostEmailCommandTest_longTitle(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
		$from = 'wanglinqing01@baidu.com';
		$subject = array('charset'=>1,'data'=>'长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题长标题');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr);
        $this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 * email not verified, but domain verified
	 */
	public function testPostEmailCommandTest_domainVerified(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$from = 'wanglinqing2010@126.com';
		$subject = array('charset'=>2,'data'=>'域名已认证但邮箱未单独认证');
		$message = array('text'=>array('charset'=>1,'data'=>'message'));
		$toAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr);
        $this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 * charset invalid(not 0-4)
	 * @expectedException baidubce\exception\BceServiceException
	 */
	public function testPostEmailCommandTest_charsetUnvalid(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$from = 'wanglinqing2010@126.com';
		$subject = array('charset'=>2,'data'=>'字符集非法');
		$message = array('text'=>array('charset'=>6,'data'=>'message测试字符集非法test'));
		$toAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr);
    }
	
	/**
	 * only ccAddr
	 */
	public function testPostEmailCommandTest_onlyccAddr(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$from = 'wanglinqing2010@126.com';
		$subject = array('charset'=>2,'data'=>'仅有密送人');
		$message = array('text'=>array('charset'=>0,'data'=>'message仅有抄送人test'));
		$toAddr = array();
		$ccAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr);
		$this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 * only bccAddr
	 */
	public function testPostEmailCommandTest_onlybccAddr(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$from = 'wanglinqing2010@126.com';
		$subject = array('charset'=>3,'data'=>'仅有抄送人');
		$message = array('text'=>array('charset'=>0,'data'=>'message仅有抄送人test'));
		$toAddr = array();
		$ccAddr = array();
		$bccAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr);
		$this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 * no param
	 * @expectedException baidubce\exception\BceServiceException
	 */
	public function testPostEmailCommandTest_noParam(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$from = '';
		$subject = array();
		$message = array();
		$toAddr = array();
		$ccAddr = array();
		$bccAddr = array();
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr);
    }
	
	/**
	 * no charset
	 */
	public function testPostEmailCommandTest_noCharset(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$from = 'wanglinqing2010@126.com';
		$subject = array('data'=>'no charset');
		$message = array('text'=>array('data'=>'no charset'));
		$toAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr);
		$this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 * html format
	 */
	public function testPostEmailCommandTest_htmlFormat(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$from = 'wanglinqing2010@126.com';
		$subject = array('data'=>'html format');
		$message = array('html'=>array('data'=>'<html><body><div><h3  align=\"center\">资源总数统计</h3><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"80%\" align=\"center\"> <tr><th bgColor=\"426ab3\">type</th><th bgColor=\"426ab3\">count</th></tr><tr> <td align=\"center\" bgColor=\"#9b95c9\">BCC云主机</td><td align=\"center\"  bgColor=\"#9b95c9\">15</td></tr><tr> <td align=\"center\" bgColor=\"#9b95c9\">RDS关系型数据库</td><td align=\"center\"  bgColor=\"#9b95c9\">15</td></tr><tr> <td align=\"center\" bgColor=\"#867892\">SCS缓存服务</td><td align=\"center\"  bgColor=\"#867892\">15</td></tr><tr> <td align=\"center\" bgColor=\"#fab27b\">BOS对象存储服务</td><td align=\"center\"  bgColor=\"#fab27b\">15</td></tr><tr> <td align=\"center\" bgColor=\"#c88400\">BMR百度MapReduce</td><td align=\"center\"  bgColor=\"#c88400\">15</td></tr><tr> <td align=\"center\" bgColor=\"#b7ba6b\">CDN服务</td><td align=\"center\"  bgColor=\"#b7ba6b\">15</td></tr><tr> <td align=\"center\" bgColor=\"#769149\">SES邮件服务</td><td align=\"center\"  bgColor=\"#769149\">15</td></tr><tr> <td align=\"center\" bgColor=\"#78a355\">SMS短信服务</td><td align=\"center\"  bgColor=\"#78a355\">15</td></tr></table></div><div><h3  align=\"center\">资源数量top10用户统计</h3><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" align=\"center\"> <tr><th bgColor=\"426ab3\">type</th><th bgColor=\"426ab3\">iam_account_id</th> <th bgColor=\"426ab3\">count</th></tr><tr> <td align=\"center\" bgColor=\"#9b95c9\">BCC云主机</td><td align=\"center\"  bgColor=\"#9b95c9\">dcf5a8476ba443988322ed577d67b8ef</td><td align=\"center\"  bgColor=\"#9b95c9\"> 10</td></tr><tr> <td align=\"center\" bgColor=\"#9b95c9\">BCC云主机</td><td align=\"center\"  bgColor=\"#9b95c9\">dcf5a8476ba443988322ed577d67b8ef</td><td align=\"center\"  bgColor=\"#9b95c9\"> 10</td></tr><tr> <td align=\"center\" bgColor=\"#9b95c9\">BCC云主机</td><td align=\"center\"  bgColor=\"#9b95c9\">1734317d-40c6-4950-b1f1-f45393970f63</td><td align=\"center\"  bgColor=\"#9b95c9\"> 9</td></tr><tr> <td align=\"center\" bgColor=\"#9b95c9\">BCC云主机</td><td align=\"center\"  bgColor=\"#9b95c9\">bbe13106ecaa4a9aa73188720f0e1193</td><td align=\"center\"  bgColor=\"#9b95c9\"> 6</td></tr><tr> <td align=\"center\" bgColor=\"#9b95c9\">BCC云主机</td><td align=\"center\"  bgColor=\"#9b95c9\">33ee9b2d-228b-42c2-aae5-b1f1841374fb</td><td align=\"center\"  bgColor=\"#9b95c9\"> 6</td></tr><tr> <td align=\"center\" bgColor=\"#867892\">SCS缓存服务</td><td align=\"center\"  bgColor=\"#867892\">0a784fe6cc4d49879b882645023aaa73</td><td align=\"center\"  bgColor=\"#867892\"> 10</td></tr><tr> <td align=\"center\" bgColor=\"#867892\">SCS缓存服务</td><td align=\"center\"  bgColor=\"#867892\">dcf5a8476ba443988322ed577d67b8ef1</td><td align=\"center\"  bgColor=\"#867892\"> 10</td></tr><tr> <td align=\"center\" bgColor=\"#867892\">SCS缓存服务</td><td align=\"center\"  bgColor=\"#867892\">1734317d-40c6-4950-b1f1-f45393970f63</td><td align=\"center\"  bgColor=\"#867892\"> 7</td></tr><tr> <td align=\"center\" bgColor=\"#867892\">SCS缓存服务</td><td align=\"center\"  bgColor=\"#867892\">bbe13106ecaa4a9aa73188720f0e1193</td><td align=\"center\"  bgColor=\"#867892\"> 5</td></tr><tr> <td align=\"center\" bgColor=\"#867892\">SCS缓存服务</td><td align=\"center\"  bgColor=\"#867892\">33ee9b2d-228b-42c2-aae5-b1f1841374fb</td><td align=\"center\"  bgColor=\"#867892\"> 5</td></tr><tr> <td align=\"center\" bgColor=\"#fab27b\">BOS对象存储服务</td><td align=\"center\"  bgColor=\"#fab27b\">bbe13106ecaa4a9aa73188720f0e1193</td><td align=\"center\"  bgColor=\"#fab27b\"> 5</td></tr><tr> <td align=\"center\" bgColor=\"#fab27b\">BOS对象存储服务</td><td align=\"center\"  bgColor=\"#fab27b\">bbe13106ecaa4a9aa73188720f0e1193</td><td align=\"center\"  bgColor=\"#fab27b\"> 5</td></tr><tr> <td align=\"center\" bgColor=\"#fab27b\">BOS对象存储服务</td><td align=\"center\"  bgColor=\"#fab27b\">bbe13106ecaa4a9aa73188720f0e1193</td><td align=\"center\"  bgColor=\"#fab27b\"> 5</td></tr><tr> <td align=\"center\" bgColor=\"#b7ba6b\">CDN服务</td><td align=\"center\"  bgColor=\"#b7ba6b\">bbe13106ecaa4a9aa73188720f0e1193</td><td align=\"center\"  bgColor=\"#b7ba6b\"> 5</td></tr><tr> <td align=\"center\" bgColor=\"#b7ba6b\">CDN服务</td><td align=\"center\"  bgColor=\"#b7ba6b\">bbe13106ecaa4a9aa73188720f0e1193</td><td align=\"center\"  bgColor=\"#b7ba6b\"> 5</td></tr><tr> <td align=\"center\" bgColor=\"#b7ba6b\">CDN服务</td><td align=\"center\"  bgColor=\"#b7ba6b\">bbe13106ecaa4a9aa73188720f0e1193</td><td align=\"center\"  bgColor=\"#b7ba6b\"> 5</td></tr><tr> <td align=\"center\" bgColor=\"#769149\">SES邮件服务</td><td align=\"center\"  bgColor=\"#769149\">bbe13106ecaa4a9aa73188720f0e1193</td><td align=\"center\"  bgColor=\"#769149\"> 5</td></tr><tr> <td align=\"center\" bgColor=\"#769149\">SES邮件服务</td><td align=\"center\"  bgColor=\"#769149\">bbe13106ecaa4a9aa73188720f0e1193</td><td align=\"center\"  bgColor=\"#769149\"> 5</td></tr></table></div></body></html>'));
		$toAddr = array(array('addr'=>'wanglinqing01@baidu.com'));
		$response = $ses_client->postEmail($from, $subject, $message, $toAddr);
		$this->assertEquals(200, $response->getHttpCode());
    }
}
 