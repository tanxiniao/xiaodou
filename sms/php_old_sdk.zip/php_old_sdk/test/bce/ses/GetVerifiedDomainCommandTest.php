 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
require_once(__DIR__ . '/../../../baidubce/services/ses/util/SesOptions.php');

use baidubce\ses\util\SesOptions;

class GetVerifiedDomainCommand extends PHPUnit_Framework_TestCase {
    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    /**
     * get verifieddomain list
     */
    public function testGetVerifiedDomainList_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->getVerifiedDomain();
        $this->assertEquals(200, $response->getHttpCode());
		$this->assertTrue(is_array($response->getDetails()));
    }
    
	/**
     * get verifieddomain
     */
    public function testGetVerifiedDomain_NormalDomain(){
    	//verified domain
		$ses_client = \baidubce\ses\SesClient::factory();
    	$domain = time().'qq.com';
    	$response = $ses_client->putVerifiedDomain($domain);
        $this->assertEquals(200, $response->getHttpCode());
		
		//get domain
		$response = $ses_client->getVerifiedDomain($domain);
    	$this->assertEquals(200, $response->getHttpCode());
    	$this->assertNotNull(is_array($response->getDetail()));
    }
	
	/**
     * get verifieddomain, invalid domain
	 *@expectedException baidubce\exception\BceServiceException
     */
    public function testGetVerifiedDomain_invalidDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$domain = 'qq';
    	$response = $ses_client->getVerifiedDomain($domain);
    	$this->assertEquals(204, $response->getHttpCode());
		$this->assertEquals('invalid domain', $response->getErrorMessage());
    }
	
    
    /**
     * 获取权限认证失败
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testGetVerifiedDomain_AuthFail(){
    	$config[SesOptions::ACCESS_KEY_ID] = 'notValidAk';
    	$config[SesOptions::ACCESS_KEY_SECRET] = 'notValidSk';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getVerifiedDomain();
    	//断言状态码是200
    	$statusCode = $response->getHttpCode();
    	$this->assertEquals(401, $statusCode);
//    	$this->assertNotEmpty($response->getErrorCode());
    	$this->assertNotEmpty($response->getErrorMessage());
    	$this->assertNotEmpty($response->getRequestId());
    }
    
    /**
     * AK/SK为空时抛出异常
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testGetVerifiedDomain_EmptyAkSk(){
    	$config[SesOptions::ACCESS_KEY_ID] = '';
    	$config[SesOptions::ACCESS_KEY_SECRET] = '';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getVerifiedDomain();
    }
    
    /**
     * HOST为空时抛出异常
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testGetVerifiedDomain_EmptyHost(){
    	$config[SesOptions::ENDPOINT] = '';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getVerifiedDomain();
    }
}