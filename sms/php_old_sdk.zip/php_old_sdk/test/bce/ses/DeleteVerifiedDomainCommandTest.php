<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午2:46
 */

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
// use baidubce\ses\model\request\DeleteVerifiedDomain;

class DeleteVerifiedDomainCommandTest extends PHPUnit_Framework_TestCase {

    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    public function testDeleteVerifiedDomain_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	
    	$domain = time().'renren.com';
    	
    	$response = $ses_client->putVerifiedDomain($domain);
    	$this->assertEquals(200, $response->getHttpCode());
    	
    	$response = $ses_client->deleteVerifiedDomain($domain);
        $this->assertEquals(200, $response->getHttpCode());
    }
	
	public function testDeleteVerifiedDomain_domainNotExist(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$domain = time().'1renren.com';
    	$response = $ses_client->deleteVerifiedDomain($domain);
        $this->assertEquals(200, $response->getHttpCode());
    }
    
    /**
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testDeleteVerifiedDomain_EmptyDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->deleteVerifiedDomain();
    }
}
 