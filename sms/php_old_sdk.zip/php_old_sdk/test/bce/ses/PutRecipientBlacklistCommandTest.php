<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午2:46
 */

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
// use baidubce\ses\model\request\DeleteRecipientBlacklist;

class PutRecipientBlacklistCommandTest extends PHPUnit_Framework_TestCase {

    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    public function testPutRecipientBlacklist_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$emailAddress = 'wanglinqing2014@baidu.com';
    	$response = $ses_client->putRecipientBlacklist($emailAddress);
        $this->assertEquals(200, $response->getHttpCode());
    }
    
    /**
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testPutRecipientBlacklist_EmptyEmailAddress(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->putRecipientBlacklist();
    	$this->assertEquals(200, $response->getHttpCode());
    }
}
 