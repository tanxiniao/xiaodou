 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
require_once(__DIR__ . '/../../../baidubce/services/ses/util/SesOptions.php');

use baidubce\ses\util\SesOptions;

class GetUserBlacklistCommand extends PHPUnit_Framework_TestCase {
    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    /**
     * 获取黑名单信息,hgetall qos:blacklist: 56ce66dc36df46769094dfcdc5c688a4
     */
    public function testGetUserBlacklist_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	//set userblacklist
		$userId = '56ce66dc36df46769094dfcdc5c688a5';
    	$response = $ses_client->putUserBlacklist($userId);
    	$this->assertEquals(200, $response->getHttpCode());
		
		//get blacklist
		$response = $ses_client->getUserBlacklist();
        $this->assertEquals(200, $response->getHttpCode());
        $this->assertTrue(is_array($response->getUser()));
    }
    
    public function testGetUserBlacklist_NormalUserId(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$userId = '56ce66dc36df46769094dfcdc5c688a4';
    	$response = $ses_client->getUserBlacklist($userId);
    	$this->assertEquals(200, $response->getHttpCode());
    	$this->assertTrue($response->getExist());
    }
    
//     /**
//      * 获取权限认证失败
//      * @expectedException baidubce\exception\BceServiceException
//      */
//     public function testGetUserBlacklist_AuthFail(){
//     	$config[SesOptions::ACCESS_KEY_ID] = 'notValidAk';
//     	$config[SesOptions::ACCESS_KEY_SECRET] = 'notValidSk';
//     	$ses_client = \baidubce\ses\SesClient::factory($config);
//     	$response = $ses_client->getUserBlacklist();
//     	//断言状态码是200
//     	$statusCode = $response->getHttpCode();
//     	$this->assertEquals(401, $statusCode);
// //    	$this->assertNotEmpty($response->getErrorCode());
//     	$this->assertNotEmpty($response->getErrorMessage());
//     	$this->assertNotEmpty($response->getRequestId());
//     }
    
//     /**
//      * AK/SK为空时抛出异常
//      * @expectedException baidubce\exception\BceServiceException
//      */
//     public function testGetUserBlacklist_EmptyAkSk(){
//     	$config[SesOptions::ACCESS_KEY_ID] = '';
//     	$config[SesOptions::ACCESS_KEY_SECRET] = '';
//     	$ses_client = \baidubce\ses\SesClient::factory($config);
//     	$response = $ses_client->getUserBlacklist();
//     }
    
//     /**
//      * HOST为空时抛出异常
//      * @expectedException baidubce\exception\BceRuntimeException
//      */
//     public function testGetUserBlacklist_EmptyHost(){
//     	$config[SesOptions::ENDPOINT] = '';
//     	$ses_client = \baidubce\ses\SesClient::factory($config);
//     	$response = $ses_client->getUserBlacklist();
//     }
}