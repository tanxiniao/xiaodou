 <?php
/**
 * @file SesBaseTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');

use baidubce\ses\SesClient;
use baidubce\ses\util\SesOptions;

class SesClientTest extends PHPUnit_Framework_TestCase {
    public function setUp(){
		sleep(1);	
    }
    public function tearDown(){}
    
    /**
     */
    public function testClient_Normal(){
//     	$client = SesClient::getInstance();
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$this->assertTrue($ses_client instanceof SesClient);
    }
    
    /**
     */
    public function testClient_SingleInstanceSame(){
//     	$config = SesClient::config();
		$config = array();
    	$client_default_1 = \baidubce\ses\SesClient::factory($config);
    	$client_default_2 = \baidubce\ses\SesClient::factory($config);
// 	    $client_default_1 = SesClient::getInstance($config);
// 	    $client_default_2 = SesClient::getInstance($config);
	    $this->assertFalse($client_default_1 === $client_default_2);
    }
    
    /**
     */
    public function testClient_SingleInstanceNotSame(){
    /*$config = SesClient::config();
    $client_default_1 = SesClient::getInstance($config);
    $config[SesOptions::SECURE_AK_KEY] = 'asdf';
    $client_default_2 = SesClient::getInstance($config);*/
    $config = array();
    $client_default_1 = \baidubce\ses\SesClient::factory($config);
    $config[SesOptions::ACCESS_KEY_ID] = 'asdf';
    $client_default_2 = \baidubce\ses\SesClient::factory($config);
    $this->assertTrue($client_default_1 !== $client_default_2);
    }

}
 