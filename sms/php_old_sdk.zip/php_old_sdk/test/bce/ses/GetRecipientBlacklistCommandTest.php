 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
require_once(__DIR__ . '/../../../baidubce/services/ses/util/SesOptions.php');

use baidubce\ses\util\SesOptions;

class GetRecipientBlacklistCommand extends PHPUnit_Framework_TestCase {
    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    /**
     * 获取黑名单信息,userid:08c52154a494401aaeadfff780fd3d3c    sms04环境
     */
    public function testGetRecipientBlacklist_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		
		$type = 1;
		$enabled = false;
		$email = 'wanglinqing01@baidu.com';
    	$response = $ses_client->putFeedback($type, $enabled, $email);
        $this->assertEquals(200, $response->getHttpCode());
		
		//blacklist adsfdshgfjhkjhlhkjlk@163.com, 01@baidu.com
		sleep(1);
		$response = $ses_client->getRecipientBlacklist();
        $this->assertEquals(200, $response->getHttpCode());
		var_dump($response->getRecpt());
		$this->assertTrue(is_array($response->getRecpt()));
    }
    
    public function testGetRecipientBlacklist_NormalEmailAddress(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$emailAddress = 'adsfdshgfjhkjhlhkjlk@163.com';
    	$response = $ses_client->getRecipientBlacklist($emailAddress);
    	$this->assertEquals(200, $response->getHttpCode());
		var_dump($response->getExist());
    	$this->assertTrue($response->getExist());
    }
    
    /**
     * 获取权限认证失败
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testGetRecipientBlacklist_AuthFail(){
    	$config[SesOptions::ACCESS_KEY_ID] = 'notValidAk';
    	$config[SesOptions::ACCESS_KEY_SECRET] = 'notValidSk';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getRecipientBlacklist();
    	//断言状态码是200
    	$statusCode = $response->getHttpCode();
    	$this->assertEquals(401, $statusCode);
//    	$this->assertNotEmpty($response->getErrorCode());
    	$this->assertNotEmpty($response->getErrorMessage());
    	$this->assertNotEmpty($response->getRequestId());
    }
    
    /**
     * AK/SK为空时抛出异常
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testGetRecipientBlacklist_EmptyAkSk(){
    	$config[SesOptions::ACCESS_KEY_ID] = '';
    	$config[SesOptions::ACCESS_KEY_SECRET] = '';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getRecipientBlacklist();
    }
    
    /**
     * HOST为空时抛出异常
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testGetRecipientBlacklist_EmptyHost(){
    	$config[SesOptions::ENDPOINT] = '';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getRecipientBlacklist();
    }
}