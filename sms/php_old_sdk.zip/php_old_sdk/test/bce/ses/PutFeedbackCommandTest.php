<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午2:46
 */

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
// use baidubce\ses\model\request\DeleteRecipientBlacklist;

class PutFeedbackCommandTest extends PHPUnit_Framework_TestCase {

    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    public function testPutFeedbackCommandTest_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$type = 1;
		$enabled = true;
		$email = 'feedback@sample.com';
    	$response = $ses_client->putFeedback($type, $enabled, $email);
        $this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 * all param empty
	 */
	 public function testPutFeedbackCommandTest_allParamEmpty(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->putFeedback();
    	$this->assertEquals(200, $response->getHttpCode());
    }
    
    /**
     * type is null
     */
    public function testPutFeedbackCommandTest_nullType(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$type = null;
		$enabled = true;
		$email = 'feedback@sample.com';
    	$response = $ses_client->putFeedback($type, $enabled, $email);
    	$this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
     * enable is null
     */
    public function testPutFeedbackCommandTest_nullEnable(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$type = 1;
		$enabled = null;
		$email = 'feedback@sample.com';
    	$response = $ses_client->putFeedback($type, $enabled, $email);
    	$this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
     * email is null
     */
    public function testPutFeedbackCommandTest_nullEmail(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$type = 1;
		$enabled = true;
		$email = null;
    	$response = $ses_client->putFeedback($type, $enabled, $email);
    	$this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
     * no email
     */
    public function testPutFeedbackCommandTest_noEmail(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$type = 1;
		$enabled = true;
    	$response = $ses_client->putFeedback($type, $enabled);
    	$this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testPutFeedbackCommandTest_EmptyType(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$type = '';
		$enabled = true;
		$email = 'feedback@sample.com';
    	$response = $ses_client->putFeedback($type, $enabled, $email);
    	$this->assertEquals(503, $response->getHttpCode());
    }
	
    /**
	 *empty enabled, ok
     */
    public function testPutFeedbackCommandTest_EmptyEnabled(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$type = 1;
		$enabled = '';
		$email = 'feedback@sample.com';
    	$response = $ses_client->putFeedback($type, $enabled, $email);
		$this->assertEquals(200, $response->getHttpCode());
    }
    
    /**
     * empty email,ok
     */
    public function testPutFeedbackCommandTest_EmptyEmail(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$type = 1;
    	$enabled = true;
    	$email = '';
    	$response = $ses_client->putFeedback($type, $enabled, $email);
    	$this->assertEquals(200, $response->getHttpCode());
    }
}
 