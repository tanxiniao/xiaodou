<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午2:46
 */

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
// use baidubce\ses\model\request\DeleteUserBlacklist;

class PutUserBlacklistCommandTest extends PHPUnit_Framework_TestCase {

    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    public function testPutUserBlacklist_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$userId = '56ce66dc36df46769094dfcdc5c688a8';
    	$response = $ses_client->putUserBlacklist($userId);
        $this->assertEquals(200, $response->getHttpCode());
    }
    
    /**
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testPutUserBlacklist_EmptyUserId(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->putUserBlacklist();
    }
}
 