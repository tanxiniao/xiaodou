 <?php
/**
 * @file RequestCommandTest.php
 * @author ronghantao01
 * @date 2014/08/29 16:48:05
 * @brief base env test
 **/

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
require_once(__DIR__ . '/../../../baidubce/services/ses/util/SesOptions.php');

use baidubce\ses\util\SesOptions;

class GetVerifiedEmailCommand extends PHPUnit_Framework_TestCase {
    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    /**
     * 获取全部邮件地址认证信息
     */
    public function testGetVerifiedEmail_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->getVerifiedEmail();
        $this->assertEquals(200, $response->getHttpCode());
        $this->assertTrue(is_array($response->getDetails()));
    }
    
	/**
     * 获取单个邮件地址认证信息
     */
    public function testGetVerifiedEmail_NormalEmailAddress(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$emailAddress = 'wanglinqing2013@163.com';
    	$response = $ses_client->getVerifiedEmail($emailAddress);
    	$this->assertEquals(200, $response->getHttpCode());
		//check data
		$detail = $response->getDetail();
    	$this->assertEquals($emailAddress, $detail->address);
		$this->assertEquals(5, $detail->status);
    }
	
	/**
     * 获取单个邮件地址认证信息，transfer from int to string
     */
    public function testGetVerifiedEmail_intParam(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$emailAddress = 123456;
    	$response = $ses_client->getVerifiedEmail($emailAddress);
    	$this->assertEquals(200, $response->getHttpCode());
		//check data
		$detail = $response->getDetail();
    	$this->assertEquals($emailAddress, $detail->address);
		$this->assertEquals(5, $detail->status);
    }
    
    /**
     * 获取权限认证失败
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testGetVerifiedEmail_AuthFail(){
    	$config[SesOptions::ACCESS_KEY_ID] = 'notValidAk';
    	$config[SesOptions::ACCESS_KEY_SECRET] = 'notValidSk';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getVerifiedEmail();
    	//断言状态码是200
    	$statusCode = $response->getHttpCode();
    	$this->assertEquals(401, $statusCode);
//    	$this->assertNotEmpty($response->getErrorCode());
    	$this->assertNotEmpty($response->getErrorMessage());
    	$this->assertNotEmpty($response->getRequestId());
    }
    
    /**
     * AK/SK为空时抛出异常
     * @expectedException baidubce\exception\BceServiceException
     */
    public function testGetVerifiedEmail_EmptyAkSk(){
    	$config[SesOptions::ACCESS_KEY_ID] = '';
    	$config[SesOptions::ACCESS_KEY_SECRET] = '';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getVerifiedEmail();
    }
    
    /**
     * HOST为空时抛出异常
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testGetVerifiedEmail_EmptyHost(){
    	$config[SesOptions::ENDPOINT] = '';
    	$ses_client = \baidubce\ses\SesClient::factory($config);
    	$response = $ses_client->getVerifiedEmail();
    }
}