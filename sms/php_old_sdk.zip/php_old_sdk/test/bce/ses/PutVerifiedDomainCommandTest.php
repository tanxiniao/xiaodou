<?php
/**
 * Created by PhpStorm.
 * User: shangjiaolong
 * Date: 14-7-7
 * Time: 下午2:46
 */

require_once(__DIR__ . '/../../../baidubce/services/ses/SesClient.php');
// use baidubce\ses\model\request\DeleteVerifiedDomain;
use baidubce\ses\util\SesOptions;

class PutVerifiedDomainCommandTest extends PHPUnit_Framework_TestCase {

    public function setUp(){
		sleep(1);
	}
    public function tearDown(){}

    public function testPutVerifiedDomain_Normal(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$domain = '6ed973d8-20a0-41d7-bd60-b6ee15cc27cb.baidu.com';
    	$response = $ses_client->putVerifiedDomain($domain);
        $this->assertEquals(200, $response->getHttpCode());
		$this->assertNotNull($response->getToken());
    }
    
    /**
     * @expectedException baidubce\exception\BceRuntimeException
     */
    public function testPutVerifiedDomain_NullDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
    	$response = $ses_client->putVerifiedDomain();
    }
	
	/**
     *@expectedException baidubce\exception\BceRuntimeException 
	 *empty domain
     */
    public function testPutVerifiedDomain_emptyDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$domain = '';
    	$response = $ses_client->putVerifiedDomain($domain);
    }
	
	/**
	 *invalid domain
	 *@expectedException baidubce\exception\BceServiceException
     */
    public function testPutVerifiedDomain_invalidDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$domain = 'invaliddomain';
    	$response = $ses_client->putVerifiedDomain($domain);
		$this->assertEquals(204, $response->getHttpCode());
		$this->assertEquals('invalid domain', $response->getErrorMessage());
    }
	
	//domain dkim
	
	/**
	 *verified dkim
	 */
	public function testPutVerifiedDomainDkim_normalDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$domain = 'dom.com';
		$dkim = "dkim";
    	$response = $ses_client->putVerifiedDomain($domain, $dkim);
		$this->assertEquals(200, $response->getHttpCode());
		$this->assertNotNull($response->getToken());
    }
	
	/**
     *@expectedException baidubce\exception\BceRuntimeException 
	 *empty domain
     */
    public function testPutVerifiedDomainDkim_emptyDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$domain = '';
		$dkim = "dkim";
    	$response = $ses_client->putVerifiedDomain($domain, $dkim);
    }
	
	/**
	 *invalid domain
	 *@expectedException baidubce\exception\BceServiceException
     */
    public function testPutVerifiedDomainDkim_invalidDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$domain = 'invaliddomain';
		$dkim = "dkim";
    	$response = $ses_client->putVerifiedDomain($domain, $dkim);
		$this->assertEquals(204, $response->getHttpCode());
		$this->assertEquals('parse sub domain failed', $response->getErrorMessage());
    }
	
	//dkim enable
	/**
	 * enable dkim
	 */
	public function testPutVerifiedDomainDkimEnable_normalDomain(){
    	//verified dkim
		$ses_client = \baidubce\ses\SesClient::factory();
		$domain = 'dom.com';
		$dkim = "dkim";
    	$response = $ses_client->putVerifiedDomain($domain, $dkim);
		$this->assertEquals(200, $response->getHttpCode());
	
		//enable dkim
		$enableDkim = "enableDkim";
    	$response = $ses_client->putVerifiedDomain($domain, $enableDkim);
		$this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 * enable dkim, but dkim not verified
	 *@expectedException baidubce\exception\BceServiceException
	 */
	public function testPutVerifiedDomainDkimEnable_dkimNotVerified(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$domain = time().'dom.com';
		$enableDkim = "enableDkim";
    	$response = $ses_client->putVerifiedDomain($domain, $enableDkim);
		$this->assertEquals(2000, $response->getHttpCode());
    }
	
	/**
     *@expectedException baidubce\exception\BceRuntimeException 
	 *empty domain
     */
    public function testPutVerifiedDomainDkimEnable_emptyDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$domain = '';
		$enableDkim = "enableDkim";
    	$response = $ses_client->putVerifiedDomain($domain, $enableDkim);
    }
	
	/**
	 *invalid domain
	 *@expectedException baidubce\exception\BceServiceException
     */
    public function testPutVerifiedDomainDkimEnable_invalidDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$domain = 'invaliddomain';
		$enableDkim = "enableDkim";
    	$response = $ses_client->putVerifiedDomain($domain, $enableDkim);
		$this->assertEquals(200, $response->getHttpCode());
		$this->assertEquals('parse sub domain failed', $response->getErrorMessage());
    }
	
	//dkim disable
	public function testPutVerifiedDomainDkimDisable_normalDomain(){
    	//verified dkim
		$ses_client = \baidubce\ses\SesClient::factory();
		$domain = 'doc.com';
		$dkim = "dkim";
    	$response = $ses_client->putVerifiedDomain($domain, $dkim);
		$this->assertEquals(200, $response->getHttpCode());
		
		//disable dkim
		$disableDkim = "disableDkim";
    	$response = $ses_client->putVerifiedDomain($domain, $disableDkim);
		$this->assertEquals(200, $response->getHttpCode());
    }
	
	/**
	 * disable dkim, but dkim not verified
	 *@expectedException baidubce\exception\BceServiceException
	 */
	public function testPutVerifiedDomainDkimdisable_dkimNotVerified(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$domain = time().'dom.com';
		$disableDkim = "disableDkim";
    	$response = $ses_client->putVerifiedDomain($domain, $disableDkim);
		$this->assertEquals(2001, $response->getHttpCode());
    }
	
	/**
     *@expectedException baidubce\exception\BceRuntimeException 
	 *empty domain
     */
    public function testPutVerifiedDomainDkimDisable_emptyDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$domain = '';
		$disableDkim = "disableDkim";
    	$response = $ses_client->putVerifiedDomain($domain, $disableDkim);
    }
	
	/**
	 *invalid domain
	 *@expectedException baidubce\exception\BceServiceException
     */
    public function testPutVerifiedDomainDkimDisable_invalidDomain(){
    	$ses_client = \baidubce\ses\SesClient::factory();
		$domain = 'invaliddomain';
		$disableDkim = "disableDkim";
    	$response = $ses_client->putVerifiedDomain($domain, $disableDkim);
		$this->assertEquals(204, $response->getHttpCode());
		$this->assertEquals('parse sub domain failed', $response->getErrorMessage());
    }
}
 