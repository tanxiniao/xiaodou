<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\bos\model\request;

require_once __DIR__ . "/BosCommand.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/Constant.php";
require_once dirname(dirname(__DIR__))."/util/BosConstraint.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))). "/exception/BceIllegalArgumentException.php";

use baidubce\bos\util\BosConstraint;
use baidubce\bos\util\BosOptions;
use baidubce\exception\BceIllegalArgumentException;

class ObjectCommand extends BosCommand {
    protected  $bucket_name;
    protected  $object_name;

    protected function checkOptions($client_options, $options) {
        parent::checkOptions($client_options, $options);
        if (!isset($options[BosOptions::BUCKET])) {
            throw new BceIllegalArgumentException("bucket name not exist in object request");
        }
        if (!isset($options[BosOptions::OBJECT])) {
            throw new BceIllegalArgumentException("object name not exist in object request");
        }

        $this->bucket_name = $options[BosOptions::BUCKET];
        BosConstraint::checkBucketName($this->bucket_name);

        $this->object_name = $options[BosOptions::OBJECT];
        BosConstraint::checkObjectName($this->object_name);
        return true;
    }

    protected  function getRequest($client_options, $options) {
        $request = parent::getRequest($client_options, $options);
        $request->setBucketName($this->bucket_name);
        $request->setObjectName($this->object_name);

        $options = array_change_key_case($options,CASE_LOWER);
        $this->copyHeadersFromOptions($request, array_merge($client_options, $options));
        return $request;
    }
} 