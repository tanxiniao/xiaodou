<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\bos\model\request;

require_once dirname(dirname(dirname(dirname(__DIR__))))."/http/HttpMethod.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/Constant.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringInputStream.php";

use baidubce\exception\BceIllegalArgumentException;
use baidubce\bos\util\BosOptions;
use baidubce\model\stream\BceStringInputStream;
use baidubce\http\HttpMethod;
use baidubce\util\Constant;

require_once __DIR__ . "/ObjectCommand.php";

class MultipartUploadPartId {
    function __construct($etag, $part_number)
    {
        $this->etag = $etag;
        $this->partNumber = $part_number;
    }

    /**
     * @return mixed
     */
    public function getEtag()
    {
        return $this->etag;
    }

    /**
     * @return mixed
     */
    public function getPartNumber()
    {
        return $this->partNumber;
    }
    private $partNumber;
    private $etag;
}

class CompleteMultipartUpload extends ObjectCommand {
    protected function checkOptions($client_options, $options) {
        parent::checkOptions($client_options, $options);

        if (!isset($options[BosOptions::UPLOAD_ID])) {
            throw new BceIllegalArgumentException("miss upload id");
        }
        $this->upload_id = $options[BosOptions::UPLOAD_ID];

        if (!isset($options[BosOptions::PART_LIST])) {
            throw new BceIllegalArgumentException("miss part list");
        }

        $this->part_list = $options[BosOptions::PART_LIST];

        return true;
    }

    protected  function getRequest($client_options, $options) {
        $request = parent::getRequest($client_options, $options);
        $request->setHttpMethod(HttpMethod::HTTP_POST);
        $request->addQueryString("uploadId", $this->upload_id);

        $part_list = array();
        foreach ($this->part_list as $part) {
            $json_part = array();
            $json_part["partNumber"] = $part->getPartNumber();
            $json_part["eTag"] = $part->getEtag();

            array_push($part_list, $json_part);
        }

        $json_body = array();
        $json_body["parts"] = $part_list;

        var_dump($this->part_list);

        $json_body_str = json_encode($json_body);
        echo "============json body================================\n";
        echo $json_body_str;
        echo "=====================================================\n";
        $request->setInputStream(new BceStringInputStream($json_body_str));
        $request->addHttpHeader("content-length", sprintf("%d", strlen($json_body_str)));
        return $request;
    }

    protected  function needHeaderIncludeInRequest($header_key) {
        if (parent::needHeaderIncludeInRequest($header_key)) {
            return true;
        }

        $lower_header_key = strtolower($header_key);

        if (substr($lower_header_key, 0, strlen(Constant::BCE_HEADER_PREFIX)) == Constant::BCE_HEADER_PREFIX) {
            return true;
        }

        if (array_key_exists($lower_header_key, CompleteMultipartUpload::$legal_header_key_set)) {
            return true;
        }

        return false;
    }

    private $upload_id;
    private $part_list;

    public static $legal_header_key_set;
}

CompleteMultipartUpload::$legal_header_key_set = array("content-length" => "", "content-md5" => "");