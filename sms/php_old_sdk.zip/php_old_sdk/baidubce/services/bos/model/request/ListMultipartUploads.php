<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\bos\model\request;

require_once __DIR__ . "/BucketCommand.php";
require_once dirname(dirname(__DIR__))."/util/BosOptions.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/exception/BceIllegalArgumentException.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/http/HttpMethod.php";

use baidubce\http\HttpMethod;
use baidubce\bos\util\BosOptions;
use baidubce\exception\BceIllegalArgumentException;

class ListMultipartUploads extends BucketCommand {
    protected function checkOptions($client_options, $options) {
        parent::checkOptions($client_options, $options);
        if (isset($options[BosOptions::LIST_DELIMITER])) {
            $this->delimiter = $options[BosOptions::LIST_DELIMITER];
        }

        if (isset($options[BosOptions::LIST_MARKER])) {
            $this->marker = $options[BosOptions::LIST_MARKER];
        }

        if (isset($options[BosOptions::LIST_MAX_UPLOAD_SIZE])) {
            if(is_string($options[BosOptions::LIST_MAX_UPLOAD_SIZE])){
                throw new BceIllegalArgumentException("LIST_MAX_KEY_SIZE should be int type");
            }

            $this->max_uploads = $options[BosOptions::LIST_MAX_UPLOAD_SIZE];
            if ($this->max_uploads > 1000 or $this->max_uploads < 0) {
                throw new BceIllegalArgumentException("LIST_MAX_KEY_SIZE must less than 1000");
            }
        }

        if (isset($options[BosOptions::LIST_PREFIX])) {
            $this->prefix = $options[BosOptions::LIST_PREFIX];
        }

        return true;
    }
    protected  function getRequest($client_options, $options) {
        $request = parent::getRequest($client_options, $options);
        $request->setHttpMethod(HttpMethod::HTTP_GET);
        $request->addQueryString("uploads", "");
        if (isset($this->delimiter)) {
            $request->addQueryString("delimiter", $this->delimiter);
        }

        if (isset($this->marker) ) {
            $request->addQueryString("keyMarker", $this->marker);
        }

        if (isset($this->max_uploads)) {
            $request->addQueryString("maxUploads", $this->max_uploads);
        }

        if (isset($this->prefix) ) {
            $request->addQueryString("prefix", sprintf("%s", $this->prefix));
        }

        return $request;
    }

    private $delimiter;
    private $marker;

    /**
     * @return mixed
     */
    public function getDelimiter()
    {
        return $this->delimiter;
    }

    /**
     * @return mixed
     */
    public function getMarker()
    {
        return $this->marker;
    }

    /**
     * @return mixed
     */
    public function getMaxUploads()
    {
        return $this->max_uploads;
    }

    /**
     * @return mixed
     */
    public function getPrefix()
    {
        return $this->prefix;
    }
    private $max_uploads;
    private $prefix;
} 
