<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\bos\model\request;

use baidubce\exception\BceIllegalArgumentException;
use baidubce\bos\util\BosOptions;
use baidubce\bos\util\BosConstraint;
use baidubce\util\Constant;
use baidubce\http\HttpMethod;

require_once __DIR__ . "/ObjectCommand.php";
require_once dirname(dirname(__DIR__))."/util/BosConstraint.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/Constant.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/http/HttpMethod.php";

class CopyObject extends ObjectCommand {
    protected function checkOptions($client_options, $options) {
        parent::checkOptions($client_options, $options);

        if (!isset($options[BosOptions::OBJECT_COPY_SOURCE])) {
            throw new BceIllegalArgumentException("must have x-bce-copy-source in copy request");
        }

        $copy_source_items = explode("/", $options[BosOptions::OBJECT_COPY_SOURCE], 3);
        print_r($copy_source_items);
        if (count($copy_source_items) != 3) {
            throw new BceIllegalArgumentException("x-bce-copy-source format error");
        }

        if ($copy_source_items[0] != "") {
            throw new BceIllegalArgumentException("x-bce-copy-source format error");
        }

        $bucket_name = $copy_source_items[1];
        $object_name = $copy_source_items[2];

        BosConstraint::checkBucketName($bucket_name);
        BosConstraint::checkObjectName($object_name);

        $this->copy_source = $options[BosOptions::OBJECT_COPY_SOURCE];

        if (isset($options[BosOptions::OBJECT_COPY_SOURCE_IF_MATCH_TAG])) {
            $this->if_match_tag = $options[BosOptions::OBJECT_COPY_SOURCE_IF_MATCH_TAG];
        } else {
            $this->if_match_tag = NULL;
        }

        if (isset($options[BosOptions::OBJECT_COPY_METADATA_DIRECTIVE])) {
            $this->metadata_directive = $options[BosOptions::OBJECT_COPY_METADATA_DIRECTIVE];
            if ($this->metadata_directive != "copy" && $this->metadata_directive != "replace") {
                throw new BceIllegalArgumentException("Illega copy metadata directive, should be copy or replace");
            }
        } else {
            $this->metadata_directive = NULL;
        }

        return true;
    }

    protected  function getRequest($client_options, $options) {
        $request = parent::getRequest($client_options, $options);
        $request->setHttpMethod(HttpMethod::HTTP_PUT);
        $request->addHttpHeader("x-bce-copy-source", $this->copy_source);

        if (!is_null($this->if_match_tag)) {
            $request->addHttpHeader("x-bce-copy-source-if-match", $this->if_match_tag);
        }

        if (!is_null($this->metadata_directive)) {
            $request->addHttpHeader("x-bce-metadata-directive", $this->metadata_directive);
        }

        $request->addHttpHeader("content-length", "0");

        return $request;
    }

    protected  function needHeaderIncludeInRequest($header_key) {
        if (parent::needHeaderIncludeInRequest($header_key)) {
            return true;
        }

        $lower_header_key = strtolower($header_key);

        if (substr($lower_header_key, 0, strlen(Constant::BCE_HEADER_PREFIX)) == Constant::BCE_HEADER_PREFIX) {
            return true;
        }

        if (array_key_exists($lower_header_key, CopyObject::$legal_header_key_set)) {
            return true;
        }

        return false;
    }

    private $copy_source;
    private $if_match_tag;
    private $metadata_directive;

    public static $legal_header_key_set;
}

CopyObject::$legal_header_key_set = array("content-type" => "");