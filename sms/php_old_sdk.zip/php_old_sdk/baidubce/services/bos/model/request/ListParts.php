<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\bos\model\request;
require_once __DIR__ . "/ObjectCommand.php";
require_once __DIR__ . "/MultipartUploadCommand.php";

use baidubce\bos\util\BosOptions;
use baidubce\http\HttpMethod;
use baidubce\exception\BceIllegalArgumentException;
use baidubce\bos\model\request\MultipartUploadCommand;

class ListParts extends MultipartUploadCommand {
    private $max_parts;

    /**
     * @return mixed
     */
    public function getPartsMarker()
    {
        return $this->parts_marker;
    }

    /**
     * @return mixed
     */
    public function getMaxParts()
    {
        return $this->max_parts;
    }
    private $parts_marker;

    protected function checkOptions($client_options, $options) {
        parent::checkOptions($client_options, $options);

        if (isset($options[BosOptions::MAX_PARTS_COUNT])) {
            if(is_string($options[BosOptions::MAX_PARTS_COUNT])){
                throw new BceIllegalArgumentException("MAX_PARTS_COUNT should be int type");
            }
            $this->max_parts = $options[BosOptions::MAX_PARTS_COUNT];
            if ($this->max_parts < 0 || $this->max_parts > 1000) {
                throw new BceIllegalArgumentException("MAX_PARTS_COUNT must between 0 and 1000");
            }
        }

        if (isset($options[BosOptions::PART_NUMBER_MARKER])) {
            $this->parts_marker = $options[BosOptions::PART_NUMBER_MARKER];
        }

        return true;
    }

    protected  function getRequest($client_options, $options) {
        $request = parent::getRequest($client_options, $options);
        $request->setHttpMethod(HttpMethod::HTTP_GET);

        //before change:$this->max_parts != NULL
        if (!is_null($this->max_parts)) {
            $request->addQueryString("maxParts", sprintf("%d", $this->max_parts));
        }

        if (!is_null($this->parts_marker)) {
            $request->addQueryString("partNumberMarker", $this->parts_marker);
        }

        return $request;
    }
} 
