<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\bos\model\request;

require_once __DIR__ . "/BucketCommand.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringInputStream.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/http/HttpMethod.php";

use baidubce\bos\util\BosOptions;
use baidubce\model\stream\BceStringInputStream;
use baidubce\http\HttpMethod;

class CreateBucket extends BucketCommand {
    protected function checkOptions($client_options, $options) {
        parent::checkOptions($client_options, $options);
        if (isset($options[BosOptions::BUCKET_LOCATION])) {
            $this->location_constraint = $options[BosOptions::BUCKET_LOCATION];
        } else {
            $this->location_constraint = "cn-n1";
        }
        return true;
    }

    protected  function getRequest($client_options, $options) {
        $request = parent::getRequest($client_options, $options);
        $request->setHttpMethod(HttpMethod::HTTP_PUT);
        $bucket_config = sprintf("{\"locationConstraint\": \"%s\"}", $this->location_constraint);
        $request->setInputStream(new BceStringInputStream($bucket_config));
        $request->addHttpHeader("content-length", strlen($bucket_config));
        $request->addHttpHeader("x-bce-content-sha256", hash("sha256", $bucket_config));

        return $request;
    }
    private $location_constraint;
} 