<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\bos\model\request;

require_once __DIR__ . "/ObjectCommand.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/auth/Auth.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/Constant.php";
require_once dirname(dirname(__DIR__))."/util/BosConstraint.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))). "/model/stream/BceStringInputStream.php";

use baidubce\http\HttpMethod;

class GetObject extends ObjectCommand {
    protected function checkOptions($client_options, $options) {
        parent::checkOptions($client_options, $options);

        return true;
    }

    protected  function getRequest($client_options, $options) {
        $request = parent::getRequest($client_options, $options);
        $request->setHttpMethod(HttpMethod::HTTP_GET);

        return $request;
    }

    protected  function needHeaderIncludeInRequest($header_key) {
        if (parent::needHeaderIncludeInRequest($header_key)) {
            return true;
        }

        $lower_header_key = strtolower($header_key);
        if (array_key_exists($lower_header_key, GetObject::$legal_header_key_set)) {
            return true;
        }

        return false;
    }

    public static $legal_header_key_set;
}

GetObject::$legal_header_key_set = array("range" => "");