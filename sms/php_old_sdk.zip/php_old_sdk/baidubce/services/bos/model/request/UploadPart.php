<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\bos\model\request;;

use baidubce\bos\util\BosOptions;
use baidubce\exception\BceIllegalArgumentException;

require_once __DIR__ . "/PutObject.php";

class UploadPart extends PutObject {
    protected function checkOptions($client_options, $options) {
        parent::checkOptions($client_options, $options);

        if (!isset($options[BosOptions::UPLOAD_ID])) {
            throw new BceIllegalArgumentException("miss upload id");
        }
        $this->upload_id = $options[BosOptions::UPLOAD_ID];

        if (!isset($options[BosOptions::PART_NUM])) {
            throw new BceIllegalArgumentException("miss part number");
        }
        $this->part_num = $options[BosOptions::PART_NUM];
        if (!is_int($this->part_num)) {
            throw new BceIllegalArgumentException("part number must be a positive integer less than 10000");
        }

        if ((int)$this->part_num > 10000 || (int)$this->part_num < 0) {
            throw new BceIllegalArgumentException("part number must be a positive integer less than 10000");
        }

        return true;
    }
    protected  function getRequest($client_options, $options) {
        $request = parent::getRequest($client_options, $options);
        $request->addQueryString("partNumber", $this->part_num);
        $request->addQueryString("uploadId", $this->upload_id);

        return $request;
    }

    private $upload_id;
    private $part_num;
} 