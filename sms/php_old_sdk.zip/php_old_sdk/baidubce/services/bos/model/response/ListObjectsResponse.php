<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
namespace baidubce\bos\model\response;

require_once dirname(dirname(__DIR__)) . "/BosResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/Time.php";

use baidubce\bos\service\BosResponse;
use baidubce\util\Time;
use baidubce\model\stream\BceStringOutputStream;

class ListObjectObjectInfo {

    private $prefix;
    private  $sub_object_name;
    private $last_modified;
    private $etag;
    private $size;
    private $owner_id;
    private $owner_name;

    function __construct($prefix, $sub_object_name, $last_modified, $etag, $size, $owner_id, $owner_name)
    {
        $this->prefix = $prefix;
        $this->etag = $etag;
        $this->last_modified = $last_modified;
        $this->sub_object_name = $sub_object_name;
        $this->owner_id = $owner_id;
        $this->owner_name = $owner_name;
        $this->size = $size;
    }

    public function getObjectName() {
        return $this->sub_object_name;
    }

    /**
     * @return mixed
     */
    public function getPrefix()
    {
        return $this->prefix;
    }
    /**
     * @return mixed
     */
    public function getEtag()
    {
        return $this->etag;
    }

    /**
     * @return mixed
     */
    public function getLastModified()
    {
        return $this->last_modified;
    }

    /**
     * @return mixed
     */
    public function getOwnerId()
    {
        return $this->owner_id;
    }

    /**
     * @return mixed
     */
    public function getOwnerName()
    {
        return $this->owner_name;
    }

    /**
     * @return mixed
     */
    public function getSize()
    {
        return $this->size;
    }
}

class ListObjectCommonPrefix {
    private $prefix;

    function __construct($prefix)
    {
        $this->prefix = $prefix;
    }

    /**
     * @return mixed
     */
    public function getPrefix()
    {
        return $this->prefix;
    }
}

class ListObjectsResponse extends BosResponse {
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
        $this->object_list = array();
        $this->common_prefix_list = array();
    }

    public function parseResponse() {
        parent::parseResponse();

        $list_object_result = json_decode($this->getOutputStream()->readAll());
        $this->bucket_name = $list_object_result->name;
        $this->prefix = $list_object_result->prefix;
        if (isset($list_object_result->delimiter)) {
            $this->delimiter = $list_object_result->delimiter;
        }
        $this->marker = $list_object_result->marker;
        $this->max_keys = $list_object_result->maxKeys;
        if (isset($list_object_result->nextMarker)) {
            $this->next_marker = $list_object_result->nextMarker;
        }
        if ($list_object_result->isTruncated == "true") {
            $this->is_truncated = true;
        } else {
            $this->is_truncated = false;
        }

        $object_list = $list_object_result->contents;
        foreach ($object_list as $object) {
            $sub_object_name = $object->key;
            $last_modified = Time::BceTimeToDateTime($object->lastModified);
            $etag = $object->eTag;
            $size = $object->size;
            $owner_id = $object->owner->id;
            $owner_name = $object->owner->displayName;

            array_push($this->object_list, new ListObjectObjectInfo($this->prefix, $sub_object_name, $last_modified, $etag, $size, $owner_id, $owner_name));
        }
        if (isset($list_object_result->commonPrefixes)) {
            $common_prefix_list = $list_object_result->commonPrefixes;
            foreach($common_prefix_list as $common_prefix) {
                $prefix = $common_prefix->prefix;
                array_push($this->common_prefix_list, new ListObjectCommonPrefix($prefix));
            }
        }
    }

    private $bucket_name;
    private $prefix;
    private $delimiter;
    private $marker;
    private $max_keys;
    private $is_truncated;
    private $object_list;
    private $common_prefix_list;
    private $next_marker;

    /**
     * @return mixed
     */
    public function getNextMarker()
    {
        return $this->next_marker;
    }

    /**
     * @return mixed
     */
    public function getCommonPrefixList()
    {
        return $this->common_prefix_list;
    }

    /**
     * @return mixed
     */
    public function getBucketName()
    {
        return $this->bucket_name;
    }

    /**
     * @return mixed
     */
    public function getDelimiter()
    {
        return $this->delimiter;
    }

    /**
     * @return mixed
     */
    public function isTruncated()
    {
        return $this->is_truncated;
    }

    /**
     * @return mixed
     */
    public function getMarker()
    {
        return $this->marker;
    }

    /**
     * @return mixed
     */
    public function getMaxKeys()
    {
        return $this->max_keys;
    }

    /**
     * @return mixed
     */
    public function getObjectList()
    {
        return $this->object_list;
    }

    /**
     * @return mixed
     */
    public function getPrefix()
    {
        return $this->prefix;
    }
} 