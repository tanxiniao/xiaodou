<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
namespace baidubce\bos\model\response;

require_once dirname(dirname(__DIR__)) . "/BosResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";

use baidubce\bos\service\BosResponse;
use baidubce\model\stream\BceStringOutputStream;

class CompleteMultipartUploadResponse extends BosResponse {
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
    }

    public function parseResponse() {
        parent::parseResponse();

        $complete_multipart_upload_result = json_decode($this->getOutputStream()->readAll());
        $this->location = $complete_multipart_upload_result->location;
        $this->bucket_name = $complete_multipart_upload_result->bucket;
        $this->object_name = $complete_multipart_upload_result->key;
        $this->etag = str_replace('"',"",$complete_multipart_upload_result->eTag);
    }

    /**
     * @return mixed
     */
    public function getBucketName()
    {
        return $this->bucket_name;
    }

    /**
     * @return mixed
     */
    public function getEtag()
    {
        return $this->etag;
    }

    /**
     * @return mixed
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * @return mixed
     */
    public function getObjectName()
    {
        return $this->object_name;
    }

    private $location;
    private $bucket_name;
    private $object_name;
    private $etag;
} 
