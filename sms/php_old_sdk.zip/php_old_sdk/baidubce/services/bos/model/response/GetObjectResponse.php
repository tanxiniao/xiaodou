<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
namespace baidubce\bos\model\response;

require_once dirname(dirname(__DIR__)) . "/BosResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/Constant.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";

use baidubce\bos\service\BosResponse;
use baidubce\util\Constant;
use baidubce\bos\util\BosOptions;
use baidubce\model\stream\BceStringOutputStream;
use baidubce\exception\BceIllegalArgumentException;

class GetObjectResponse extends BosResponse {

    function __construct($options) {
        $output_stream = NULL;
        if (isset($options[BosOptions::OBJECT_CONTENT_STREAM])) {
            $output_stream = $options[BosOptions::OBJECT_CONTENT_STREAM];
        } else {
            $output_stream = new BceStringOutputStream();
        }

        parent::__construct($output_stream);
    }

    function getContent() {
        return $this->getOutputStream()->readAll();
    }

    function getContentStream() {
        $caculatedMD5 = md5(base64_encode($this->getOutputStream()));
        if($this->getETag() == $caculatedMD5){
            return $this->getOutputStream();
        }else{
            throw new BceIllegalArgumentException("wrong etag");
        }

    }

    public function parseResponse() {
        parent::parseResponse();
        $http_header = $this->getHttpHeaders();
        if (array_key_exists("ETag", $http_header)) {
            $this->ETag = str_replace('"',"",$http_header["ETag"]);
        }
    }

    public function getContentRange() {
        return $this->getResponseHeader("Content-Range");
    }

    public function getContentLength() {
        return $this->getResponseHeader("Content-Length");
    }

    public function getObjectMeta() {
        $http_response_header = $this->getHttpHeaders();

        $object_meta = array();
        foreach ($http_response_header as $key => $val) {
            if (substr($key, 0, strlen(Constant::BCE_OBJECT_META_HEADER_PREFIX)) == Constant::BCE_OBJECT_META_HEADER_PREFIX) {
                $object_meta[$key] = $val;
            }
        }

        return $object_meta;
    }

    private $ETag;

    /**
     * @return mixed
     */
    public function getETag()
    {
        return $this->ETag;
    }
} 
