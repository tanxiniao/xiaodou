<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
namespace baidubce\bos\model\response;

require_once dirname(dirname(__DIR__)) . "/BosResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/Time.php";

use baidubce\bos\service\BosResponse;
use baidubce\util\Time;
use baidubce\model\stream\BceStringOutputStream;

class ListMultipartUploadsUploadInfo {

    private $object_name;
    private $upload_id;
    private $initiated_time;
    private $owner_id;
    private $owner_name;

    function __construct($initiated_time, $object_name, $owner_id, $owner_name, $upload_id)
    {
        $this->initiated_time = $initiated_time;
        $this->object_name = $object_name;
        $this->owner_id = $owner_id;
        $this->owner_name = $owner_name;
        $this->upload_id = $upload_id;
    }

    /**
     * @return mixed
     */
    public function getInitiatedTime()
    {
        return $this->initiated_time;
    }

    /**
     * @return mixed
     */
    public function getObjectName()
    {
        return $this->object_name;
    }

    /**
     * @return mixed
     */
    public function getOwnerId()
    {
        return $this->owner_id;
    }

    /**
     * @return mixed
     */
    public function getOwnerName()
    {
        return $this->owner_name;
    }

    /**
     * @return mixed
     */
    public function getUploadId()
    {
        return $this->upload_id;
    }


}

class ListMultipartUploadsResponse extends  BosResponse {
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
        $this->common_prefix_list = array();
        $this->upload_list = array();
    }

    public function parseResponse() {
        parent::parseResponse();

        $response_body = $this->getOutputStream()->readAll();
        $list_multipart_uploads_result = json_decode($response_body);

        $this->bucket_name = $list_multipart_uploads_result->bucket;

        if (isset($list_multipart_uploads_result->prefix)) {
            $this->prefix = $list_multipart_uploads_result->prefix;
        }

        if (isset($list_multipart_uploads_result->delimiter)) {
            $this->delimiter = $list_multipart_uploads_result->delimiter;
        }

        if (isset($list_multipart_uploads_result->keyMarker)) {
            $this->key_marker =  $list_multipart_uploads_result->keyMarker;
        }

        if (isset($list_multipart_uploads_result->nextKeyMarker)) {
            $this->next_key_marker = $list_multipart_uploads_result->nextKeyMarker;
        }

        $this->max_uploads = $list_multipart_uploads_result->maxUploads;

        $this->is_truncated = $list_multipart_uploads_result->isTruncated == "true" ? true : false;

        $contents = $list_multipart_uploads_result->uploads;
        foreach ($contents as $upload_info) {
            $object_name = $upload_info->key;
            $upload_id = $upload_info->uploadId;
            $owner_id = $upload_info->owner->id;
            $owner_name = $upload_info->owner->displayName;
            $initiated_time = Time::BceTimeToDateTime($upload_info->initiated);

            array_push($this->upload_list, new ListMultipartUploadsUploadInfo($initiated_time, $object_name, $owner_id, $owner_name, $upload_id));
        }

        if (isset($list_multipart_uploads_result->commonPrefixes)) {
            $common_prefixes_list = $list_multipart_uploads_result->commonPrefixes;
            foreach($common_prefixes_list as $common_prefix) {
                array_push($this->common_prefix_list, $common_prefix->prefix);
            }
        }
    }

    /**
     * @return mixed
     */
    public function getPrefix()
    {
        return $this->prefix;
    }

    private $bucket_name;
    private $key_marker;
    private $next_key_marker;
    private $max_uploads;
    private $is_truncated;
    private $prefix;
    private $upload_list;
    private $common_prefix_list;
    private $delimiter;

    /**
     * @return mixed
     */
    public function getDelimiter()
    {
        return $this->delimiter;
    }

    /**
     * @return mixed
     */
    public function getBucketName()
    {
        return $this->bucket_name;
    }

    /**
     * @return array
     */
    public function getCommonPrefixList()
    {
        return $this->common_prefix_list;
    }

    /**
     * @return mixed
     */
    public function getIsTruncated()
    {
        return $this->is_truncated;
    }

    /**
     * @return mixed
     */
    public function getKeyMarker()
    {
        return $this->key_marker;
    }

    /**
     * @return mixed
     */
    public function getMaxUploads()
    {
        return $this->max_uploads;
    }

    /**
     * @return mixed
     */
    public function getNextKeyMarker()
    {
        return $this->next_key_marker;
    }

    /**
     * @return array
     */
    public function getUploadList()
    {
        return $this->upload_list;
    }

} 