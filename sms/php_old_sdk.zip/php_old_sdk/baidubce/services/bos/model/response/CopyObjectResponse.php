<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\bos\model\response;

require_once dirname(dirname(__DIR__)) . "/BosResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/Time.php";

use baidubce\util\Time;
use baidubce\model\stream\BceStringOutputStream;
use baidubce\bos\service\BosResponse;

class CopyObjectResponse extends BosResponse {
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
    }

    public function parseResponse() {
        parent::parseResponse();
        $copy_object_result = json_decode($this->getOutputStream()->readAll());
        $this->dest_etag = $copy_object_result->eTag;
        $this->dest_last_modify = $copy_object_result->lastModified;
    }

    private $dest_etag;
    private $dest_last_modify;

    /**
     * @return mixed
     */
    public function getDestEtag()
    {
        return $this->dest_etag;
    }

    /**
     * @return mixed
     */
    public function getDestLastModify()
    {
        var_dump( $this->dest_last_modify);
        return Time::BceTimeToDateTime($this->dest_last_modify);
    }
} 
