<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
namespace baidubce\bos\model\response;

require_once dirname(dirname(__DIR__)) . "/BosResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/Time.php";

use baidubce\bos\service\BosResponse;
use baidubce\util\Time;
use baidubce\model\stream\BceStringOutputStream;

class ListBucketBucketInfo {
    private $bucket_name;
    private $create_time;

    function __construct($bucket_name, $create_time) {
        $this->bucket_name = $bucket_name;
        $this->create_time = $create_time;
    }

    /**
     * @return mixed
     */
    public function getBucketName()
    {
        return $this->bucket_name;
    }

    /**
     * @return mixed
     */
    public function getCreateTime()
    {
        return $this->create_time;
    }
}
class ListBucketsResponse extends BosResponse {
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
        $this->bucket_list = array();
    }

    public function parseResponse() {
        parent::parseResponse();

        $list_bucket_result = json_decode($this->getOutputStream()->readAll());

        $this->owner_id = $list_bucket_result->owner->id;
        $this->owner_display_name = $list_bucket_result->owner->displayName;

        $bucket_list = $list_bucket_result->buckets;
        foreach ($bucket_list as $bucket) {
            $bucket_name = $bucket->name;
            $bucket_create_time = Time::BceTimeToDateTime($bucket->creationDate);

            array_push($this->bucket_list, new ListBucketBucketInfo($bucket_name, $bucket_create_time));
        }
    }

    /**
     * @return array
     */
    public function getBucketList()
    {
        return $this->bucket_list;
    }

    /**
     * @return mixed
     */
    public function getOwnerDisplayName()
    {
        return $this->owner_display_name;
    }

    /**
     * @return mixed
     */
    public function getOwnerId()
    {
        return $this->owner_id;
    }

    private  $owner_id;
    private $owner_display_name;
    private $bucket_list;
} 