<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
namespace baidubce\bos\model\response;

require_once dirname(dirname(__DIR__)) . "/BosResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))). "/model/stream/BceStringOutputStream.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/Time.php";

use baidubce\bos\service\BosResponse;
use baidubce\util\Time;
use baidubce\model\stream\BceStringOutputStream;

class ListPartsPartInfo {
    private $part_number;
    private $last_modified;
    private $etag;
    private $size;

    function __construct($etag, $last_modified, $part_number, $size)
    {
        $this->etag = $etag;
        $this->last_modified = $last_modified;
        $this->part_number = $part_number;
        $this->size = $size;
    }

    /**
     * @return mixed
     */
    public function getEtag()
    {
        return $this->etag;
    }

    /**
     * @return mixed
     */
    public function getLastModified()
    {
        return $this->last_modified;
    }

    /**
     * @return mixed
     */
    public function getPartNumber()
    {
        return $this->part_number;
    }

    /**
     * @return mixed
     */
    public function getSize()
    {
        return $this->size;
    }

}

class ListPartsResponse extends BosResponse {
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
        $this->part_info = array();
    }

    public function parseResponse() {
        parent::parseResponse();

        $list_parts_result = json_decode($this->getOutputStream()->readAll());
        $this->bucket_name = $list_parts_result->bucket;
        $this->object_name = $list_parts_result->key;
        $this->upload_id = $list_parts_result->uploadId;
        if(isset($list_parts_result->maxParts)){
            $this->max_parts = $list_parts_result->maxParts;
        }

        $this->initiated_time = Time::BceTimeToDateTime($list_parts_result->initiated);
        $this->owner_id = $list_parts_result->owner->id;
        $this->owner_name = $list_parts_result->owner->displayName;
        $this->part_number_marker = $list_parts_result->partNumberMarker;
        $this->next_part_number_marker = $list_parts_result->nextPartNumberMarker;
        $this->is_truncated = $list_parts_result->isTruncated == "true" ? true : false;

        $parts_list = $list_parts_result->parts;
        foreach ($parts_list as $part) {
            $part_number = $part->partNumber;
            $last_modified = Time::BceTimeToDateTime($part->lastModified);
            $etag = str_replace('"',"",$part->eTag);
            $size = $part->size;

            array_push($this->part_info, new ListPartsPartInfo($etag, $last_modified, $part_number, $size));
        }
    }

    /**
     * @return mixed
     */
    public function getBucketName()
    {
        return $this->bucket_name;
    }

    /**
     * @return mixed
     */
    public function getInitiatedTime()
    {
        return $this->initiated_time;
    }

    /**
     * @return mixed
     */
    public function getIsTruncated()
    {
        return $this->is_truncated;
    }

    /**
     * @return mixed
     */
    public function getMaxParts()
    {
        return $this->max_parts;
    }

    /**
     * @return mixed
     */
    public function getNextPartNumberMarker()
    {
        return $this->next_part_number_marker;
    }

    /**
     * @return mixed
     */
    public function getObjectName()
    {
        return $this->object_name;
    }

    /**
     * @return mixed
     */
    public function getOwnerId()
    {
        return $this->owner_id;
    }

    /**
     * @return mixed
     */
    public function getOwnerName()
    {
        return $this->owner_name;
    }

    /**
     * @return mixed
     */
    public function getPartInfo()
    {
        return $this->part_info;
    }

    /**
     * @return mixed
     */
    public function getPartNumberMarker()
    {
        return $this->part_number_marker;
    }

    /**
     * @return mixed
     */
    public function getUploadId()
    {
        return $this->upload_id;
    }



    private $bucket_name;
    private $object_name;
    private $upload_id;
    private $initiated_time;
    private $owner_name;
    private $owner_id;
    private $part_number_marker;
    private $next_part_number_marker;
    private $max_parts;
    private $is_truncated;
    private $part_info;

} 
