<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
namespace baidubce\bos\model\response;

require_once dirname(dirname(__DIR__)) . "/BosResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))). "/model/stream/BceStringOutputStream.php";

use baidubce\bos\service\BosResponse;
use baidubce\model\stream\BceStringOutputStream;

class ShowAccessControlList {
    private $grantee_name;
    private $grantee_id;
    private $permission;

    /**
     * @return mixed
     */
    public function getGranteeId()
    {
        return $this->grantee_id;
    }

    /**
     * @return mixed
     */
    public function getGranteeName()
    {
        return $this->grantee_name;
    }

    /**
     * @return mixed
     */
    public function getPermission()
    {
        return $this->permission;
    }

    function  __construct($grantee_id, $grantee_name, $permission){
        $this->grantee_id = $grantee_id;
        $this->grantee_name = $grantee_name;
        $this->permission = $permission;
    }
}


class GetBucketAclResponse extends BosResponse {
    function  __construct($option){
        parent::__construct(new BceStringOutputStream());
        $this->acl = array();

    }

    public function parseResponse(){
        parent::parseResponse();

        $get_bucket_acl_result = json_decode($this->getOutputStream()->readAll());
        $this->owner_name = $get_bucket_acl_result->owner->displayName;
        $this->owner_id = $get_bucket_acl_result->owner->id;
        $access_control_list = $get_bucket_acl_result->accessControlList;

        foreach ($access_control_list as $access_control){
            $grantee_id = $access_control->grantee->id;
            $grantee_name = $access_control->grantee->displayName;
            $permission = $access_control->permission;

            array_push($this->acl, new ShowAccessControlList($grantee_id,$grantee_name,$permission));
        }
    }

    private $acl;
    private $owner_name;
    private $owner_id;


    /**
     * @return mixed
     */
    public function getAcl()
    {
        return $this->acl;
    }

    /**
     * @return mixed
     */
    public function getOwnerId()
    {
        return $this->owner_id;
    }

    /**
     * @return mixed
     */
    public function getOwnerName()
    {
        return $this->owner_name;
    }

}
