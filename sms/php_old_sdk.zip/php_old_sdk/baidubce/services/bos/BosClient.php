<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
namespace baidubce\bos;

require_once __DIR__ . "/BosClient.php";
require_once __DIR__ . "/util/BosOptions.php";
require_once __DIR__ . "/BosHttpClient.php";

require_once dirname(dirname(__DIR__)) . "/model/stream/BceFileOutputStream.php";
require_once dirname(dirname(__DIR__)) . "/model/stream/BceFileInputStream.php";
require_once dirname(dirname(__DIR__)) . "/auth/Auth.php";


use baidubce\bos\util\BosOptions;
use baidubce\bos\service\BosHttpClient;
use baidubce\auth\Auth;
use baidubce\http\HttpMethod;
use baidubce\bos\model\request\MultipartUploadPartId;
use baidubce\exception\BceIllegalArgumentException;
use baidubce\model\stream\BceFileOutputStream;
use baidubce\model\stream\BceFileInputStream;

class BosClient {
    static function factory(array $config) {
        return new static($config);
    }

    public function putObject(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function getObject(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function deleteObject(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function copyObject(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function getObjectMetadata(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function createBucket(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function listBuckets(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function listObjects(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function doesBucketExist(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function deleteBucket(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function setBucketAcl(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function getBucketAcl(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function initiateMultipartUpload(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function uploadPart(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function completeMultipartUpload(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function abortMultipartUpload(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function listParts(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function listMultipartUploads(array $options) {
        $response = $this->execute(__FUNCTION__, $options);
        return $response;
    }

    public function generatePresignedUrl($bucket, $key, $expires = NULL, array $args = array()) {
        $uri = sprintf("/v1/%s/%s", $bucket, $key);

        if ($expires == NULL || !is_int($expires) || $expires <= 0) {
            $expires = 1800;
        }

        $signed_headers = array("host");
        $headers = array();
        $headers["host"] = $this->endpoint;

        if ($args == NULL) {
            $args = array();
        }

        $auth = new Auth($this->ak, $this->sk);
        $authorization_string = $auth->generateAuthorizationWithSignedHeaders(HttpMethod::HTTP_GET, $uri, $headers, $signed_headers, $args, $expires);

        $args["authorization"] = $authorization_string;

        $query_string = "";
        foreach($args as $query_string_key => $query_string_data) {
            if ($query_string == "") {
                $query_string = sprintf("%s=%s", $query_string_key, rawurlencode($query_string_data));
            } else {
                $query_string = sprintf("%s&%s=%s", $query_string, $query_string_key, rawurlencode($query_string_data));
            }
        }

        return sprintf("http://%s%s?%s", $this->endpoint, $uri, $query_string);
    }

    public  function __construct(array $config) {
        $this->ak = $config[BosOptions::ACCESS_KEY_ID];
        $this->sk = $config[BosOptions::ACCESS_KEY_SECRET];
        $this->endpoint = $config[BosOptions::ENDPOINT];
        // $this->charset = $config[BosOptions::CHARSET];

        $this->client_options = $config;
        $this->service_client = new BosHttpClient($config);
    }

    protected function lowercaseKeys($array){
        $newArray = array();

        $object_meta_prefix = "x-bce-meta-";
        $object_meta_prefix_size = strlen($object_meta_prefix);

        foreach($array as $key=>$value){
            if("content-length" == strtolower($key)){
                $newArray[strtolower($key)] = $value;
            }if("content-type" == strtolower($key)){
                $newArray[strtolower($key)] = $value;
            }if("content-md5" == strtolower($key)){
                $newArray[strtolower($key)] = $value;
            }if("range" == strtolower($key)){
                $newArray[strtolower($key)] = $value;
            }if("x-bce-content-sha256" == strtolower($key)){
                $newArray[strtolower($key)] = $value;
            }if(strncmp($object_meta_prefix, strtolower($key), $object_meta_prefix_size) == 0){
                $newArray[strtolower($key)] = $value;
            }else{
                $newArray[$key] = $value;
            }
        }

        return $newArray;
    }

    protected function execute($method, $options) {
        $options = self::lowercaseKeys($options);

        $command_class_name = ucfirst($method);
        require_once __DIR__ . "/model/request/$command_class_name.php";
        $command_class = 'baidu\\bce\\bos\\model\\request\\'.$command_class_name;
        $command = new $command_class($method);
        $command->setServiceClient($this->service_client);

        $response_class_name = ucfirst($method).'Response';
        require_once __DIR__ . "/model/response/$response_class_name.php";
        $response_class = 'baidu\\bce\\bos\\model\\response\\'.$response_class_name;
        $response = new $response_class($options);

        $command->execute($this->client_options, $options, $response);

        return $response;
    }

    protected $endpoint;
    protected $ak;
    protected $sk;
    protected $charset;

    private $service_client;
}


class BosSimpleClient {
    const MIN_PART_SIZE = 5242880;
    const MAX_PART_SIZE = 5368709120;
    const MAX_PARTS     = 10000;

    function __construct(array $config) {
        $this->bos_client = new BosClient($config);
    }

    static function factory(array $config) {
        return new static($config);
    }

    public function createBucket($bucket_name, $location = "cn-n1") {
        $request = array();
        $request[BosOptions::BUCKET] = $bucket_name;
        $request[BosOptions::BUCKET_LOCATION] = $location;

        return $this->bos_client->createBucket($request);
    }

    public function deleteBucket($bucket_name) {
        $request = array();
        $request[BosOptions::BUCKET] = $bucket_name;
        return $this->bos_client->deleteBucket($request);
    }

    public function bucketExist($bucket_name) {
        $request = array();
        $request[BosOptions::BUCKET] = $bucket_name;
        $this->bos_client->doesBucketExist($request);

        return true;
    }

    public function setBucketAcl($bucket_name, $acl) {
        $request = array();
        $request[BosOptions::BUCKET] = $bucket_name;
        $request[BosOptions::ACL] = $acl;
        return $this->bos_client->setBucketAcl($request);
    }

    public function getBucketAcl($bucket_name) {
        $request = array();
        $request[BosOptions::BUCKET] = $bucket_name;

        return $this->bos_client->getBucketAcl($request)->getAcl();
    }

    public function getBucketLocation($bucket_name) {
        $request = array();
        $request[BosOptions::BUCKET] = $bucket_name;

        return $this->bos_client->getBucketConfiguration($request)->getLocationConstraint();
    }

    public function putObject($bucket_name, $object_name, $object_content, $object_meta_list = array()) {
        $request = array();

        $request[BosOptions::BUCKET] = $bucket_name;
        $request[BosOptions::OBJECT] = $object_name;
        $request[BosOptions::OBJECT_CONTENT_STRING] = $object_content;

        foreach($object_meta_list as $meta_key => $meta_value) {
            $request[$meta_key] = $meta_value;
        }

        return $this->bos_client->putObject($request);
    }

    public function getObjectWithMeta($bucket_name, $object_name) {
        $request = array();

        $request[BosOptions::BUCKET] = $bucket_name;
        $request[BosOptions::OBJECT] = $object_name;

        $response = $this->bos_client->getObject($request);
        $result["content"] = $response->getContent();
        $result["object_meta"] = $response->getObjectMeta();
        return $result;
    }

    public function getObject($bucket_name, $object_name) {
        return $this->getObjectWithMeta($bucket_name, $object_name);
    }

    public function getObjectMeta($bucket_name, $object_name) {
        $request = array();

        $request[BosOptions::BUCKET] = $bucket_name;
        $request[BosOptions::OBJECT] = $object_name;

        $response = $this->bos_client->getObjectMetadata($request);
        return $response->getObjectMeta();
    }

    public function uploadObject($bucket_name, $object_name, $file_name, $object_meta_list = array()) {
        $request = array();

        $request[BosOptions::BUCKET] = $bucket_name;
        $request[BosOptions::OBJECT] = $object_name;

        $object_input_stream = new BceFileInputStream($file_name);
        $request[BosOptions::OBJECT_CONTENT_STREAM] = $object_input_stream;

        foreach($object_meta_list as $meta_key => $meta_value) {
            $request[$meta_key] = $meta_value;
        }

        $this->bos_client->putObject($request);
    }

    public function uploadSuperObject($bucket_name, $object_name, $file_name, $upload_id=NULL, $object_meta_list = array()){
        $request = array();

        $request[BosOptions::BUCKET] = $bucket_name;
        $request[BosOptions::OBJECT] = $object_name;

        $fileSize = filesize($file_name);
        $partSize = self::calculatePartSize($fileSize);

        $task_list = array();

        for($start = 0, $part_number = 0; $start < $fileSize; $start += $partSize, $part_number++){
            $current_part_size = $partSize;
            if ($current_part_size + $start > $fileSize) {
                $current_part_size = -1;
            }
            $task_list[$part_number] = new BceFileInputStream($file_name,$start, $current_part_size);
        }

        $dir = "tmp_uploadId_file";
        if(!file_exists($dir)){
            mkdir($dir);
        }

        $part_list = array();
        if($upload_id != NULL && file_exists($dir."/".$upload_id)){
            $uploadId = $upload_id;

            $fp = fopen($dir."/".$uploadId, "r");

            if($fp){
                for($i=1; !feof($fp); $i++) {
                    array_push($part_list, fgets($fp));
                }
            }
            fclose($fp);

        }else{
            $response = $this->bos_client->initiateMultipartUpload($request);
            $uploadId = $response->getUploadId();
        }

        $request[BosOptions::UPLOAD_ID] = $uploadId;

        $file_handle = fopen($dir."/".$uploadId, "a") or exit("Unable to create the uploadId file");

        foreach($task_list as $part_number => $task_stream){
            if(!in_array($part_number,$part_list)){
                $request[BosOptions::OBJECT_CONTENT_STREAM] = $task_stream;
                $request[BosOptions::PART_NUM] = $part_number;
                $response = $this->bos_client->uploadPart($request);
                if($response->getEtag()!=null){
                    fwrite($file_handle, $part_number."\r\n");
                }
                array_push($part_list, new MultipartUploadPartId($response->getEtag(), $part_number));
            }
        }
        fclose($file_handle);
        $request[BosOptions::PART_LIST] = $part_list;
        $result = $this->bos_client->completeMultipartUpload($request);

        unlink($dir."/".$uploadId);
        return $result;
    }

    public function calculatePartSize($fileSize){
        $partSize = (int) ceil(($fileSize / self::MAX_PARTS));
        $partSize = max(self::MIN_PART_SIZE, $partSize);
        $partSize = min($partSize, self::MAX_PART_SIZE);
        $partSize = max($partSize, self::MIN_PART_SIZE);

        return $partSize;
    }

    public function downloadObject($bucket_name, $object_name, $file_name) {
        $request = array();

        $request[BosOptions::BUCKET] = $bucket_name;
        $request[BosOptions::OBJECT] = $object_name;
        $request[BosOptions::OBJECT_CONTENT_STREAM] = new BceFileOutputStream($file_name);

        $response = $this->bos_client->getObject($request);

        return $response->getObjectMeta();
    }

    public function deleteObject($bucket_name, $object_name) {
        $request = array();

        $request[BosOptions::BUCKET] = $bucket_name;
        $request[BosOptions::OBJECT] = $object_name;

        $this->bos_client->deleteObject($request);
    }

    public function copyObject($src_bucket, $src_object, $dest_bucket, $dest_object, $replace_object_meta_list = NULL) {
        $request = array();
        $request[BosOptions::BUCKET] = $dest_bucket;
        $request[BosOptions::OBJECT] = $dest_object;
        $request[BosOptions::OBJECT_COPY_SOURCE] = "/$src_bucket/$src_object";
        if ($replace_object_meta_list != NULL) {
            $request[BosOptions::OBJECT_COPY_METADATA_DIRECTIVE] = "replace";

            foreach($replace_object_meta_list as $meta_key => $meta_value) {
                $request[$meta_key] = $meta_value;
            }
        }

        $this->bos_client->copyObject($request);
    }

    public function listBuckets() {
        return $this->bos_client->listBuckets(array());
    }

    public function openObjectDir($bucket_name, $dir, $delimiter = "/") {
        if (substr($dir, strlen($dir) - strlen($delimiter), strlen($delimiter)) != $delimiter) {
            throw new BceIllegalArgumentException("object dir must end with $delimiter");
        }

        $object_dir_handle = new ObjectDirHandle();
        $object_dir_handle->setBucketName($bucket_name);
        $object_dir_handle->setDelimiter($delimiter);
        $object_dir_handle->setNextMarker($dir);
        $object_dir_handle->setPrefix($dir);

        return $object_dir_handle;
    }

    public function getNextObjectInObjectDir($object_dir_handle) {
        while (true) {
            $object = $object_dir_handle->getNextObject();
            if ($object != NULL) {
                return $object;
            }

            if (!$this->updateObjectDirHandle($object_dir_handle)) {
                return NULL;
            }
        }

        return NULL;
    }

    public function getNextChildDirInObjectDir($object_dir_handle) {
        while (true) {
            $child_dir_name = $object_dir_handle->getNextDirName();
            if ($child_dir_name != NULL) {
                return $child_dir_name;
            }

            if (!$this->updateObjectDirHandle($object_dir_handle)) {
                return NULL;
            }
        }
        return NULL;
    }
    private function updateObjectDirHandle($object_dir_handle) {
        $request = array();
        if ($object_dir_handle->getNextMarker() == NULL) {
            return false;
        }

        $request[BosOptions::BUCKET] = $object_dir_handle->getBucketName();
        $request[BosOptions::LIST_PREFIX] = $object_dir_handle->getPrefix();
        $request[BosOptions::LIST_MARKER] = $object_dir_handle->getNextMarker();
        $request[BosOptions::LIST_DELIMITER] = $object_dir_handle->getDelimiter();

        $response = $this->bos_client->listObjects($request);

        $object_dir_handle->setNextMarker($response->getNextMarker());
        $child_dir_name_list = array();
        foreach($response->getCommonPrefixList() as $common_prefix) {
            array_push($child_dir_name_list, $common_prefix->getPrefix());
        }

        $object_dir_handle->appendResult($child_dir_name_list, $response->getObjectList());

        return true;
    }

//    public function uploadSuperFile($bucket_name, $object_name, $file_name, $persisted_dir = ".") {
//        $size = filesize($file_name);
//        $part_size = $this->getPartSize($size);
//
//        $task_list = array();
//        for ($start = 0, $part_number = 0; $start < $size; $start += $part_size, $part_number++) {
//            $current_part_size = $part_size;
//            if ($current_part_size + $start > $size) {
//                $current_part_size = -1;
//            }
//
//            $task_list[$part_number] = new BosFileInputStream($file_name, $start, $current_part_size);
//        }
//
//        $this->parallelRunUploadTask($bucket_name, $object_name, $task_list, $persisted_dir);
//    }

//    private function parallelRunUploadTask($bucket_name, $object_name, $task_list, $persisted_dir) {
//    }

    private $bos_client;
}

class ObjectDirHandle {

    private $bucket_name;
    private $delimiter;
    private $prefix;
    private $next_marker;


    private $child_dir_list;
    private $next_dir_index;

    private $object_list;
    private $next_object_index;

    function __construct()
    {
        $this->child_dir_list = array();
        $this->object_list = array();
        $this->next_dir_index = 0;
        $this->next_object_index = 0;
    }

    public function  appendResult($child_dir_list, $object_list) {
        $this->child_dir_list = array_merge(array_slice($this->child_dir_list, $this->next_dir_index), $child_dir_list);
        $this->object_list = array_merge(array_slice($this->object_list, $this->next_object_index), $object_list);
        echo "=========================================\n";
        echo sprintf("%d, %d\n", count($this->child_dir_list), count($this->object_list));
        echo "=========================================\n";
        $this->next_dir_index = 0;
        $this->next_object_index = 0;
    }

    public function getNextObject() {
        if (count($this->object_list) <= $this->next_object_index) {
            return NULL;
        }

        $current_object_index = $this->next_object_index;
        $this->next_object_index = $current_object_index + 1;

        return $this->object_list[$current_object_index];
    }

    public function getNextDirName() {
        if (count($this->child_dir_list) <= $this->next_dir_index) {
            return NULL;
        }

        $current_child_dir_index = $this->next_dir_index;
        $this->next_dir_index = $current_child_dir_index + 1;

        return $this->child_dir_list[$current_child_dir_index];
    }

    /**
     * @return mixed
     */
    public function getBucketName()
    {
        return $this->bucket_name;
    }

    /**
     * @return mixed
     */
    public function getDelimiter()
    {
        return $this->delimiter;
    }

    /**
     * @return mixed
     */
    public function getNextMarker()
    {
        return $this->next_marker;
    }

    /**
     * @return mixed
     */
    public function getPrefix()
    {
        return $this->prefix;
    }

    /**
     * @param mixed $bucket_name
     */
    public function setBucketName($bucket_name)
    {
        $this->bucket_name = $bucket_name;
    }

    /**
     * @param mixed $delimiter
     */
    public function setDelimiter($delimiter)
    {
        $this->delimiter = $delimiter;
    }

    /**
     * @param mixed $next_marker
     */
    public function setNextMarker($next_marker)
    {
        $this->next_marker = $next_marker;
    }

    /**
     * @param mixed $prefix
     */
    public function setPrefix($prefix)
    {
        $this->prefix = $prefix;
    }
}
