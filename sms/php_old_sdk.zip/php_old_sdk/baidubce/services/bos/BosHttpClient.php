<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
namespace baidubce\bos\service;

require_once dirname(dirname(__DIR__)) . "/http/HttpClient.php";
require_once dirname(dirname(__DIR__))  . "/auth/Auth.php";
require_once __DIR__ . "/BosResponse.php";
require_once dirname(dirname(__DIR__)) . "/exception/BceServiceException.php";
require_once dirname(dirname(__DIR__)) . "/util/Coder.php";

use baidubce\bos\util\BosOptions;
use baidubce\exception\BceServiceException;
use baidubce\http\HttpClient;
use baidubce\util\Coder;
use baidubce\auth\Auth;

class BosHttpClient extends HttpClient {
    function __construct($client_options){
        $this->client_options = $client_options;
        $this->auth = new Auth($client_options[BosOptions::ACCESS_KEY_ID], $client_options[BosOptions::ACCESS_KEY_SECRET]);
    }

    public function sendRequest($request, $response) {
        $headers = $request->getHeaders();
        $encode_headers = array();
        $copy_source_header = "x-bce-copy-source";
        $object_meta_prefix = "x-bce-meta-";
        $object_meta_prefix_size = strlen($object_meta_prefix);
        foreach ($headers as $key => $val) {
            if (strcmp($copy_source_header, $key) == 0) {
                $request->addHttpHeader($key, Coder::UrlEncodeExceptSlash($val));
            } else if (strncmp($object_meta_prefix, $key, $object_meta_prefix_size) == 0) {
                $request->addHttpHeader($key, $val);
            }
        }

        foreach($encode_headers as $key => $val) {
            $headers[$key] = $val;
        }

        parent::sendRequest($request, $response);
        $http_code = $response->getHttpCode();

        if ($http_code >= 200 && $http_code < 300) {
            $response->parseResponse();
            return true;
        }

        $service_error_message = $response->getErrorMessage();

        echo "================================\n";
        echo $response->getHttpCode();
        echo "\n";
        echo $service_error_message;
        echo "================================\n";

        $error = json_decode($service_error_message);
        throw new BceServiceException($error->requestId, $error->code, $error->message, $http_code);
    }

    protected function getResponse($output_stream) {
        return new BosResponse($output_stream);
    }

    protected function getReuqestUrl($request) {
        $host = $request->getHost();
        $uri = Coder::UrlEncodeExceptSlash($request->getUri());
        $query_string = implode("&", array_map(function($k, $v) {return $k . "=" . Coder::UrlEncode($v);},
            array_keys($request->getQueryString()), $request->getQueryString()));

        echo "uri:$uri\n";
        echo "query_string:$query_string\n";

        if (!is_null($query_string) && $query_string != "") {
            return "http://" . $host . $uri . "?" . $query_string;
        }

        return "http://" . $host . $uri;
    }

    private $client_options;
    private $auth;
}