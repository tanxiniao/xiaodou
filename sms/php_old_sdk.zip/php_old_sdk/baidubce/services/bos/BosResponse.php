<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
namespace baidubce\bos\service;

require_once dirname(dirname(__DIR__)) . "/http/HttpResponse.php";

use baidubce\http\HttpResponse;

class BosResponse extends HttpResponse {
    function __construct($output_stream) {
        parent::__construct($output_stream);
        $this->error_message = "";
    }

    public function writeBody($curl_handle, $data) {
        if ($this->getHttpCode() >= 200 && $this->getHttpCode() < 300) {
            return parent::writeBody($curl_handle, $data);
        }

        $this->error_message = sprintf("%s%s", $this->error_message, $data);
    }

    private $error_message;

    /**
     * @return string
     */
    public function getErrorMessage()
    {
        return $this->error_message;
    }

    public function parseResponse() {
        $http_header = $this->getHttpHeaders();
        if (array_key_exists("x-bce-request-id", $http_header)) {
            $this->request_id = $http_header["x-bce-request-id"];
        }

        if (array_key_exists("x-bce-debug-id", $http_header)) {
            $this->debug_id = $http_header["x-bce-debug-id"];
        }
    }

    private $request_id;
    private $debug_id;

    /**
     * @return mixed
     */
    public function getDebugId()
    {
        return $this->debug_id;
    }

    /**
     * @return mixed
     */
    public function getRequestId()
    {
        return $this->request_id;
    }
} 
