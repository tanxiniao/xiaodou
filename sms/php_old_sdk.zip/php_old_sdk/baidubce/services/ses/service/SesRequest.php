<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-26
 * Time: 下午3:26
 */

namespace baidubce\ses\service;

require_once dirname(dirname(dirname(__DIR__))) . "/http/HttpRequest.php";
require_once dirname(__DIR__) . "/util/SesOptions.php";

use baidubce\ses\util\SesOptions;
use baidubce\http\HttpRequest;

class SesRequest extends HttpRequest {
	/**
	 * @param
	 * @return
	 */
    function __construct($options)
    {
        parent::__construct();
        $this->query_string_array = array();
        $this->setHost($options[SesOptions::ENDPOINT]);
        $this->expiration_period_in_seconds = 1800;
    }

    /**
     * @param
     * @return
     */
    public function setUriKey($uri_key)
    {
        $this->uri_key = $uri_key;
    }

    /**
     * @param
     * @return
     */
    public function setUriValue($uri_value)
    {
        $this->uri_value = $uri_value;
    }

    /**
     * @param
     * @return
     */
    public function addQueryString($key, $data) {
//        array_push($this->query_string_array, $key . "=" . $data);
        $this->query_string_array[$key] = $data;
    }

    /**
     * @param
     * @return
     */
    public function getUri() {
        if ($this->uri_key == NULL) {
            return "/v1/";
        }

        if ($this->uri_value == NULL) {
            return sprintf("/v1/%s",$this->uri_key);
        }

        return sprintf("/v1/%s/%s", $this->uri_key, $this->uri_value);
    }

    /**
     * @param
     * @return
     */
    public function setUri($uri) {
        throw new \RuntimeException("unexpected funcation call SesRequest::setUri");
    }

    /**
     * @param
     * @return
     */
    public function getQueryString() {
//        return implode("&", $this->query_string_array);
        return $this->query_string_array;
    }

    /**
     * @param
     * @return
     */
    public function setQueryString($query_string) {
        throw new \RuntimeException("unexpected funcation call SesRequest::setQueryString");
    }

    private $uri_key;
    private $uri_value;
    private $query_string_array;
    private $expiration_period_in_seconds;

    /**
     * @param
     * @return
     */
    public function setExpirationPeriodInSeconds($expiration_period_in_seconds)
    {
        $this->expiration_period_in_seconds = $expiration_period_in_seconds;
    }

    /**
     * @param
     * @return
     */
    public function getExpirationPeriodInSeconds()
    {
        return $this->expiration_period_in_seconds;
    }
} 