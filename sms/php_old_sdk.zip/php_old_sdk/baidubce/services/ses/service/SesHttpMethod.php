<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-25
 * Time: 上午11:01
 */

namespace baidubce\ses\service;

require_once dirname(dirname(dirname(__DIR__))) . "/exception/BceRuntimeException.php";

use baidubce\exception\BceRuntimeException;
use baidubce\http\HttpMethod;

class SesHttpMethod {
    const HTTP_PUT = 1;
    const HTTP_GET = 2;
    const HTTP_HEAD = 3;
    const HTTP_POST = 4;
    const HTTP_DELETE = 5;

    /**
     * @param
     * @return
     */
    static function getStringMethod($method) {
        if (!array_key_exists($method, HttpMethod::$string_method_map)) {
            throw new BceRuntimeException(sprintf("Unexpected http method:%d", $method));
        }

        return HttpMethod::$string_method_map[$method];
    }

    static $string_method_map;
}
HttpMethod::$string_method_map = array(HttpMethod::HTTP_PUT => "PUT", HttpMethod::HTTP_GET => "GET",
            HttpMethod::HTTP_HEAD => "HEAD", HttpMethod::HTTP_POST => "POST", HttpMethod::HTTP_DELETE => "DELETE");