<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-25
 * Time: 上午11:17
 */

namespace baidubce\ses\service;

require_once dirname(dirname(dirname(__DIR__))) . "/http/HttpClient.php";
require_once dirname(dirname(dirname(__DIR__))) . "/auth/Auth.php";
require_once "SesResponse.php";
require_once dirname(dirname(dirname(__DIR__))) . "/exception/BceServiceException.php";
require_once dirname(dirname(dirname(__DIR__))) . "/util/Coder.php";

use baidubce\ses\util\SesOptions;
use baidubce\exception\BceServiceException;
use baidubce\http\HttpClient;
use baidubce\util\Coder;
use baidubce\auth\Auth;

class SesHttpClient extends HttpClient {
	/**
	 * @param
	 * @return
	 */
    function __construct($client_options){
        $this->client_options = $client_options;
        $this->auth = new Auth($client_options[SesOptions::ACCESS_KEY_ID], $client_options[SesOptions::ACCESS_KEY_SECRET]);
    }

    /**
     * @param
     * @return
     */
    public function sendRequest($request, $http_response) {
    	/*
//     	$http_response = new Service_SmsResponse();
    	$url = $this->getReuqestUrl($request);
    	if(SesOptions::isDebugMode()){
    		echo "now we do request to $url...\n";
    	}
    	
    	$http_method = $request->getHttpMethod ();
    	$headers = $request->getHeaders ();
    	
    	$curl_handle =\curl_init ();
    	curl_setopt ( $curl_handle, CURLOPT_URL, $url);
    	curl_setopt ( $curl_handle, CURLOPT_NOPROGRESS, 1 );
    	
    	$write_header_function = function ($curl_handle, $str) use($http_response) {
    	return $http_response->writeHeader ( $curl_handle, $str );
    	};
    	
    	$write_body_function = function ($curl_handle, $str) use($http_response) {
    	return $http_response->writeBody ( $curl_handle, $str );
    	};
    	
    	curl_setopt ( $curl_handle, CURLOPT_WRITEFUNCTION, $write_body_function );
    	curl_setopt ( $curl_handle, CURLOPT_HEADERFUNCTION, $write_header_function );
    	
    	$header_line_list = array ();
    	foreach ( $headers as $key => $val ) {
    	array_push ( $header_line_list, sprintf ( "%s:%s", $key, $val ) );
    	}
    	curl_setopt ( $curl_handle, CURLOPT_HTTPHEADER, $header_line_list );
    	
    	switch ($http_method) {
    	case SesHttpMethod::HTTP_PUT :
    	$this->setHttpPutOptions ( $curl_handle, $request, $http_response );
    	break;
    	case SesHttpMethod::HTTP_DELETE :
    	$this->setHttpDeleteOptions ( $curl_handle, $request, $http_response );
    	break;
    	case SesHttpMethod::HTTP_GET :
    	$this->setHttpGetOptions ( $curl_handle, $request, $http_response );
    	break;
    	case SesHttpMethod::HTTP_POST :
    	$this->setHttpPostOptions ( $curl_handle, $request, $http_response );
    	break;
    	case SesHttpMethod::HTTP_HEAD :
    	$this->setHttpHeadOptions ( $curl_handle, $request, $http_response );
    	break;
    	}
    	
    	curl_exec($curl_handle);
    	if(SesOptions::isDebugMode()){
    	echo "finish request...\n";
    	}
    	curl_close($curl_handle);
    	return $http_response;*/
    	
        $headers = $request->getHeaders();
        $encode_headers = array();
        $copy_source_header = "x-bce-copy-source";
        $object_meta_prefix = "x-bce-meta-";
        $object_meta_prefix_size = strlen($object_meta_prefix);
        foreach ($headers as $key => $val) {
            if (strcmp($copy_source_header, $key) == 0) {
                $request->addHttpHeader($key, Coder::UrlEncodeExceptSlash($val));
            } else if (strncmp($object_meta_prefix, $key, $object_meta_prefix_size) == 0) {
                $request->addHttpHeader($key, $val);
            }
        }

        foreach($encode_headers as $key => $val) {
            $headers[$key] = $val;
        }

        parent::sendRequest($request, $http_response);
        $http_code = $http_response->getHttpCode();
// var_dump($http_response);
        if ($http_code >= 200 && $http_code < 300) {
            $http_response->parseResponse();
            return true;
        }

        $service_error_message = $http_response->getErrorMessage();

        echo "================================\n";
        echo $http_response->getHttpCode();
        echo "\n";
        echo $service_error_message;
        echo "================================\n";
        
        if($service_error_message===''){
        	throw new BceServiceException('', '', '', $http_code);
        }

        $error = json_decode($service_error_message);
        throw new BceServiceException($error->requestId, $error->code, $error->message, $http_code);
    }

    /**
     * @param
     * @return
     */
    protected function getResponse($output_stream) {
        return new SesResponse($output_stream);
    }

    /**
     * @param
     * @return
     */
    protected function getReuqestUrl($request) {
        $host = $request->getHost();
        $uri = Coder::UrlEncodeExceptSlash($request->getUri());
        $query_string = implode("&", array_map(function($k, $v) {return $k . "=" . Coder::UrlEncode($v);},
            array_keys($request->getQueryString()), $request->getQueryString()));

        echo "uri:$uri\n";
        echo "query_string:$query_string\n";

        if (!is_null($query_string) && $query_string != "") {
            return "http://" . $host . $uri . "?" . $query_string;
        }

        return "http://" . $host . $uri;
    }

    private $client_options;
    private $auth;
}