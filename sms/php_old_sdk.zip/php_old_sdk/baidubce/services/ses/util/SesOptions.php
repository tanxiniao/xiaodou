<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-24
 * Time: 下午8:06
 */

namespace baidubce\ses\util;


class SesOptions {
    const ACCESS_KEY_ID = 'AccessKeyId';
    const ACCESS_KEY_SECRET = 'AccessKeySecret';
    const ENDPOINT = 'Endpoint';
    const CHARSET = 'Charset';

    const URI_KEY = 'Key';
    const URI_VALUE = 'Value';

    const OBJECT_CONTENT_STRING = "ObjectContentString";
    const OBJECT_CONTENT_STREAM = "ObjectDataStream";

    const OBJECT_COPY_SOURCE = "CopySource";
    const OBJECT_COPY_SOURCE_IF_MATCH_TAG = "IfMatchTag";
    const OBJECT_COPY_METADATA_DIRECTIVE = "MetadataDirective";

    const BUCKET_LOCATION = "BucketLocation";
    
    const FEEDBACK_TYPE = "type";
    const FEEDBACK_ENABLED = "enabled";
    const FEEDBACK_EMAIL = "email";
    
    const VERIFIEDDOMAIN_DKIM = "dkim";
    const VERIFIEDDOMAIN_ENABLEDDKIM = "enableDkim";
    const VERIFIEDDOMAIN_DISABLEDDKIM = "disableDkim";
    
    const USERBLACKLIST_EXIST = "exist";
    
    const EMAIL_MAIL = "mail";
    const EMAIL_SOURCE = "source";
    const EMAIL_DESTINATION = "destination";
    const EMAIL_SUBJECT = "subject";
    const EMAIL_PRIORITY = "priority";
    const EMAIL_MESSAGE = "message";
    const EMAIL_ATTACHMENTS = "attachments";
    
    const QUOTA_MAXPERDAY = "maxPerDay";
    const QUOTA_MAXPERSECOND = "maxPerSecond";

    /**
     * @param
     * @return
     */
    public static function isDebugMode(){
    	return defined(SMS_DEBUG_MODE) && SMS_DEBUG_MODE==true;
    }
    
    /*
    const LIST_DELIMITER = "Delimiter";
    const LIST_MARKER = "Marker";
    const LIST_MAX_KEY_SIZE = "ListMaxKeySize";
    const LIST_PREFIX = "ListPrefix";
    const LIST_MAX_UPLOAD_SIZE =  "ListMaxUploadSize";

    const ACL = "Acl";

    const UPLOAD_ID = "UploadId";
    const PART_NUM = "PartNum";
    const PART_LIST = "PartList";

    const CONTENT_LENGTH = "Content-Length";
    const CONTENT_TYPE = "Content-Type";

    const MAX_PARTS_COUNT = "MaxPartsCount";
    const PART_NUMBER_MARKER = "PArtNumberMarker";
    */
} 