<?php
/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file AutoLoader.php
 * @author zhanglei05(com@baidu.com)
 * @date 2014/08/28 22:48:05
 * @brief 
 *  
 **/

namespace baidubce\sms\util;


if(!defined('BASE_PATH')){
    define('BASE_PATH', dirname(dirname(dirname(__DIR__))));
}

class AutoLoader {
    
    /*
     * delimiter in class name
     */
    const DELEMITER = '_';
    
    /*
     * file postfix
     */
    const FILE_POSTFIX = '.php';
    
    /**
     * @param
     * @return
     */
    static public function autoload($class){
        $class = str_replace('\\', DIRECTORY_SEPARATOR, $class);
        $file_path = BASE_PATH . '/' . $class . self::FILE_POSTFIX;
        if(file_exists($file_path)){
            require_once($file_path);
        }else{
//          throw new \RuntimeException("can not find file: ".$file_path);
        }
    }
}
//register autoload function
spl_autoload_register(array(__NAMESPACE__.'\AutoLoader', 'autoload'));
// var_dump(spl_autoload_functions());
/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */ 