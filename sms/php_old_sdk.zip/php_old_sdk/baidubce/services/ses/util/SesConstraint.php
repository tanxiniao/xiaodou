<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-26
 * Time: 下午2:22
 */

namespace baidubce\ses\util;

use baidubce\exception\BceIllegalArgumentException;

require_once dirname(dirname(dirname(__DIR__))). "/exception/BceIllegalArgumentException.php";

class SesConstraint {
	/**
	 * @param
	 * @return
	 */
    public static function checkUriKey($uri_key) {
        $bucket_name_length = strlen($uri_key);
        if ($bucket_name_length < 3 || $bucket_name_length > 63) {
            throw new BceIllegalArgumentException("uri key Illegal");
        }
		/*
        $bucket_name_pattern = "/^[a-z0-9][-0-9a-z]*[a-z0-9]$/";
        if (!preg_match($bucket_name_pattern, $bucket_name)) {
            throw new BceIllegalArgumentException("uri key Illegal");
        }*/
    }

    /**
     * @param
     * @return
     */
    public static function checkUriValue($uri_value) {
        $object_name_length = strlen($uri_value);
        if ($object_name_length > 1024 || $object_name_length < 1) {
            throw new BceIllegalArgumentException("uri value Illegal");
        }
    }

} 