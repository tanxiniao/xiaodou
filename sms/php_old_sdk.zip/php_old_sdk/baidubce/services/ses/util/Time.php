<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-25
 * Time: 下午4:22
 */

namespace baidubce\ses\util;

class Time {
	
	/**
	 * @param
	 * @return
	 */
    static function SesTimeNow() {
        return gmstrftime("%Y-%m-%dT%H:%M:%SZ",time());
    }

    /**
     * @param
     * @return
     */
    static function SesTimeToDateTime($ses_time) {
        return \DateTime::createFromFormat("Y-m-d\TH:i:s\Z", $ses_time, new \DateTimeZone("UTC"))->setTimezone(new \DateTimeZone(date_default_timezone_get()));
    }
}