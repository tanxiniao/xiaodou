<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-26
 * Time: 下午3:56
 */

namespace baidubce\ses\util;

class Constant {
    const BCE_HEADER_PREFIX = "x-bce-";
    const BCE_OBJECT_META_HEADER_PREFIX = "x-bce-meta-";
} 