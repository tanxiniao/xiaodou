<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-7-4
 * Time: 上午10:25
 */

namespace baidubce\ses\util;

class Coder {
	
	/**
	 * @param
	 * @return
	 */
    static function UrlEncode($str) {
        return rawurlencode($str);
    }

    /**
     * @param
     * @return
     */
    static function UrlEncodeExceptSlash($str) {
        return implode("/", array_map(function($v) { return rawurlencode($v); }, explode("/", $str)));
    }
} 