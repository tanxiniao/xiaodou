<?php
/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file SmsConfig.php
 * @author zhanglei05(com@baidu.com)
 * @date 2014/08/28 23:48:05
 * @brief 
 *  
 **/

namespace baidubce\sms;

//AK 公钥
define ( 'SES_AK', 'c21c23e79a144c4694c4ba9a4894b6bf' );
//SK 私钥
define ( 'SES_SK', 'c482270679c244a9962f5ad4d23d3f2b' );
//SMS Host
define ( 'SES_DOMAIN', 'cq02-bce-sms04.cq02.baidu.com:8886' );

//AK 公钥
//define ( 'SES_AK', 'b27e68d25ddf4c218b9550c330145e43' );
//SK 私钥
//define ( 'SES_SK', '4dd186b0321646a2a75270b4b126604a' );
//SMS Host
// define ( 'SES_DOMAIN', 'dbl-bigdata-jeep01.dbl01.baidu.com:8886' );

//DEBUG
define('SES_DEBUG_MODE', true);
//API版本
define ( 'SES_API_VERSION', 'v1' );