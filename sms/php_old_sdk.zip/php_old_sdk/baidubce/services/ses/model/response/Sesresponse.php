<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-26
 * Time: 下午9:15
 */

namespace baidubce\ses\service;

require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/http/HttpResponse.php";

use baidubce\http\HttpResponse;

class SesResponse extends HttpResponse {
	/**
	 * @param
	 * @return
	 */
    function __construct($output_stream) {
        parent::__construct($output_stream);
        $this->error_message = "";
    }

    /**
     * @param
     * @return
     */
    public function writeBody($curl_handle, $data) {
        if ($this->getHttpCode() >= 200 && $this->getHttpCode() < 300) {
            return parent::writeBody($curl_handle, $data);
        }

        $this->error_message = sprintf("%s%s", $this->error_message, $data);
    }

    /**
     * @param
     * @return
     */
    private $error_message;

    /**
     * @param
     * @return
     */
    public function getErrorMessage()
    {
        return $this->error_message;
    }

    /**
     * @param
     * @return
     */
    public function parseResponse() {
        $http_header = $this->getHttpHeaders();
        if (array_key_exists("x-bce-request-id", $http_header)) {
            $this->request_id = $http_header["x-bce-request-id"];
        }

        if (array_key_exists("x-bce-debug-id", $http_header)) {
            $this->debug_id = $http_header["x-bce-debug-id"];
        }
    }

    private $request_id;
    private $debug_id;

    /**
     * @param
     * @return
     */
    public function getDebugId()
    {
        return $this->debug_id;
    }

    /**
     * @param
     * @return
     */
    public function getRequestId()
    {
        return $this->request_id;
    }
} 