<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-29
 * Time: 上午6:12
 */

namespace baidubce\ses\model\response;

require_once dirname(dirname(__DIR__)) . "/service/SesResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";

use baidubce\ses\service\SesResponse;
use baidubce\model\stream\BceStringOutputStream;

class GetQuotaResponse extends SesResponse {
	private $maxPerDay;
	private $maxPerSecond;
	private $usedToday;
	
	/**
	 * @param
	 * @return
	 */
	public function getMaxPerDay()
	{
		return $this->maxPerDay;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getMaxPerSecond()
	{
		return $this->maxPerSecond;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getUsedToday(){
		return $this->usedToday;
	}
	
	/**
	 * @param
	 * @return
	 */
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
    }
    
    /**
     * @param
     * @return
     */
    public function parseResponse() {
    	parent::parseResponse();
    
    	$get_quota_result = json_decode($this->getOutputStream()->readAll());
    	$this->maxPerDay = $get_quota_result->maxPerDay;
    	$this->maxPerSecond = $get_quota_result->maxPerSecond;
    	$this->usedToday = $get_quota_result->usedToday;
    }
} 