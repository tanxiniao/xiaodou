<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-29
 * Time: 上午6:12
 */

namespace baidubce\ses\model\response;

require_once dirname(dirname(__DIR__)) . "/service/SesResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";

use baidubce\ses\service\SesResponse;
use baidubce\model\stream\BceStringOutputStream;

class GetFeedbackResponse extends SesResponse {
	private $type;
	private $enabled;
	private $email;
	
	/**
	 * @param
	 * @return
	 */
	public function getType()
	{
		return $this->type;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getEnabled()
	{
		return $this->enabled;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getEmail(){
		return $this->email;
	}
	
	/**
	 * @param
	 * @return
	 */
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
    }
    
    /**
     * @param
     * @return
     */
    public function parseResponse() {
    	parent::parseResponse();
    
    	$get_feedback_result = json_decode($this->getOutputStream()->readAll());
    	$this->type = $get_feedback_result->type;
    	$this->enabled = $get_feedback_result->enabled;
    	$this->email = $get_feedback_result->email;
    }
} 