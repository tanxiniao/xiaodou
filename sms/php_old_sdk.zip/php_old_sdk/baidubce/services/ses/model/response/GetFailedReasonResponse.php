<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-29
 * Time: 上午6:12
 */

namespace baidubce\ses\model\response;

require_once dirname(dirname(__DIR__)) . "/service/SesResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";

use baidubce\ses\service\SesResponse;
use baidubce\model\stream\BceStringOutputStream;

class GetFailedReasonResponse extends SesResponse {
	private $accsize;
	private $address;
	private $quotaoverflow;
	private $recptcnt;
	private $spammail;
	private $title;
	private $verification;
	private $virusmail;
	
	/**
	 * @param
	 * @return
	 */
	public function getAccsize()
	{
		return $this->accsize;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getAddress()
	{
		return $this->address;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getQuotaoverflow()
	{
		return $this->quotaoverflow;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getRecptcnt()
	{
		return $this->recptcnt;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getSpammail()
	{
		return $this->spammail;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getTitle()
	{
		return $this->title;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getVerification()
	{
		return $this->verification;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getVirusmail()
	{
		return $this->virusmail;
	}
	
	/**
	 * @param
	 * @return
	 */
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
    }
    
    /**
     * @param
     * @return
     */
    public function parseResponse() {
    	parent::parseResponse();
    	$get_failreason_result = json_decode($this->getOutputStream()->readAll());
    	$this->accsize = $get_failreason_result->accsize;
    	$this->address = $get_failreason_result->address;
    	$this->quotaoverflow = $get_failreason_result->quotaoverflow;
    	$this->recptcnt = $get_failreason_result->recptcnt;
    	$this->spammail = $get_failreason_result->spammail;
    	$this->title = $get_failreason_result->title;
    	$this->verification = $get_failreason_result->verification;
    	$this->virusmail = $get_failreason_result->virusmail;
    }
} 