<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-29
 * Time: 上午6:12
 */

namespace baidubce\ses\model\response;

require_once dirname(dirname(__DIR__)) . "/service/SesResponse.php";

use baidubce\ses\service\SesResponse;

class PutFeedbackResponse extends SesResponse {
	/**
	 * @param
	 * @return
	 */
    function __construct($options) {
        parent::__construct(NULL);
    }
} 