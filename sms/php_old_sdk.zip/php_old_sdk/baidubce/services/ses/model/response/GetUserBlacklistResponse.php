<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-29
 * Time: 上午6:12
 */

namespace baidubce\ses\model\response;

require_once dirname(dirname(__DIR__)) . "/service/SesResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";

use baidubce\ses\service\SesResponse;
use baidubce\model\stream\BceStringOutputStream;

class GetUserBlacklistResponse extends SesResponse {
	private $user;
	private $exist;
	
	/**
	 * @param
	 * @return
	 */
	public function getUser()
	{
		return $this->user;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getExist()
	{
		return $this->exist;
	}
	
	/**
	 * @param
	 * @return
	 */
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
    }
    
    /**
     * @param
     * @return
     */
    public function parseResponse() {
    	parent::parseResponse();
    
    	$get_userblacklist_result = json_decode($this->getOutputStream()->readAll());
    	if(isset($get_userblacklist_result->user)){
    		$this->user = $get_userblacklist_result->user;
    	}
    	if(isset($get_userblacklist_result->exist)){
    		$this->exist = $get_userblacklist_result->exist;
    	}
    }
} 