<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-29
 * Time: 上午6:12
 */

namespace baidubce\ses\model\response;

require_once dirname(dirname(__DIR__)) . "/service/SesResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";

use baidubce\ses\service\SesResponse;
use baidubce\model\stream\BceStringOutputStream;

class PutVerifiedDomainResponse extends SesResponse {
	private $token;
	
	/**
	 * @param
	 * @return
	 */
	public function getToken()
	{
		return $this->token;
	}
	
	/**
	 * @param
	 * @return
	 */
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
    }
    
    /**
     * @param
     * @return
     */
    public function parseResponse() {
    	parent::parseResponse();
    
    	$put_verifieddomain_result = json_decode($this->getOutputStream()->readAll());
    	if(isset($put_verifieddomain_result->token)){
    		$this->token = $put_verifieddomain_result->token;
    	}
    }
} 