<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-29
 * Time: 上午6:12
 */

namespace baidubce\ses\model\response;

require_once dirname(dirname(__DIR__)) . "/service/SesResponse.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/model/stream/BceStringOutputStream.php";

use baidubce\ses\service\SesResponse;
use baidubce\model\stream\BceStringOutputStream;

class GetVerifiedDomainResponse extends SesResponse {
	private $details;
	private $detail;
	
	/**
	 * @param
	 * @return
	 */
	public function getDetails()
	{
		return $this->details;
	}
	
	/**
	 * @param
	 * @return
	 */
	public function getDetail()
	{
		return $this->detail;
	}
	
	/**
	 * @param
	 * @return
	 */
    function __construct($options) {
        parent::__construct(new BceStringOutputStream());
    }
    
    /**
     * @param
     * @return
     */
    public function parseResponse() {
    	parent::parseResponse();
    
    	$get_verifieddomain_result = json_decode($this->getOutputStream()->readAll());
    	if(isset($get_verifieddomain_result->details)){
    		$this->details = $get_verifieddomain_result->details;
    	}
    	if(isset($get_verifieddomain_result->detail)){
    		$this->detail = $get_verifieddomain_result->detail;
    	}    	
    }
} 