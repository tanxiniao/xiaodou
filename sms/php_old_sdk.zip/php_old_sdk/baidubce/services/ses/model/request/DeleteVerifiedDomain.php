<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-28
 * Time: 下午4:20
 */

namespace baidubce\ses\model\request;

require_once __DIR__ . "/SesCommand.php";
require_once dirname(dirname(__DIR__))."/util/Constant.php";
require_once dirname(dirname(__DIR__))."/util/SesConstraint.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/http/HttpMethod.php";

use baidubce\http\HttpMethod;

class DeleteVerifiedDomain extends SesCommand {
	/**
	 * @param
	 * @return
	 */
    protected  function getRequest($client_options, $options) {
        $request = parent::getRequest($client_options, $options);
        $request->setHttpMethod(HttpMethod::HTTP_DELETE);

        return $request;
    }
} 