<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-24
 * Time: 下午8:23
 */

namespace baidubce\ses\model\request;

use baidubce\auth\Auth;

use baidubce\ses\util\SesOptions;
use baidubce\util\BceTools;
use baidubce\util\Time;
use baidubce\ses\util\SesConstraint;
use baidubce\ses\service\SesRequest;

require_once dirname(dirname(__DIR__)) . "/service/SesRequest.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/BceTools.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/util/Time.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))) . "/auth/Auth.php";

require_once dirname(dirname(__DIR__))."/util/SesConstraint.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))). "/exception/BceIllegalArgumentException.php";

use baidubce\exception\BceIllegalArgumentException;

class SesCommand {
	
	/**
	 * @param
	 * @return
	 */
    public function __construct($name) {
        $this->name = $name;
    }

    /**
     * @param
     * @return
     */
    public function setServiceClient($service_client) {
        $this->service_client = $service_client;
    }

    /**
     * @param
     * @return
     */
    protected function getDefaultContentType() {
        return "application/json";
    }

    /**
     * @param
     * @return
     */
    protected  function getRequest($client_options, $options) {
        $options = array_change_key_case($options,CASE_LOWER);
        $request = new SesRequest($client_options);

        $request->addHttpHeader("x-bce-date", Time::BceTimeNow());
        $request->addHttpHeader("expect", "");
        $request->addHttpHeader("transfer-encoding", "");

        $request->addHttpHeader("content-type",$this->getDefaultContentType());
//         $request->addHttpHeader("host", $client_options[SesOptions::ENDPOINT]);
        $request->addHttpHeader("x-bce-request-id", BceTools::genUUid());

        if(array_key_exists("content-type",$options)){
            $request->addHttpHeader("content-type",$options["content-type"]);
        }else{
            $request->addHttpHeader("content-type",$this->getDefaultContentType());
        }

        if(array_key_exists("host",$options)){
            $request->addHttpHeader("host",strtolower(rawurlencode($options["host"])));
        }else{
            $request->addHttpHeader("host", strtolower(rawurlencode($client_options[SesOptions::ENDPOINT])));
        }

        if(array_key_exists("x-bce-request-id",$options)){
            $request->addHttpHeader("x-bce-request-id",$options["x-bce-request-id"]);
        }else{
            $request->addHttpHeader("x-bce-request-id", BceTools::genUUid());
        }
        
        	//add bu zhangxiang01@
        	if(!is_null($this->uri_key)){
        		$request->setUriKey($this->uri_key);
        	}
        	if(!is_null($this->uri_value)){
        		$request->setUriValue($this->uri_value);
        	}
        	$options = array_change_key_case($options,CASE_LOWER);
        	$this->copyHeadersFromOptions($request, array_merge($client_options, $options));

        return $request;
    }

    /**
     * @param
     * @return
     */
    public function execute($client_options, $options, $response) {
        $this->checkOptions($client_options, $options);

        $request = $this->getRequest($client_options, $options);

        $context = $this->GetContext($options);

        $this->addAuthorization($request, $client_options);

        $this->sendRequest($request, $context, $response);

    }

    /**
     * @param
     * @return
     */
    protected function getContext($options) {
        return NULL;
    }

    /**
     * @param
     * @return
     */
    protected function sendRequest($request, $context, $response) {
        return $this->service_client->sendRequest($request, $response);
    }

    /**
     * @param
     * @return
     */
    protected function checkOptions($client_options, $options) {
    	if (!isset($options[SesOptions::URI_KEY])) {
    		throw new BceIllegalArgumentException("uri key not exist in object request");
    	}
    	$this->uri_key = $options[SesOptions::URI_KEY];
    	SesConstraint::checkUriKey($this->uri_key);
    	/*
    	if (!isset($options[SesOptions::OBJECT])) {
    		throw new BceIllegalArgumentException("object name not exist in object request");
    	}*/
    	if (isset($options[SesOptions::URI_VALUE])) {
    		$this->uri_value = $options[SesOptions::URI_VALUE];
    		SesConstraint::checkUriValue($this->uri_value);
    	}
        return true;
    }

    /**
     * @param
     * @return
     */
    protected  function needHeaderIncludeInRequest($header_key) {
        return false;
    }

    /**
     * @param
     * @return
     */
    public  function copyHeadersFromOptions($request, $options) {
        foreach($options as $key => $val) {
            if($this->needHeaderIncludeInRequest($key)) {
                $request->addHttpHeader($key, $val);
            }
        }
    }

    /**
     * @param
     * @return
     */
    private function addAuthorization($request, $client_options) {
        $auth = new Auth($client_options[SesOptions::ACCESS_KEY_ID], $client_options[SesOptions::ACCESS_KEY_SECRET]);
        $request->addHttpHeader("authorization", $auth->generateAuthorization($request));
    }

    protected $service_client;
    protected $name;
    protected $uri_key;
    protected $uri_value;
}
/*
interface SesConstraint {
}*/
