<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-28
 * Time: 下午4:20
 */

namespace baidubce\ses\model\request;

require_once __DIR__ . "/SesCommand.php";
require_once dirname(dirname(__DIR__))."/util/Constant.php";
require_once dirname(dirname(__DIR__))."/util/SesConstraint.php";
require_once dirname(dirname(__DIR__))."/util/SesOptions.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/http/HttpMethod.php";

use baidubce\http\HttpMethod;
use baidubce\ses\util\SesOptions;

class PutVerifiedDomain extends SesCommand {
	
	/**
	 * @param
	 * @return
	 */
	protected function checkOptions($client_options, $options) {
		parent::checkOptions($client_options, $options);
	
		if (isset($options[SesOptions::VERIFIEDDOMAIN_DKIM])) {
			$this->dkim = $options[SesOptions::VERIFIEDDOMAIN_DKIM];
		}
	
		if (isset($options[SesOptions::VERIFIEDDOMAIN_ENABLEDDKIM])) {
			$this->enableDkim = $options[SesOptions::VERIFIEDDOMAIN_ENABLEDDKIM];
		}
	
		if (isset($options[SesOptions::VERIFIEDDOMAIN_DISABLEDDKIM])) {
			$this->disableDkim = $options[SesOptions::VERIFIEDDOMAIN_DISABLEDDKIM];
		}
		return true;
	}
	
	/**
	 * @param
	 * @return
	 */
    protected  function getRequest($client_options, $options) {
    	$request = parent::getRequest($client_options, $options);
    	$request->setHttpMethod(HttpMethod::HTTP_PUT);
    	if (!is_null($this->dkim)) {
    		$request->addQueryString("dkim", $this->dkim);
    	}
    	
    	if (!is_null($this->enableDkim)) {
    		$request->addQueryString("enableDkim", $this->enableDkim);
    	}
    	
    	if (!is_null($this->disableDkim)) {
    		$request->addQueryString("disableDkim", $this->disableDkim);
    	}
    	
    	return $request;
    }
    
    private $dkim;
    private $enableDkim;
    private $disableDkim;
} 