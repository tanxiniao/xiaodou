<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-27
 * Time: 下午6:48
 */

namespace baidubce\ses\model\request;

require_once __DIR__ . "/SesCommand.php";
require_once dirname(dirname(__DIR__))."/util/Constant.php";
require_once dirname(dirname(__DIR__))."/util/SesConstraint.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))). "/exception/BceIllegalArgumentException.php";

use baidubce\ses\util\SesConstraint;
use baidubce\ses\util\SesOptions;
use baidubce\exception\BceIllegalArgumentException;

class VerifiedEmailCommand extends SesCommand {
    protected  $bucket_name;
    protected  $object_name;

    /**
     * @param
     * @return
     */
    protected function checkOptions($client_options, $options) {
        parent::checkOptions($client_options, $options);
        if (!isset($options[SesOptions::BUCKET])) {
            throw new BceIllegalArgumentException("bucket name not exist in object request");
        }
        if (!isset($options[SesOptions::OBJECT])) {
            throw new BceIllegalArgumentException("object name not exist in object request");
        }

        $this->bucket_name = $options[SesOptions::BUCKET];
        SesConstraint::checkBucketName($this->bucket_name);

        $this->object_name = $options[SesOptions::OBJECT];
        SesConstraint::checkObjectName($this->object_name);
        return true;
    }

    /**
     * @param
     * @return
     */
    protected  function getRequest($client_options, $options) {
        $request = parent::getRequest($client_options, $options);
        $request->setBucketName($this->bucket_name);
        $request->setObjectName($this->object_name);

        $options = array_change_key_case($options,CASE_LOWER);
        $this->copyHeadersFromOptions($request, array_merge($client_options, $options));
        return $request;
    }
} 