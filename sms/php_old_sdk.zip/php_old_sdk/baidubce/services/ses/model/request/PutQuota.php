<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-28
 * Time: 下午1:43
 */

namespace baidubce\ses\model\request;

require_once __DIR__ . "/SesCommand.php";
require_once dirname(dirname(__DIR__))."/util/SesOptions.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/exception/BceIllegalArgumentException.php";
require_once dirname(dirname(dirname(dirname(__DIR__))))."/http/HttpMethod.php";
require_once dirname(dirname(__DIR__))."/util/Constant.php";
require_once dirname(dirname(dirname(dirname(__DIR__)))). "/model/stream/BceStringInputStream.php";

use baidubce\http\HttpMethod;
use baidubce\ses\util\SesOptions;
use baidubce\model\stream\BceStringInputStream;
use baidubce\exception\BceIllegalArgumentException;
use baidubce\util\Constant;

class PutQuota extends SesCommand {

	/**
	 * @param
	 * @return
	 */
    function __construct() {
        $this->maxPerDay  = NULL;
        $this->maxPerSecond = NULL;
    }

    /**
     * @param
     * @return
     */
    protected function checkOptions($client_options, $options) {
        parent::checkOptions($client_options, $options);
/*
        if (isset($options[SesOptions::QUOTA_MAXPERDAY])) {
            $this->maxPerDay = $options[SesOptions::QUOTA_MAXPERDAY];
        }

        if (isset($options[SesOptions::QUOTA_MAXPERSECOND])) {
            $this->maxPerSecond = $options[SesOptions::QUOTA_MAXPERSECOND];
        }
        
        if (isset($options[SesOptions::QUOTA_MAXPERDAY])) {
        	$this->input_stream['maxPerDay'] = $options[SesOptions::QUOTA_MAXPERDAY];
        }
        
        if (isset($options[SesOptions::QUOTA_MAXPERSECOND])) {
        	$this->input_stream['maxPerSecond'] = $options[SesOptions::QUOTA_MAXPERSECOND];
        }*/
        
        $this->input_stream = NULL;
        if (isset($options[SesOptions::OBJECT_CONTENT_STRING])) {
        	$this->input_stream = new BceStringInputStream($options[SesOptions::OBJECT_CONTENT_STRING]);
        } else if (isset($options[SesOptions::OBJECT_CONTENT_STREAM])) {
        	$this->input_stream = $options[SesOptions::OBJECT_CONTENT_STREAM];
        } else {
        	throw new BceIllegalArgumentException("no object content input object");
        }
        return true;
    }
    
    /**
     * @param
     * @return
     */
    protected  function getRequest($client_options, $options) {
    	
    	$request = parent::getRequest($client_options, $options);
    	 
    	$request->setInputStream($this->input_stream);
    	$request->setHttpMethod(HttpMethod::HTTP_PUT);
    	 
    	$request->addHttpHeader("content-length", $this->input_stream->getSize() - $this->input_stream->getPos());
    	 
    	$md5_ctx = hash_init("md5");
    	$sha256_ctx = hash_init("sha256");
    	 
    	$saved_pos = $this->input_stream->getPos();
    	 
    	while (true) {
    		$str = $this->input_stream->read(PutQuota::BLOCK_MAX_READ_SIZE);
    		if ($str == "") {
    			break;
    		}
    		 
    		hash_update($md5_ctx, $str);
    		hash_update($sha256_ctx, $str);
    	}
    	$this->input_stream->seek($saved_pos);
    	 
    	$md5 = base64_encode(hash_final($md5_ctx, true));
    	$sha256 = hash_final($sha256_ctx);
    	 
    	 
    	$request->addHttpHeader("content-md5", $md5);
    	 
    	$request->addHttpHeader("x-bce-content-sha256", $sha256);
    	 
    	if (array_key_exists("content-md5", $options)) {
    		$request->addHttpHeader("content-md5", $options["content-md5"]);
    	}
    	 
    	if (array_key_exists("x-bce-content-sha256", $options)) {
    		$request->addHttpHeader("x-bce-content-sha256", $options["x-bce-content-sha256"]);
    	}
    	/*
        $request = parent::getRequest($client_options, $options);
        $request->setHttpMethod(HttpMethod::HTTP_PUT);
        if (!is_null($this->maxPerDay)) {
            $request->addQueryString("maxPerDay", $this->maxPerDay);
        }

        if (!is_null($this->maxPerSecond)) {
            $request->addQueryString("maxPerSecond", $this->maxPerSecond);
        }*/
        return $request;
    }
    
    /**
     * @param
     * @return
     */
    protected  function needHeaderIncludeInRequest($header_key) {
    	if (parent::needHeaderIncludeInRequest($header_key)) {
    		return true;
    	}
    
    	$lower_header_key = strtolower($header_key);
    
    	if (substr($lower_header_key, 0, strlen(Constant::BCE_HEADER_PREFIX)) == Constant::BCE_HEADER_PREFIX) {
    		return true;
    	}
    
    	if (array_key_exists($lower_header_key, PutQuota::$legal_header_key_set)) {
    		return true;
    	}
    
    	return false;
    }

    private $input_stream;
    
    private $maxPerDay;
    private $maxPerSecond;
    
    const BLOCK_MAX_READ_SIZE = 65536;
    
    public static $legal_header_key_set;
} 
PutQuota::$legal_header_key_set = array("content-md5" => "", "content-length" => "", "content-type" => "");