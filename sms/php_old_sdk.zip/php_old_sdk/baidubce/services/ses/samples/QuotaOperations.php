<?php
/**
 * Created by PhpStorm.
 * User: zhangxiang01
 * Date: 14-9-11
 * Time: 下午3:14
 */

require_once dirname(__DIR__) . '/SesClient.php';
require_once dirname(__DIR__) . '/util/SesOptions.php';
// require_once __DIR__ . '/model/request/CompleteMultipartUpload.php';

function getQuota($ses_client){
	$request = array();
	$response = $ses_client->getQuota();
	return $response;
}

function putQuota($ses_client,$maxPerSecond,$maxPerSecond){
	$response = $ses_client->getQuota($maxPerSecond,$maxPerSecond);
	return $response;
}


$client_options = array();

$ses_client = \baidubce\ses\SesClient::factory($client_options);

try {
	$maxPerDay = 300;
	$maxPerSecond = 2;
	$response = putQuota($ses_client,$maxPerSecond,$maxPerSecond);
	
	$response = getQuota($ses_client);
	
} catch (\baidubce\ses\exception\SesServiceException $ex){
	echo sprintf("%s\n", $ex->getDebugMessage());
}catch (\baidubce\ses\exception\SesBaseException $ex) {
	echo sprintf("%s\n", $ex->getDebugMessage());
} catch (Exception $ex) {
	echo sprintf("%s\n", $ex->getMessage());
}