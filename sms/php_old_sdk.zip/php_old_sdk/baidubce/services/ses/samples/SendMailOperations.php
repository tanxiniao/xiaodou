<?php
/**
 * Created by PhpStorm.
 * User: zhangxiang01
 * Date: 14-9-11
 * Time: 下午3:14
 */

require_once dirname(__DIR__) . '/SesClient.php';
require_once dirname(__DIR__) . '/util/SesOptions.php';
// require_once __DIR__ . '/model/request/CompleteMultipartUpload.php';


$client_options = array();

$ses_client = \baidubce\ses\SesClient::factory($client_options);

try {

	$from = 'wanglinqing01@baidu.com';
	$subject = array('charset'=>1,'data'=>'subject');
	$message = array('text'=>array('charset'=>1,'data'=>'message'));
	$toAddr = array(array('addr'=>'shidaiting01@baidu.com'),array('addr'=>'13488695400@126.com'));
	$ccAddr= array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
	$bccAddr = array(array('addr'=>'zhangxiang01@baidu.com'),array('addr'=>'wanglinqing01@baidu.com'));
	$priority = 1;
	$attachments= array(
		'https://svn.baidu.com/inf/bec/trunk/asm/bms/accessor/Makefile',/*'http://nj.bs.bae.baidu.com/mfb-apk-public/b6083cdfde_v30_kirin_baiduzhidao_kirin.apk',*/  
	);
	
	$response = $ses_client->postEmail($from, $subject, $message, $toAddr, $ccAddr, $bccAddr, $priority, $attachments);
	var_dump($response);
	
} catch (\baidubce\ses\exception\SesServiceException $ex){
	echo sprintf("%s\n", $ex->getDebugMessage());
}catch (\baidubce\ses\exception\SesBaseException $ex) {
	echo sprintf("%s\n", $ex->getDebugMessage());
} catch (Exception $ex) {
	echo sprintf("%s\n", $ex->getMessage());
}
