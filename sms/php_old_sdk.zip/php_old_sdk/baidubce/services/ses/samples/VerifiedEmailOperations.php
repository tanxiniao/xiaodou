<?php
/**
 * Created by PhpStorm.
 * User: zhangxiang01
 * Date: 14-9-11
 * Time: 下午3:14
 */

require_once dirname(__DIR__) . '/SesClient.php';
require_once dirname(__DIR__) . '/util/SesOptions.php';
// require_once __DIR__ . '/model/request/CompleteMultipartUpload.php';

function putVerifiedEmail($ses_client,$emailAddress){
	$response = $ses_client->putVerifiedEmail($emailAddress);
	return $response;
}

function getVerifiedEmail($ses_client,$mailAddress){
	$response = $ses_client->getVerifiedEmail($mailAddress);
	return $response;
}

function deleteVerifiedEmail($ses_client,$mailAddress){
	$response = $ses_client->deleteVerifiedEmail($mailAddress);
	return $response;
}

$client_options = array();

$ses_client = \baidubce\ses\SesClient::factory($client_options);

try {
	$emailAddress = 'zhangzheyuan@baidu.com';
	$response = putVerifiedEmail($ses_client, $emailAddress);  
	
	$response = getVerifiedEmail($ses_client, $emailAddress);
	
	$response = deleteVerifiedEmail($ses_client, $emailAddress);
	
	var_dump($response);
	
} catch (\baidubce\ses\exception\SesServiceException $ex){
	echo sprintf("%s\n", $ex->getDebugMessage());
}catch (\baidubce\ses\exception\SesBaseException $ex) {
	echo sprintf("%s\n", $ex->getDebugMessage());
} catch (Exception $ex) {
	echo sprintf("%s\n", $ex->getMessage());
}