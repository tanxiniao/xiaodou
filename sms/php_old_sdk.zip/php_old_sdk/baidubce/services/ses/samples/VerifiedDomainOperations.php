<?php
/**
 * Created by PhpStorm.
 * User: zhangxiang01
 * Date: 14-9-11
 * Time: 下午3:14
 */

require_once dirname(__DIR__) . '/SesClient.php';
require_once dirname(__DIR__) . '/util/SesOptions.php';
// require_once __DIR__ . '/model/request/CompleteMultipartUpload.php';

function putVerifiedDomain($ses_client,$domain,$dkim){
	$response = $ses_client->putVerifiedDomain($domain,$dkim);
	return $response;
}

function getVerifiedDomain($ses_client,$mailAddress){
	$response = $ses_client->getVerifiedDomain($mailAddress);
	return $response;
}

function deleteVerifiedDomain($ses_client,$mailAddress){
	$response = $ses_client->deleteVerifiedDomain($mailAddress);
	return $response;
}

$client_options = array();

$ses_client = \baidubce\ses\SesClient::factory($client_options);

try {
	$domain = '6ed973d8-20a0-41d7-bd60-b6ee15cc27cb.baidu.com';
	$dkim = 'dkim';
	$response = putVerifiedDomain($ses_client, $domain, $dkim);  
	
	$response = getVerifiedDomain($ses_client, $domain);
	
	$response = deleteVerifiedDomain($ses_client, $domain);
	
	var_dump($response);
	
} catch (\baidubce\ses\exception\SesServiceException $ex){
	echo sprintf("%s\n", $ex->getDebugMessage());
}catch (\baidubce\ses\exception\SesBaseException $ex) {
	echo sprintf("%s\n", $ex->getDebugMessage());
} catch (Exception $ex) {
	echo sprintf("%s\n", $ex->getMessage());
}