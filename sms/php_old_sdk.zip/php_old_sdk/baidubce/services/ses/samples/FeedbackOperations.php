<?php
/**
 * Created by PhpStorm.
 * User: zhangxiang01
 * Date: 14-9-11
 * Time: 下午3:14
 */

require_once dirname(__DIR__) . '/SesClient.php';
require_once dirname(__DIR__) . '/util/SesOptions.php';
// require_once __DIR__ . '/model/request/CompleteMultipartUpload.php';

function putFeedback($ses_client,$type,$enabled,$email){
	$response = $ses_client->putFeedback($type,$enabled,$email);
	return $response;
}

function getFeedback($ses_client){
	$response = $ses_client->getFeedback();
	return $response;
}

$client_options = array();

$ses_client = \baidubce\ses\SesClient::factory($client_options);

try {
	$type = 0;
	$enabled = true;
	$email = 'feedback@sample.com';
	$response = getFeedback($ses_client, $type,$enabled,$email);  
	
	$response = getFeedback($ses_client);
	
	var_dump($response);
	
} catch (\baidubce\ses\exception\SesServiceException $ex){
	echo sprintf("%s\n", $ex->getDebugMessage());
}catch (\baidubce\ses\exception\SesBaseException $ex) {
	echo sprintf("%s\n", $ex->getDebugMessage());
} catch (Exception $ex) {
	echo sprintf("%s\n", $ex->getMessage());
}