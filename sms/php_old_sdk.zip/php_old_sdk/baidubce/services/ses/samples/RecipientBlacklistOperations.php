<?php
/**
 * Created by PhpStorm.
 * User: zhangxiang01
 * Date: 14-9-11
 * Time: 下午3:14
 */

require_once dirname(__DIR__) . '/SesClient.php';
require_once dirname(__DIR__) . '/util/SesOptions.php';
// require_once __DIR__ . '/model/request/CompleteMultipartUpload.php';

function putRecipientBlacklist($ses_client,$emailAddress){
	$response = $ses_client->putRecipientBlacklist($emailAddress);
	return $response;
}

function getRecipientBlacklist($ses_client,$emailAddress){
	$response = $ses_client->getRecipientBlacklist($emailAddress);
	return $response;
}

function deleteRecipientBlacklist($ses_client,$emailAddress){
	$response = $ses_client->deleteRecipientBlacklist($emailAddress);
	return $response;
}

$client_options = array();

$ses_client = \baidubce\ses\SesClient::factory($client_options);

try {
	$emailAddress = 'zhangxiang01@baidu.com';
	$response = putRecipientBlacklist($ses_client, $emailAddress);  
	
	$response = getRecipientBlacklist($ses_client, $emailAddress);
	
	$response = deleteRecipientBlacklist($ses_client, $emailAddress);
	
	var_dump($response);
	
} catch (\baidubce\ses\exception\SesServiceException $ex){
	echo sprintf("%s\n", $ex->getDebugMessage());
}catch (\baidubce\ses\exception\SesBaseException $ex) {
	echo sprintf("%s\n", $ex->getDebugMessage());
} catch (Exception $ex) {
	echo sprintf("%s\n", $ex->getMessage());
}