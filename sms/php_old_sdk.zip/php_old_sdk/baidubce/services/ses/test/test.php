<?php
require_once dirname(__DIR__) . '/SesClient.php';  
//require_once __DIR__ . '/SesConfig.php';
//require_once __DIR__ . '/util/SesOptions.php';

use baidubce\sms\util\SmsOptions;

$client_options = array();
/*
$client_options[\baidubce\ses\util\SesOptions::ENDPOINT] = "dbl-bigdata-jeep01.dbl01.baidu.com:8886";
$client_options[\baidubce\ses\util\SesOptions::ACCESS_KEY_ID] = "c21c23e79a144c4694c4ba9a4894b6bf";
$client_options[\baidubce\ses\util\SesOptions::ACCESS_KEY_SECRET] = "c482270679c244a9962f5ad4d23d3f2b";
*/
// $client_options[SesOptions::ENDPOINT] = "dbl-bigdata-jeep01.dbl01.baidu.com:8886";
$client_options[\baidubce\ses\util\SesOptions::ENDPOINT] = "cq02-bce-sms04.cq02.baidu.com:8886";
$client_options[\baidubce\ses\util\SesOptions::ACCESS_KEY_ID] = "c21c23e79a144c4694c4ba9a4894b6bf";
$client_options[\baidubce\ses\util\SesOptions::ACCESS_KEY_SECRET] = "c482270679c244a9962f5ad4d23d3f2b";


$ses_client = \baidubce\ses\SesClient::factory($client_options);

$request = array();
$response = $ses_client->putVerifiedEmail($request);
$response = $ses_client->getVerifiedEmail($request);
$response = $ses_client->deleteVerifiedEmail($request);
$response = $ses_client->putVerifiedDomain($request);
$response = $ses_client->getVerifiedDomain($request);
$response = $ses_client->deleteVerifiedDomain($request);
$response = $ses_client->postEmail($request);
$response = $ses_client->putFeedback($request);
$response = $ses_client->getFeedback($request);
$response = $ses_client->putQuota($request);
$response = $ses_client->getQuota($request);
$response = $ses_client->putUserBlacklist($request);
$response = $ses_client->getUserBlacklist($request);
$response = $ses_client->deleteUserBlacklist($request);
$response = $ses_client->putRecipientBlacklist($request);
$response = $ses_client->getRecipientBlacklist($request);
$response = $ses_client->deleteRecipientBlacklist($request);
$response = $ses_client->getFailedReason($request);
