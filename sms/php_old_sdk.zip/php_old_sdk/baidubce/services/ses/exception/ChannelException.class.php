<?php
class ChannelException extends Exception
{
    //do nothing
}