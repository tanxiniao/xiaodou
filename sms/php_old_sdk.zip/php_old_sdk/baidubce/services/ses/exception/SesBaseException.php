<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-26
 * Time: 下午2:05
 */

namespace baidubce\ses\exception;
require_once __DIR__ . "/SesBaseException.php";

class SesBaseException extends \Exception {
	/**
	 * @param
	 * @return
	 */
    function __construct($message) {
        parent::__construct($message);
    }
    /**
     * @param
     * @return
     */
    function getDebugMessage() {
        return $this->getMessage();
    }
}