<?php
/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file NonexistentFile.php
 * @author zhanglei05(com@baidu.com)
 * @date 2014/08/29 00:48:05
 * @brief 
 *  
 **/
 
namespace baidubce\ses\exception;
require_once __DIR__ . "/SesBaseException.php";

class Exception_NonexistentFile extends SesBaseException {
	
	//error code
	const ERROR_CODE = 'InternalError';

	/**
	 * @param
	 * @return 
	 */
	function __construct($filePath) {
		parent::__construct('file [' .$filePath. '] does not exists!', ERROR_CODE);
	}
}