<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-26
 * Time: 下午2:59
 */

namespace baidubce\ses\exception;

require_once __DIR__ . "/SesBaseException.php";

class SesStreamException extends SesBaseException {

	/**
	 * @param
	 * @return
	 */
    function __construct($message) {
        parent::__construct($message);
    }
}
