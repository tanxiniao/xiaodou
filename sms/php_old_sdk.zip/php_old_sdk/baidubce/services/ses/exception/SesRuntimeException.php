<?php
/**
 * Created by PhpStorm.
 * User: cuican01
 * Date: 14-6-26
 * Time: 下午2:49
 */

namespace baidubce\ses\exception;

require_once __DIR__ . "/SesBaseException.php";

class SesRuntimeException extends  SesBaseException {
	/**
	 * @param
	 * @return
	 */
    function __construct($message) {
        parent::__construct($message);
    }
}

class SesCallPureVirtualFunctionException extends SesRuntimeException {
	/**
	 * @param
	 * @return
	 */
    function __construct($class_name, $function_name) {
        parent::__construct("call pure function " . $class_name . "::" . $function_name);
    }
}