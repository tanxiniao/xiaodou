<?php
/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file SesClient.php
 * @author zhanglei05(com@baidu.com)
 * @date 2014/08/28 23:48:05
 * @brief 
 *  
 **/

namespace baidubce\ses;

require_once __DIR__ . "/service/SesHttpClient.php";
require_once dirname(dirname(__DIR__)) . "/auth/Auth.php";
require_once __DIR__ . "/util/SesOptions.php";
require_once __DIR__ . "/SesConfig.php";

use baidubce\ses\util\SesOptions;
use baidubce\ses\service\SesHttpClient;
use baidubce\exception\BceRuntimeException;


require_once(__DIR__ . '/util/AutoLoader.php'); 

class SesClient {

	/**
	 * Get a new <code>SesClient</code> instance with the specified configuration.
	 *
	 * Use default config if params is empty(null or empty array).
	 * @param array $config the config array.
	 * <pre>
	 *  $config is an array contain following elements:
 	 *	$client_options[\baidu\bce\ses\util\SesOptions::ENDPOINT] = "ses server:port";
 	 *	$client_options[\baidu\bce\ses\util\SesOptions::ACCESS_KEY_ID] = "your ak";
 	 *	$client_options[\baidu\bce\ses\util\SesOptions::ACCESS_KEY_SECRET] = "you sk";
	 *
	 * 	if $config is empty(null or empty array), use SesConfig.php as default,
	 * 	so if you want to create a config use default value, pass null.
	 * </pre>
	 *
	 * @see baidubce\sms\SesConfig.php
	 * @return SesClient the instance
	 */
	static function factory(array $config=array()) {
		return new static($config);
	}
	
	/**
	 * verified Email
	 * 
	 * @param $emailAddress
	 * 
	 * @return \baidubce\sms\model\response\putVerifiedEmailResponse
	 */
	public function putVerifiedEmail($emailAddress='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "verifiedEmail";
		if (empty($emailAddress)){
			throw new BceRuntimeException('emailAddress can not empty');
		}
		$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $emailAddress;
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * get verified Email
	 * 
	 * @param $mailAddress
	 * 
	 * @return \baidubce\sms\model\response\getVerifiedEmailResponse
	 */
	public function getVerifiedEmail($mailAddress='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "verifiedEmail";
		if(!empty($mailAddress)){
			$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $mailAddress;
		}
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * delete verified Email
	 * 
	 * @param $mailAddress
	 * 
	 * @return \baidubce\sms\model\response\deleteVerifiedEmailResponse
	 */
	public function deleteVerifiedEmail($mailAddress='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "verifiedEmail";
		if (empty($mailAddress)){
			throw new BceRuntimeException('mailAddress can not empty');
		}
		$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $mailAddress;
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * Verified Domain
	 * 
	 * @param $domainName 
	 * @param $dkim
	 * 
	 * @return \baidubce\sms\model\response\putVerifiedDomainResponse
	 */
	public function putVerifiedDomain($domainName='',$dkim='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "verifiedDomain";
		if (empty($domainName)){
			throw new BceRuntimeException('domainName can not empty');
		}
		$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $domainName;
		switch ($dkim) {
			case 'dkim':
				$options[\baidubce\ses\util\SesOptions::VERIFIEDDOMAIN_DKIM] = 'true';
				break;
			
			case 'enableDkim':
				$options[\baidubce\ses\util\SesOptions::VERIFIEDDOMAIN_ENABLEDDKIM] = 'true';
				break;
			
			case 'disableDkim':
				$options[\baidubce\ses\util\SesOptions::VERIFIEDDOMAIN_DISABLEDDKIM] = 'true';
				break;
			default:
				;
			break;
		}
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * get Verified Domain
	 * @param $domainName
	 * @return \baidubce\sms\model\response\getVerifiedDomainResponse
	 */
	public function getVerifiedDomain($domainName='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "verifiedDomain";
		if(!empty($domainName)){
			$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $domainName;
		}
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * delete Verified Domain
	 * @param $domainName
	 * @return \baidubce\sms\model\response\deleteVerifiedDomainResponse
	 */
	public function deleteVerifiedDomain($domainName='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "verifiedDomain";
		if (empty($domainName)){
			throw new BceRuntimeException('domainName can not empty');
		}
		$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $domainName;
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * postEmail
	 * 
	 *	$from = 'example01@baidu.com';
	 *	$subject = array('charset'=>1,'data'=>'subject');
	 *	$message = array('text'=>array('charset'=>1,'data'=>'message'));
	 *	$toAddr = array(array('addr'=>'example02@baidu.com'),array('addr'=>'example03@baidu.com'));
	 *	$ccAddr= array(array('addr'=>'example02@baidu.com'),array('addr'=>'example03@baidu.com'));
	 *	$bccAddr = array(array('addr'=>'example02@baidu.com'),array('addr'=>'example03@baidu.com'));
	 *	$priority = 1;
	 *	$attachments= array('http://example.baidu.com/example.txt');
	 *
	 * @return \baidubce\sms\model\response\postEmailResponse
	 * 
	 */
	public function postEmail($from, $subject, $message, $toAddr=array(), $ccAddr=array(), $bccAddr=array(), $priority=0, $attachments=array()) {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "email";
		
		$files = array();
		if(!empty($attachments)){
			foreach($attachments as $name=>$url){
				if(is_numeric($name)){
					$arr = explode('/', $url);
					$file_name = array_pop($arr);
				}else{
					$file_name = $name;
				}
				
				$handle = fopen($url, "rb");
				$file_data = base64_encode(stream_get_contents($handle));
				$files[] = array('file_name'=>$file_name,'file_data'=>array('data'=>$file_data));
				fclose($handle);
			}	
		}
		$args['mail'] = array(
			'source'=>array('from'=>$from),
			'destination'=>array(
				'to_addr'=>$toAddr,
				'cc_addr'=>$ccAddr,
				'bcc_addr'=>$bccAddr,
			),
			'subject'=>$subject,
			'priority'=>intval($priority),
			'message'=>$message,
			'attachments'=>$files,
		);
 		echo json_encode($args);
		$options[\baidubce\ses\util\SesOptions::OBJECT_CONTENT_STRING] = json_encode($args);
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * set feedback
	 * 
	 * @param $type
	 * @param $enabled
	 * @param $email
	 * 
	 * @return \baidubce\sms\model\response\putFeedbackResponse
	 */
	public function putFeedback($type=1,$enabled=false,$email='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "feedback";
// 		$objContentArr = array('type'=>intval($type),'enabled'=>boolval($enabled));
// 		if(!empty($email)){
// 			$objContentArr['email'] = strval($email);
// 		}
		if(is_null($type)) {
			$type=1;
		}
		if(is_null($enabled)) {
			$enabled=false;
		}
		$objContentArr = empty($email)?array('type'=>intval($type),'enabled'=>boolval($enabled)):array('type'=>intval($type),'enabled'=>boolval($enabled),'email'=>strval($email));
		$options[\baidubce\ses\util\SesOptions::OBJECT_CONTENT_STRING] = json_encode($objContentArr);
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * get Feedback
	 * @param
	 * @return \baidubce\sms\model\response\getFeedbackResponse
	 */
	public function getFeedback() {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "feedback";
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * set quota
	 * @param $maxPerDay
	 * @param $maxPerSecond
	 * 
	 * @return \baidubce\sms\model\response\putQuotaResponse
	 */
	public function putQuota($maxPerDay, $maxPerSecond) {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "quota";
		$options[\baidubce\ses\util\SesOptions::OBJECT_CONTENT_STRING] = json_encode(array('maxPerDay'=>strval($maxPerDay),'maxPerSecond'=>strval($maxPerSecond)));
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * get quota
	 * @param
	 * @return \baidubce\sms\model\response\getQuotaResponse
	 */
	public function getQuota() {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "quota";
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * set userblacklist
	 * 
	 * @param $userId
	 * 
	 * @return \baidubce\sms\model\response\putUserBlacklistResponse
	 */
	public function putUserBlacklist($userId='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "userBlacklist";
		if (empty($userId)){
			throw new BceRuntimeException('userId can not empty');
		}
		$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $userId;
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * get userblacklist
	 * 
	 * @param $userId
	 * 
	 * @return \baidubce\sms\model\response\getUserBlacklistResponse
	 */
	public function getUserBlacklist($userId='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "userBlacklist";
		if(!empty($userId)){
// 			$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $userId;
			$options[\baidubce\ses\util\SesOptions::USERBLACKLIST_EXIST] = 'true';
		}
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * delete userblacklist
	 * 
	 * @param $userId
	 * 
	 * @return \baidubce\sms\model\response\deleteUserBlacklistResponse
	 */
	public function deleteUserBlacklist($userId='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "userBlacklist";
		if (empty($userId)){
			throw new BceRuntimeException('userId can not empty');
		}
		$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $userId;
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * set recipientblacklist
	 * 
	 * @param $emailAddress
	 * 
	 * @return \baidubce\sms\model\response\putRecipientBlacklistResponse
	 */
	public function putRecipientBlacklist($emailAddress='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "recipientBlacklist";
		$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $emailAddress;
		if (empty($emailAddress)){
			throw new BceRuntimeException('emailAddress can not empty');
		}
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * get recipientblacklist
	 * 
	 * @param $emailAddress
	 * 
	 * @return \baidubce\sms\model\response\getRecipientBlacklistResponse
	 */
	public function getRecipientBlacklist($emailAddress='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "recipientBlacklist";
		if(!empty($emailAddress)){
			$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $emailAddress;
		}
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * delete recipientblacklist
	 * 
	 * @param $emailAddress
	 * 
	 * @return \baidubce\sms\model\response\deleteRecipientBlacklistResponse
	 */
	public function deleteRecipientBlacklist($emailAddress='') {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "recipientBlacklist";
		if (empty($emailAddress)){
			throw new BceRuntimeException('emailAddress can not empty');
		}
		$options[\baidubce\ses\util\SesOptions::URI_VALUE] = $emailAddress;
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}

	/**
	 * get failed reason
	 * @param
	 * @return \baidubce\sms\model\response\getFailedReasonResponse
	 */
	public function getFailedReason() {
		$options[\baidubce\ses\util\SesOptions::URI_KEY] = "failedReason";
		$response = $this->execute(__FUNCTION__, $options);
		return $response;
	}
	
	/**
	 * @param $config
	 * @return $response
	 */
	public  function __construct(array $config) {
		$this->ak = $options[SesOptions::ACCESS_KEY_ID] = isset($config[SesOptions::ACCESS_KEY_ID])?$config[SesOptions::ACCESS_KEY_ID]:SES_AK;
		$this->sk = $options[SesOptions::ACCESS_KEY_SECRET] = isset($config[SesOptions::ACCESS_KEY_SECRET])?$config[SesOptions::ACCESS_KEY_SECRET]:SES_SK;
		$this->endpoint = $options[SesOptions::ENDPOINT] = isset($config[SesOptions::ENDPOINT])?$config[SesOptions::ENDPOINT]:SES_DOMAIN;
		// $this->charset = $config[SesOptions::CHARSET];
	
		if (empty($this->endpoint)){
			throw new BceRuntimeException('host can not empty');
		}
		$this->client_options = $options;
		$this->service_client = new SesHttpClient($options);
	}

	/**
	 * @param
	 * @return $response
	 */
	public function lowercaseKeys($array){
		$newArray = array();
	
		$object_meta_prefix = "x-bce-meta-";
		$object_meta_prefix_size = strlen($object_meta_prefix);
	
		foreach($array as $key=>$value){
			if("content-length" == strtolower($key)){
				$newArray[strtolower($key)] = $value;
			}if("content-type" == strtolower($key)){
				$newArray[strtolower($key)] = $value;
			}if("content-md5" == strtolower($key)){
				$newArray[strtolower($key)] = $value;
			}if("range" == strtolower($key)){
				$newArray[strtolower($key)] = $value;
			}if("x-bce-content-sha256" == strtolower($key)){
				$newArray[strtolower($key)] = $value;
			}if(strncmp($object_meta_prefix, strtolower($key), $object_meta_prefix_size) == 0){
				$newArray[strtolower($key)] = $value;
			}else{
				$newArray[$key] = $value;
			}
		}
	
		return $newArray;
	}

	/**
	 * @param $method, $options
	 * @return $response
	 */
	protected function execute($method, $options) {
		$options = self::lowercaseKeys($options);
	
		$command_class_name = ucfirst($method);
		require_once __DIR__ . "/model/request/$command_class_name.php";
		$command_class = 'baidubce\\ses\\model\\request\\'.$command_class_name;
		$command = new $command_class($method);
		$command->setServiceClient($this->service_client);
	
		$response_class_name = ucfirst($method).'Response';
		require_once __DIR__ . "/model/response/$response_class_name.php";
		$response_class = 'baidubce\\ses\\model\\response\\'.$response_class_name;
		$response = new $response_class($options);
	
		$command->execute($this->client_options, $options, $response);
	
		return $response;
	}
	
	protected $endpoint;
	protected $ak;
	protected $sk;
	protected $charset;
	
	private $service_client;
	
}