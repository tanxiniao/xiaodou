<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\sms\model\response;

class TplGetResponse extends ResponseObj{
	protected $templateId;
	protected $name;
	protected $content;
	protected $status;
	protected $createTime;
	protected $updateTime;
	
	/**
	 * parse the response to user response object
	 * @param array $retData the response data
	 * @param int $httpStatusCode response http status
	 * @see \baidubce\sms\model\response\ResponseObj::parseResponse()
	 */
	public function parseResponse(array $retData, $httpStatusCode){
		$this->retData = $retData;
		$this->httpStatusCode = $httpStatusCode;
		$this->parseCommon();
		$this->templateId = (!empty($this->retData)&&array_key_exists('templateId', $this->retData))?$this->retData['templateId']:null;
		$this->name = (!empty($this->retData)&&array_key_exists('name', $this->retData))?$this->retData['name']:null;
		$this->content = (!empty($this->retData)&&array_key_exists('content', $this->retData))?$this->retData['content']:null;
		$this->status = (!empty($this->retData)&&array_key_exists('status', $this->retData))?$this->retData['status']:null;
		$this->createTime = (!empty($this->retData)&&array_key_exists('createTime', $this->retData))?$this->retData['createTime']:null;
		$this->updateTime = (!empty($this->retData)&&array_key_exists('updateTime', $this->retData))?$this->retData['updateTime']:null;
	}
	
	/**
	 * @return null|array array template list, or null
	 * <pre>
	 * array(
	 * 	array(
	 * 		'templateId' => 'string',
	 * 		'name' => 'string',
	 * 		'content' => 'string',
	 * 		'status' => 'string',
	 * 		'createTime' => 'string time',
	 * 		'updateTime' => 'string time',
	 * 	),	
	 * 	...
	 * )
	 * </pre>
	 */
	public function getTemplateInfo(){
		return array(
				'templateId' => $this->templateId,
				'name' => $this->name,
				'content' => $this->content,
				'status' => $this->status,
				'createTime' => $this->createTime,
				'updateTime' => $this->updateTime,
		);
	}
}