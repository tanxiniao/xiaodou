<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\sms\model\request;

require_once __DIR__ . "/../../../../exception/BceIllegalArgumentException.php";
require_once __DIR__ . "/../../../../exception/BceServiceException.php";
use baidubce\sms\service\SmsRequest;
use baidubce\sms\util\RegexUtil;
use baidubce\exception\BceIllegalArgumentException;
use baidubce\sms\util\Constant;
use baidubce\sms\service\SmsHttpMethod;
use baidubce\sms\model\stream\SmsStringInputStream;
use baidubce\sms\service\SmsResponse;
use baidubce\exception\BceServiceException;
use baidubce\sms\model\response\MsgPostResponse;

class MsgPostCommand extends RequestCommand {
	private static $URI = '/message';
	private static $METHOD = SmsHttpMethod::METHOD_POST;
	private static $PROTOCOL = Constant::SMS_HTTP_PROTOCOL_HTTP;
	
	private $tplId;
	private $receiverList = array();
	private $contentVar = array();
	
	public function __construct(){
		parent::__construct(self::$URI);
	}
	
	/**
	 * do request
	 * 
	 * @param array options
	 * @return \baidubce\sms\model\response\MsgPostResponse
	 * @see \baidubce\sms\model\request\RequestCommand::execute()
	 */
	public function execute(array $options = null){
		$this->check();
		$request = new SmsRequest();
		$request->addParam('templateId', $this->tplId);
		$request->addParam('receiver', $this->receiverList);
		$request->addParam('contentVar', json_encode($this->contentVar));
		$request->setUri($this->getRestfulUri());
		$request->setHttpMethod(self::$METHOD);
		$request->setProtocol(self::$PROTOCOL);
		$inputStream = new SmsStringInputStream(json_encode($request->getParams()));
		$request->setInputStream($inputStream);
		$response = $this->doExecute($request, $options);
		if($response == null || !($response instanceof SmsResponse)){
			throw new BceServiceException("http response not valid!");
		}
		$standardResponse = new MsgPostResponse();
		$standardResponse->parseResponse($response->retData, $response->getHttpCode());
		return $standardResponse;
	}
	
	private function check(){
		if(empty($this->tplId)){
			throw new BceIllegalArgumentException("template id must be a string and can not be empty!");
		}
		if(empty($this->receiverList) || count($this->receiverList) > Constant::MAX_RECEIVER_COUNT){
			throw new BceIllegalArgumentException("receiver must be in[1, " . Constant::MAX_RECEIVER_COUNT . ']');
		}
		if(empty($this->contentVar)){
			throw new BceIllegalArgumentException('contentVar can not be empty.');
		}
	}
	/**
	 * @param string $tplId
	 */
	public function setTplId($tplId){
		$this->tplId = strval($tplId);
	}
	
	/**
	 * @param int $tplId
	 */
	public function addReceiver($receiver){
		if(!RegexUtil::checkMobileNumber($receiver)){
			throw new BceIllegalArgumentException('mobile phone number must be string number!');
		}
		if(!in_array($receiver, $this->receiverList)){
			$this->receiverList[] = strval($receiver);
		}
	}
	
	public function setReceiver(array $receiverList){
		if(empty($receiverList)){
			throw new BceIllegalArgumentException('receiver list can not be empty.');
		}
		foreach ($receiverList as $one){
			$this->addReceiver($one);
		}
	}
	
	public function getReceiver(){
		return $this->receiverList;
	}
	
	public function addContentVar($k, $v){
		if(empty($k) || empty($v)){
			throw new BceIllegalArgumentException("both contentVar's key and value can not be empty!");
		}
		$this->contentVar[strval($k)] = strval($v);
	}
	
	public function setContentVar(array $contentVarMap){
		if(empty($contentVarMap)){
			throw new BceIllegalArgumentException('receiver list can not be empty.');
		}
		foreach ($contentVarMap as $k=>$v){
			$this->addContentVar($k, $v);
		}
	}
	public function getContentVar(){
		return $this->contentVar;
	}
}