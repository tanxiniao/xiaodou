<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\sms\model\request;

require_once __DIR__ . "/../../../../exception/BceRuntimeException.php";
require_once __DIR__ . "/../../../../exception/BceIllegalArgumentException.php";

use baidubce\exception\BceIllegalArgumentException;
use baidubce\exception\BceRuntimeException;
use baidubce\sms\service\SmsRequest;
use baidubce\sms\service\SmsHttpClient;
use baidubce\sms\util\SmsOptions;
use baidubce\sms\util\Constant;

abstract class RequestCommand {
	/**
	 * 形如/message/${messageId}
	 * @var string
	 */
	private $restUri = '';
	/**
	 * restful uri的参数列表，将会根据key来替换
	 * @var string
	 */
	protected $restParams = array();
	
	/**
	 * params
	 * @var map
	 */
	protected $params = array();
	
	/**
	 * 形如/message/${messageId}格式的uri，需要以'/'开头，并且不能够为空
	 * @param string $restUri
	 * @throws Exception_BceRuntimeException 如果restUri为空，抛出异常
	 */
	public function __construct($restUri){
		if(empty($restUri) || strpos($restUri, '/') !== 0){
			throw new BceRuntimeException("uri must not be empty!");
		}
		$this->restUri = $restUri;
	}
	
	/**
	 * 获取组装后的restful uri
	 */
	public function getRestfulUri(){
		$uri = '';
		if(defined('SMS_API_VERSION')&&strlen(SMS_API_VERSION)>0){
			$uri .= '/' . SMS_API_VERSION;
		}else{
			$uri .= '/' . Constant::SMS_HTTP_API_VERSION;
		}
		$uri .= $this->restUri;
		foreach ($this->restParams as $k => $v){
			$uri = preg_replace('/{\s*'.$k.'\s*}/i', $v, $uri);
		}
		return $uri;
	}
	
	/**
	 * get the real command
	 * 
	 * @return the command is subclass of \baidubce\sms\model\request\RequestCommand, and one of:
	 * @see \baidubce\sms\model\request\BlacklistDelCommand
	 * @see \baidubce\sms\model\request\BlacklistGetCommand
	 * @see \baidubce\sms\model\request\BlacklistPostCommand
	 * @see \baidubce\sms\model\request\MsgGetCommand
	 * @see \baidubce\sms\model\request\MsgPostCommand
	 * @see \baidubce\sms\model\request\QuotaGetCommand
	 * @see \baidubce\sms\model\request\QuotaPutCommand
	 * @see \baidubce\sms\model\request\ReceiverGetCommand
	 * @see \baidubce\sms\model\request\TplDelCommand
	 * @see \baidubce\sms\model\request\TplGetCommand
	 * @see \baidubce\sms\model\request\TplGetListCommand
	 * @see \baidubce\sms\model\request\TplPostCommand
	 * @see \baidubce\sms\model\request\TplPutCommand
	 * @see \baidubce\sms\model\request\UserBlacklistGetCommand
	 */
	public static function getCommand($cmdName){
		if(empty($cmdName)){
			return null;
		}
		$clsName = lcfirst($cmdName);
		if(!class_exists($clsName)){
			throw new BceRuntimeException('Command not found: ' . $cmdName);
		}
		$inst = new $clsName();
		if($inst instanceof RequestCommand){
			return $inst;
		}else{
			throw new BceRuntimeException('Command not found: ' . $cmdName);
		}
	}
	
	public function putRestParam($k, $v){
		$this->restParams[$k] = $v;
	}
	/**
	 * 
	 * @param SmsRequest $request
	 * @param array $options
	 * @return Ambigous <\baidubce\sms\service\SmsResponse, string>
	 */
	protected function doExecute(SmsRequest $request, array $options = null){
		if(empty($options)){
			$options = SmsOptions::getDefaultOptions();
		}
		$ak = array_key_exists(SmsOptions::SECURE_AK_KEY, $options)?$options[SmsOptions::SECURE_AK_KEY]:'';
		$sk = array_key_exists(SmsOptions::SECURE_SK_KEY, $options)?$options[SmsOptions::SECURE_SK_KEY]:'';
		if(empty($ak)||empty($sk)){
			throw new BceIllegalArgumentException('SMS_AK/SMS_SK in SmsConfig.php must be set, or pass configure to me!');
		}
		$host = array_key_exists(SmsOptions::HTTP_DOMAIN_HOST_KEY, $options)?$options[SmsOptions::HTTP_DOMAIN_HOST_KEY]:null;
		$port = array_key_exists(SmsOptions::HTTP_DOMAIN_PORT_KEY, $options)?$options[SmsOptions::HTTP_DOMAIN_PORT_KEY]:null;
		if(empty($host)){
			throw new BceIllegalArgumentException('SMS_HOST in SmsConfig.php must be set, or pass configure to me!');
		}
		$timeout = array_key_exists(SmsOptions::HTTP_REQUEST_TIMEOUT, $options)?$options[SmsOptions::HTTP_REQUEST_TIMEOUT]:null;
		$retry = array_key_exists(SmsOptions::HTTP_REQUEST_RETRY, $options)?$options[SmsOptions::HTTP_REQUEST_RETRY]:null;
		$httpClient = new SmsHttpClient($host, $port, $ak, $sk);
		$response = $httpClient->sendRequest($request, $timeout, $retry);
		return $response;
	}
	/**
	 * execute command and return response
	 * 
	 * @param array $options
	 * @return the response is subclass of  \baidubce\sms\model\response\ResponseObj
	 * @see \baidubce\sms\model\response\BlacklistDelResponse
	 * @see \baidubce\sms\model\response\BlacklistGetResponse
	 * @see \baidubce\sms\model\response\BlacklistPostResponse
	 * @see \baidubce\sms\model\response\MsgGetResponse
	 * @see \baidubce\sms\model\response\MsgPostResponse
	 * @see \baidubce\sms\model\response\QuotaGetResponse
	 * @see \baidubce\sms\model\response\QuotaPutResponse
	 * @see \baidubce\sms\model\response\ReceiverGetResponse
	 * @see \baidubce\sms\model\response\TplDelResponse
	 * @see \baidubce\sms\model\response\TplGetListResponse
	 * @see \baidubce\sms\model\response\TplGetResponse
	 * @see \baidubce\sms\model\response\TplPostResponse
	 * @see \baidubce\sms\model\response\TplPutResponse
	 * @see \baidubce\sms\model\response\UserBlacklistGetResponse
	 */
	protected abstract function execute(array $options = null);
}