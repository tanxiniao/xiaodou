<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\sms\model\request;

require_once __DIR__ . "/../../../../exception/BceIllegalArgumentException.php";
require_once __DIR__ . "/../../../../exception/BceServiceException.php";

use baidubce\sms\service\SmsRequest;
use baidubce\sms\util\Constant;
use baidubce\sms\service\SmsHttpMethod;
use baidubce\sms\model\stream\SmsStringInputStream;
use baidubce\sms\service\SmsResponse;
use baidubce\exception\HttpResponseException;
use baidubce\sms\model\response\QuotaPutResponse;
use baidubce\exception\BceIllegalArgumentException;

class QuotaPutCommand extends RequestCommand {
	private static $URI = '/quota';
	private static $METHOD = SmsHttpMethod::METHOD_PUT;
	private static $PROTOCOL = Constant::SMS_HTTP_PROTOCOL_HTTP;
	
	private $maxSendPerDay=null;
	private $maxReceivePerPhoneNumberDay=null;
	
	public function __construct(){
		parent::__construct(self::$URI);
	}
	
	/**
	 * do request
	 * @param array options
	 * @return \baidubce\sms\SmsRetData
	 * @see \baidubce\sms\model\request\RequestCommand::execute()
	 */
	public function execute(array $options = null){
		$this->check();
		$request = new SmsRequest();
		if(!is_null($this->maxSendPerDay)){
			$request->addParam('maxSendPerDay', $this->maxSendPerDay);
		}
		if(!is_null($this->maxReceivePerPhoneNumberDay)){
			$request->addParam('maxReceivePerPhoneNumberDay', $this->maxReceivePerPhoneNumberDay);
		}
		
		$request->setUri($this->getRestfulUri());
		$request->setHttpMethod(self::$METHOD);
		$request->setProtocol(self::$PROTOCOL);
		$inputStream = new SmsStringInputStream(json_encode($request->getParams()));
		$request->setInputStream($inputStream);
		$response = $this->doExecute($request, $options);
		if($response == null || !($response instanceof SmsResponse)){
			throw new BceServiceException("http response not valid!");
		}
		$standardResponse = new QuotaPutResponse();
		$standardResponse->parseResponse($response->retData, $response->getHttpCode());
		return $standardResponse;
	}
	
	private function check(){
		if(!is_null($this->maxSendPerDay) && !is_int($this->maxSendPerDay)){
			throw new BceIllegalArgumentException('param maxSendPerDay must be int number.');
		}
		if(!is_null($this->maxReceivePerPhoneNumberDay) && !is_int($this->maxReceivePerPhoneNumberDay)){
			throw new BceIllegalArgumentException('param maxReceivePerPhoneNumberDay must be int number.');
		}
	}
	/**
	 * @param int $quota 用户在单日内发送的最多短信数目。按自然日计时
	 */
	public function setSendQuota($quota){
		if(is_null($quota)||!is_int($quota)){
			throw new BceIllegalArgumentException('param maxSendPerDay must be int number.');
		}
		$this->maxSendPerDay = $quota;
	}
	/**
	 * 
	 * @param int $quota 单终端用户在单日内允许接收的最大短信数。按自然日计时
	 */
	public function setReceiveQuota($quota){
		if(is_null($quota)||!is_int($quota)){
			throw new BceIllegalArgumentException('param maxReceivePerPhoneNumberDay must be int number.');
		}
		$this->maxReceivePerPhoneNumberDay = $quota;
	}
}