<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\sms\samples;

require_once(__DIR__ . '/../util/AutoLoader.php'); 
require_once(__DIR__ . '/../SmsConfig.php');

use baidubce\sms\SmsClient;
/*
We assume that you have correctly configured the basic parameters.
Please check file \baidubce\sms\SmsConfig.php first, be sure properly
defined follow const value:
		define ( 'SMS_AK', 'your ak' );
		define ( 'SMS_SK', 'your sk' );
		define ( 'SMS_HOST', 'the sms host' );
		define ( 'SMS_PORT', 'the sms port' );
		define ('SMS_DEBUG_MODE', true);
		define ( 'SMS_API_VERSION', 'v1' ); 
*/ 

// we use default configure here(defined in SmsConfigure.php).
$client = SmsClient::getInstance();
/*
//1. create a SMS template
$now = time();
$templateName = 'tpl_' . $now;    // template name can not be more than 32 characters in length
$templateContent = 'this is content for ${TEMPLATE_NAME}, now time is ${CURRENT_TIME}';  // the ${...} string will be replaced later
$response = $client->templateCreate('tpl_' . time(), $templateContent);
$templateId = $response->getTemplateId();
echo "we create a SMS template, the templateId=${templateId}.\n";

//2. set SMS tempalte status to VALID
$response = $client->templateUpdate($templateId, null, null, SmsClient::TEMPLATE_STATUS_VALID);
echo "we set $templateId status to " . SmsClient::TEMPLATE_STATUS_VALID . ".\n";

//3. send message use tempalte
$receiverList = array('13000000000', '13000000001');
$contentVarMap = array('TEMPLATE_NAME'=>$templateName, 'CURRENT_TIME'=>$now);
$response = $client->messageSend($templateId, $receiverList, $contentVarMap);
echo "we send message to '" . implode(',', $receiverList) . "',\n";
echo "    send count: " . $response->getSendCount() . "\n";
echo "    success count: " . $response->getSuccessCount() . "\n";
echo "    fail list: " . json_encode($response->getFailList()) . "\n";
 */

$client->templateList();

?>
