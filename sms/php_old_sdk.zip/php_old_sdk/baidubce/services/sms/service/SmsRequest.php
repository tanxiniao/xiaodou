<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
* the License. You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
* an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
* specific language governing permissions and limitations under the License.
*/
namespace baidubce\sms\service;

use baidubce\sms\util\Constant;
use baidubce\sms\service\SmsHttpUrl;
use baidubce\sms\model\stream\SmsInputStream;

class SmsRequest {
	private $protocol = Constant::SMS_HTTP_PROTOCOL_HTTP;
	private $queryStringArray = array ();
	private $expirationPeriodSeconds;
	private $httpMethod;
	private $uri;
	private $headers = array();
	private $inputStream;
	private $params = array();
	
	function __construct() {
		$this->expirationPeriodSeconds = Constant::SMS_HTTP_REQUEST_EXPIRATION_PERIOD;
	}
	
	public function setParams(array $params){
		$this->params = $params;
	}
	/**
	 * add k-v to params
	 * @param string $k
	 * @param string $v
	 */
	public function addParam($k, $v){
		$this->params[$k] = $v;
	}
	public function getParams(){
		if(empty($this->params)){
			return (object)$this->params;
		}
		return $this->params;
	}
	
	/**
	 * 获取协议类型，默认HTTP协议
	 * @return string
	 */
	public function getProtocol(){
		return $this->protocol;
	}
	
	/**
	 * 设置协议类型
	 * @param string $protocol 可以使用http/https两种协议
	 * @see Constant::SMS_HTTP_PROTOCOL_HTTP
	 * @see Constant::SMS_HTTP_PROTOCOL_HTTPS
	 */
	public function setProtocol($protocol){
		$this->protocol = $protocol;
	}
	
	/**
	 * @param int $expirationPeriodSeconds        	
	 */
	public function setExpirationPeriodInSeconds($expirationPeriodSeconds) {
		$this->expirationPeriodSeconds = $expirationPeriodSeconds;
	}
	
	/**
	 *
	 * @return int
	 */
	public function getExpirationPeriodInSeconds() {
		return $this->expirationPeriodSeconds;
	}
	
	/**
	 * add k-v to query string
	 * @param string $k
	 * @param string $v
	 */
	public function addQueryString($k, $v) {
		$this->queryStringArray[$k] = $v;
	}
	
	/**
	 * get real query string
	 * @return array queryString array
	 */
	public function getQueryString() {
		return $this->queryStringArray;
	}
	/**
	 * 
	 * @return string
	 */
	public function getQueryStringResolved(){
		return SmsHttpUrl::queryStringResolve($this->queryStringArray);
	}
	
	/**
	 *
	 * @param mixed $uri
	 */
	public function setUri($uri) {
		$this->uri = $uri;
	}
	
	/**
	 *
	 * @return mixed
	 */
	public function getUri() {
		return $this->uri;
	}
	
	/**
	 *
	 * @param mixed $headers
	 */
	public function setHeaders($headers) {
		$this->headers = $headers;
	}
	
	/**
	 *
	 * @return mixed
	 */
	public function getHeaders() {
		return $this->headers;
	}
	
	/**
	 *
	 * @param SmsInputStream $inputStream
	 */
	public function setInputStream(SmsInputStream $inputStream) {
		$this->inputStream = $inputStream;
	}
	
	/**
	 *
	 * @return SmsInputStream
	 */
	public function getInputStream() {
		return $this->inputStream;
	}
	
	/**
	 * @param string $httpMethod one of GET/POST/PUT/DELETE/HEAD
	 */
	public function setHttpMethod($httpMethod) {
		$this->httpMethod = $httpMethod;
	}
	
	/**
	 * get http method, one of GET/POST/PUT/DELETE/HEAD
	 * @return string http method
	 */
	public function getHttpMethod() {
		return $this->httpMethod;
	}
	
	/**
	 * add k-v to headers
	 * @param string $k
	 * @param string $v
	 */
	public function addHttpHeader($k, $v) {
		$this->headers [$k] = $v;
	}
} 