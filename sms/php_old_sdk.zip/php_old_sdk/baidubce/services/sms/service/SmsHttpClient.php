<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
* the License. You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
* an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
* specific language governing permissions and limitations under the License.
*/
namespace baidubce\sms\service;

require_once __DIR__ . "/../../../exception/BceRuntimeException.php";
require_once __DIR__ . "/../../../exception/BceServiceException.php";

require_once dirname( dirname ( dirname ( __DIR__ ) ) ) . "/http/HttpClient.php";
require_once dirname( dirname ( dirname ( __DIR__ ) ) ) . "/auth/Auth.php";
require_once dirname( dirname ( dirname ( __DIR__ ) ) ) . "/util/Coder.php";
require_once dirname( dirname ( dirname ( __DIR__ ) ) ) . "/util/Time.php";
require_once dirname( dirname ( dirname ( __DIR__ ) ) ) . "/util/BceTools.php";

use baidubce\sms\util\SmsOptions;
use baidubce\auth\Auth;
use baidubce\sms\service\SmsRequest;
use baidubce\sms\service\SmsResponse;
use baidubce\sms\service\SmsHttpUrl;
use baidubce\sms\service\SmsHttpMethod;
use baidubce\sms\util\Constant;
use baidubce\util\Time;
use baidubce\util\BceTools;
use baidubce\exception\BceRuntimeException;
use baidubce\exception\BceServiceException;

class SmsHttpClient {
	private $auth;
	private $host;
	private $port;
	/**
	 * 创建httpClient
	 */
	function __construct($host, $port, $ak, $sk) {
		//ak, sk, host must not be empty
		if(empty($host) || empty($ak) || empty($sk)){
			throw new BceRuntimeException('host/ak/sk must not be empty!');
		}
		$this->auth = new Auth ( $ak, $sk );
		$this->host = $host;
		$this->port = $port;
	}
	/**
	 * 
	 * @param SmsRequest $request
	 * @param int $timeout request timeout
	 * @param int $retry request retry times
	 * @throws BceServiceException
	 * @return SmsResponse
	 */
	public function sendRequest(SmsRequest $request, $timeout=Constant::SMS_HTTP_TIMEOUT, $retry = Constant::SMS_HTTP_RETRY) {
		//添加通用请求头
		$request->addHttpHeader(SmsOptions::HTTP_HEADER_CONTENTTYPE, Constant::SMS_HTTP_HEADER_CONTENTTYPE);
		$request->addHttpHeader(SmsOptions::HTTP_HEADER_DATE, Time::BceTimeNow());
// 		$request->addHttpHeader(SmsOptions::HTTP_HEADER_DATE, '2014-09-09T09:30:12Z');
		$request->addHttpHeader(SmsOptions::HTTP_HEADER_SHA256, $request->getInputStream()->getSha256());
		$request->addHttpHeader(SmsOptions::HTTP_HEADER_HOST, $this->host);
		$request->addHttpHeader("x-bce-request-id", BceTools::genUUid());
// 		$request->addHttpHeader("x-bce-request-id", 'd3805afd-0047-4467-b0c5-3a0a43721926');
		$request->addHttpHeader(SmsOptions::HTTP_HEADER_AUTHORIZATION, $this->auth->generateAuthorization($request));
		if(SmsOptions::isDebugMode()){
			echo "\n=========request header=========\n";
			print_r($request->getHeaders());
			echo "=========request header=========\n\n";
			echo "\n==========request body==========\n";
			$inputStream = $request->getInputStream();
			if($inputStream != null){
				echo $inputStream->readAll() . "\n";
			}
			echo "==========request body==========\n\n";
		}
		for($i=0; $i<$retry; $i++){
			if(SmsOptions::isDebugMode()){
				echo "we try the " . ($i+1) . "th...\n";
			}
			$response = $this->doRealRequest($request, $timeout);
			if(!$response->needRetry()){
				break;
			}
			if(SmsOptions::isDebugMode()){
				echo "in debug mode we do not retry";
				break;
			}
		}
		$response->parseResponse ();
		if ($response->isOk()) {
			if(SmsOptions::isDebugMode()){
				echo "\n\n";
				echo "^v^ request seems all ok.\n";
				echo "========response header========\n";
				print_r($response->getHttpHeaders());
				echo "========response header========\n\n";
				echo "\n=========response body=========\n";
				if($response->getOutputStream() != null){
					echo $response->getOutputStream()->readAll()."\n";
				}
				echo "=========response body=========\n\n";
			}
		}else{
			$resString = $response->getOutputStream()->readAll();
			if(SmsOptions::isDebugMode()){
				echo "\n\n";
				echo "~v~ request failed.\n";
				echo "========response header========\n";
				print_r($response->getHttpHeaders());
				echo "========response header========\n\n";
				echo "\n=========response body=========\n";
				if($response->getOutputStream() != null){
					echo "\n";
					echo $resString."\n\n";
				}
				echo 'HttpCode = ' . $response->getHttpCode ()."\n";
				echo 'Code = ' . $response->code . "\n";
				echo 'Message = ' . $response->message."\n";
				echo "=========response body=========\n\n";
			}
			$statusCode = $response->getHttpCode();
			if($statusCode>=500 && $statusCode < 600){
				throw new BceServiceException ( 'http request failed, response=' . $resString );
			}
			throw new BceServiceException($response->request_id, $response->code, $response->message, $response->getHttpCode());
		}
		return $response;
	}
	
	private function getDomain(){
		$domain = $this->host;
		if(!empty($this->port)){
			$domain .= ':' . $this->port;
		}
		return $domain;
	}
	
	/**
	 * 真正的执行一次http请求
	 *
	 * @param SmsRequest $request        	
	 * @return SmsResponse
	 */
	private function doRealRequest(SmsRequest $request, $timeout) {
		$http_response = new SmsResponse ();
		$domain = $this->getDomain();
		$url = SmsHttpUrl::urlResolve ( $domain, $request->getProtocol (), $request->getUri (), $request->getQueryStringResolved());
		if (SmsOptions::isDebugMode ()) {
			echo "now we do request to $url...\n";
		}
		
		$http_method = $request->getHttpMethod ();
		$headers = $request->getHeaders ();
		
		$curl_handle =\curl_init ();
		curl_setopt ( $curl_handle, CURLOPT_URL, $url );
		curl_setopt ( $curl_handle, CURLOPT_NOPROGRESS, 1 );
		curl_setopt ($curl_handle, CURLOPT_TIMEOUT, $timeout);
		
		$write_header_function = function ($curl_handle, $str) use($http_response) {
			return $http_response->writeHeader ( $curl_handle, $str );
		};
		
		$write_body_function = function ($curl_handle, $str) use($http_response) {
			return $http_response->writeBody ( $curl_handle, $str );
		};
		
		curl_setopt ( $curl_handle, CURLOPT_WRITEFUNCTION, $write_body_function );
		curl_setopt ( $curl_handle, CURLOPT_HEADERFUNCTION, $write_header_function );
		
		$header_line_list = array ();
		foreach ( $headers as $key => $val ) {
			array_push ( $header_line_list, sprintf ( "%s:%s", $key, $val ) );
		}
		curl_setopt ( $curl_handle, CURLOPT_HTTPHEADER, $header_line_list );
		
		switch ($http_method) {
			case SmsHttpMethod::METHOD_PUT:
				curl_setopt ( $curl_handle, CURLOPT_BINARYTRANSFER, 1 );
				$input_stream = $request->getInputStream ();
				$read_body_function = function ($curl_handle, $fp, $size) use($input_stream) {
					if ($input_stream == NULL) {
						return "";
					}
					return $input_stream->read ( $size );
				};
				curl_setopt ( $curl_handle, CURLOPT_READFUNCTION, $read_body_function );
				curl_setopt ( $curl_handle, CURLOPT_UPLOAD, 1 );
				break;
			case SmsHttpMethod::METHOD_DELETE :
				curl_setopt ( $curl_handle, CURLOPT_CUSTOMREQUEST, "DELETE" );
				break;
			case SmsHttpMethod::METHOD_GET :
				//donothing
				break;
			case SmsHttpMethod::METHOD_POST :
				curl_setopt ( $curl_handle, CURLOPT_POST, 1 );
				if ($request->getInputStream () != NULL) {
					$data = $request->getInputStream ()->readAll ();
					curl_setopt ( $curl_handle, CURLOPT_POSTFIELDS, $data );
				}
				break;
			case SmsHttpMethod::METHOD_HEAD :
				curl_setopt ( $curl_handle, CURLOPT_NOBODY, true );
				break;
		}
		curl_exec ( $curl_handle );
		if (SmsOptions::isDebugMode ()) {
			echo "finish request...\n";
		}
		curl_close ( $curl_handle );
		return $http_response;
	}
}