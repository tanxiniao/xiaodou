<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\sms\service;

require_once dirname (dirname ( dirname ( __DIR__ ) ) ) . "/util/Coder.php";
require_once dirname (dirname ( dirname ( __DIR__ ) ) ) . "/exception/BceIllegalArgumentException.php";
use baidubce\sms\util\Constant;
use baidubce\exception\BceIllegalArgumentException;
use baidubce\util\Coder;

class SmsHttpUrl {
	/**
	 * 生成url
	 * @param string $domain 域名，如：baidu.com，不加协议（http/https）前缀
	 * @param string $protocol 协议，目前支持http/https
	 * @param string $uri 访问uri
	 * @param string $queryString the standard query string
	 * @throws HttpUrlException
	 * @return string 合并后的url
	 */
	public static function urlResolve($domain, $protocol=Constant::SMS_HTTP_PROTOCOL_HTTP, $uri='/', $queryString=''){
		if(strpos($domain, Constant::SMS_HTTP_PROTOCOL_HTTP) === 0 ||
			strpos($domain, Constant::SMS_HTTP_PROTOCOL_HTTPS) === 0){
			//domin里已经带了http/https，这会导致异常
			throw new BceIllegalArgumentException("params 'domain' can not start with http/https!");
		}
		if(empty($protocol)){
			throw new BceIllegalArgumentException("params 'protocol' can not be empty!");
		}
		if(strcasecmp($protocol,Constant::SMS_HTTP_PROTOCOL_HTTP)!==0 && strcasecmp($protocol, Constant::SMS_HTTP_PROTOCOL_HTTPS)!==0){
			throw new BceIllegalArgumentException("protocol $protocol not support yet(only ".Constant::SMS_HTTP_PROTOCOL_HTTP."/".Constant::SMS_HTTP_PROTOCOL_HTTPS."supported)!");
		}
		$url = strtolower($protocol) . '://' . trim($domain, '/');
		if(!empty($uri)){
			$url .= '/' . trim(Coder::UrlEncodeExceptSlash($uri), '/');
// 			$url .= '/' . trim($uri, '/');
		}
		if(!empty($queryString)){
			$url .= '?' . $queryString;
		}
		
		return $url;
	}
	
	/**
	 * get resolved standard query string
	 * @param array $queryStringArray query string map
	 */
	public static function queryStringResolve(array $queryStringArray){
		if(empty($queryStringArray)){
			return "";
		}
		$queryString = '';
		foreach ($queryStringArray as $k=>$v){
			if(!empty($v)){
				$queryString .= $k.'='.Coder::UrlEncode($v).'&';
			}else{
				$queryString .= $k . '=' . '&';
			}
		}
		return rtrim($queryString, '&');
	}
}
