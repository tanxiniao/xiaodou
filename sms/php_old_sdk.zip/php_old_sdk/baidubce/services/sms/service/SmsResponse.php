<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
* the License. You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
* an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
* specific language governing permissions and limitations under the License.
*/
namespace baidubce\sms\service;

require_once dirname (dirname ( dirname ( __DIR__ ) ) ) . "/http/HttpResponse.php";

use baidubce\http\HttpResponse;
use baidubce\sms\util\SmsOptions;
use baidubce\sms\model\stream\SmsStringOutputStream;

class SmsResponse extends HttpResponse {
	/**
	 * 错误信息
	 * @var string
	 */
	public $message;
	/**
	 * 错误码
	 * @var string
	 */
	public $code;
	public $request_id;
// 	public $debug_id;
	public $retData;
	
	function __construct() {
		parent::__construct (new SmsStringOutputStream());
		$this->message = null;
		$this->code = null;
		$this->request_id = $this->debug_id = null;
	}
	/**
	 * @param curl_handle
	 * @param $data
	 * @see \baidubce\http\HttpResponse::writeBody()
	 */
	public function writeBody($curl_handle, $data) {
		return parent::writeBody ( $curl_handle, $data );
	}
	
	public function parseResponse() {
		$http_header = $this->getHttpHeaders ();
		if (array_key_exists ( SmsOptions::HTTP_HEADER_REQUESTID, $http_header )) {
			$this->request_id = $http_header [SmsOptions::HTTP_HEADER_REQUESTID];
		}
// 		if (array_key_exists ( SmsOptions::HTTP_HEADER_DEBUGID, $http_header )) {
// 			$this->debug_id = $http_header [SmsOptions::HTTP_HEADER_DEBUGID];
// 		}
		$outputStream = $this->getOutputStream();
		if($outputStream!=null){
			$output = $this->getOutputStream()->readAll();
			if(!empty($output)){
				$this->retData = json_decode($output, true);
				if($this->retData != null && $this->retData != false && $this->getHttpCode()!=200){
					$this->request_id = $this->retData[SmsOptions::HTTP_RESPONSE_REQUESTID];
					$this->code = $this->retData[SmsOptions::HTTP_RESPONSE_CODE];
					$this->message = $this->retData[SmsOptions::HTTP_RESPONSE_MESSAGE];
				}
			}
		}
	}
// 	/**
// 	 * get standard response data
// 	 * @return baidubce\sms\SmsRetData
// 	 */
// 	public function getResponseStandard(){
// 		$ret = new SmsRetData();
// 		$ret->code = $this->code;
// 		$ret->httpStatusCode = $this->getHttpCode();
// 		$ret->message = $this->message;
// 		$ret->requestId = $this->request_id;
// 		$ret->retData = $this->retData;
// 		return $ret;
// 	}
	
	/**
	 * 是否需要重试。
	 * 状态码为5xx的需要重试
	 * @return boolean
	 */
	public function needRetry(){
		$scode = $this->getHttpCode();
		return $scode >= 500 && $scode < 600;
	}
	/**
	 * 请求是否ok。
	 * ok的条件为状态码=200并且code为空并且message为空
	 * @return boolean
	 */
	public function isOk(){
		return $this->getHttpCode()==200 && empty($this->code) && empty($this->message);
	}
} 