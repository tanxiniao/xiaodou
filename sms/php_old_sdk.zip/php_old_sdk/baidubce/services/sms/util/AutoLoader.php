<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
 
namespace baidubce\sms\util;


if(!defined('BASE_PATH')){
	define('BASE_PATH', dirname(__DIR__));
}

if(!defined('PACKAGE_PATH')){
	define('PACKAGE_PATH', 'baidubce/sms/');
}

class AutoLoader {
	
	/*
	 * file postfix
	 */
	const FILE_POSTFIX = '.php';
	
	/*
	 * autoload function
	 */
	static public function autoload($class){
		//首先去除
		$class = str_replace('\\', DIRECTORY_SEPARATOR, $class);
		$class = str_replace(PACKAGE_PATH, '', $class);
		$file_path = BASE_PATH . DIRECTORY_SEPARATOR . $class . self::FILE_POSTFIX;
		if(file_exists($file_path)){
			require_once($file_path);
		}else{
// 			throw new \RuntimeException("can not find file: ".$file_path);
		}
	}
}
//register autoload function
spl_autoload_register(array(__NAMESPACE__.'\AutoLoader', 'autoload'));
// var_dump(spl_autoload_functions());
/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
