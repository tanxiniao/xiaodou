<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
* the License. You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
* an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
* specific language governing permissions and limitations under the License.
*/
namespace baidubce\sms\util;

use baidubce\sms\util\Constant;

class SmsOptions {
	const SECURE_AK_KEY = 'ak';
	const SECURE_SK_KEY = 'sk';
	const HTTP_DOMAIN_HOST_KEY = 'host';
	const HTTP_DOMAIN_PORT_KEY = 'port';
	const HTTP_HEADER_REQUESTID = "x-bce-request-id";
	const HTTP_HEADER_DEBUGID = "x-bce-debug-id";
	const HTTP_HEADER_CONTENTTYPE = "Content-Type";
	const HTTP_HEADER_AUTHORIZATION = "Authorization";
	const HTTP_HEADER_DATE = "x-bce-date";
	const HTTP_HEADER_SHA256 = "x-bce-content-sha256";
	const HTTP_HEADER_HOST = "host";
	const HTTP_RESPONSE_REQUESTID = "requestId";
	const HTTP_RESPONSE_CODE = "code";
	const HTTP_RESPONSE_MESSAGE = "message";
	const HTTP_REQUEST_TIMEOUT = "httpRequestTimeout";
	const HTTP_REQUEST_RETRY = "httpRequestRetry";
	const SMS_COMMON_DEBUG_KEY = 'debugMode';
	const SMS_COMMON_API_VERSION = 'apiVersion';
	
	private static $options = null;
	/**
	 * Get default options.
	 * 
	 * the value was initialized with SmsConfig.php by default,
	 * you can then chang it if you want.
	 * 
	 * @param string|null $key the option key you want to get
	 * @return string|array the default options init from SmsConfig.php
	 */
	public static function getDefaultOptions($key=null) {
		if(is_null(self::$options)){
			self::$options = array (
					SmsOptions::SECURE_AK_KEY => SMS_AK,
					SmsOptions::SECURE_SK_KEY => SMS_SK,
					SmsOptions::HTTP_DOMAIN_HOST_KEY => SMS_HOST,
					SmsOptions::HTTP_DOMAIN_PORT_KEY => SMS_PORT,
					SmsOptions::SMS_COMMON_API_VERSION => SMS_API_VERSION,
					SmsOptions::HTTP_REQUEST_TIMEOUT => Constant::SMS_HTTP_TIMEOUT,
					SmsOptions::HTTP_REQUEST_RETRY => Constant::SMS_HTTP_RETRY
			);
		}
		if(empty($key)){
			return self::$options;
		}else{
			return self::$options [$key];
		}
	}
	public static function isDebugMode() {
		return defined ( 'SMS_DEBUG_MODE' ) && SMS_DEBUG_MODE == true;
	}
} 