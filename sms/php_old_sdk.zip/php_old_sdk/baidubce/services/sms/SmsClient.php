<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\sms;

require_once(__DIR__ . '/util/AutoLoader.php'); 
require_once(__DIR__ . '/SmsConfig.php');

use baidubce\sms\util\Constant;
use baidubce\sms\util\SmsOptions;
use baidubce\sms\model\request\MsgPostCommand;
use baidubce\sms\model\request\MsgGetCommand;
use baidubce\sms\model\request\TplPostCommand;
use baidubce\sms\model\request\TplPutCommand;
use baidubce\sms\model\request\TplDelCommand;
use baidubce\sms\model\request\TplGetCommand;
use baidubce\sms\model\request\TplGetListCommand;
use baidubce\sms\model\request\QuotaPutCommand;
use baidubce\sms\model\request\QuotaGetCommand;
use baidubce\sms\model\request\ReceiverGetCommand;
use baidubce\sms\model\request\BlacklistPostCommand;
use baidubce\sms\model\request\BlacklistDelCommand;
use baidubce\sms\model\request\BlacklistGetCommand;
use baidubce\sms\model\request\UserBlacklistGetCommand;

/**
 * @example samples/SmsClientSample.php
 */
class SmsClient {
	private static $instArray = array();
	private $config = null;
	
	/**
	 * Get a new <code>SmsClient</code> instance with the specified configuration.
	 * 
	 * Use default config if params is empty(null or empty array).
	 * @param array $config the config array.
	 * <pre>
	 *  $config is an array contain following elements:
	 *  $config = array(
	 *  	SmsOptions::SECURE_AK_KEY => "your ak",
	 *  	SmsOptions::SECURE_SK_KEY => "your sk",
	 *		SmsOptions::HTTP_DOMAIN_HOST_KEY => "sms service host",
	 *		SmsOptions::HTTP_DOMAIN_PORT_KEY => "sms service port",
	 *		SmsOptions::SMS_COMMON_API_VERSION => "sms api version",
	 *		SmsOptions::HTTP_REQUEST_TIMEOUT => 30,
	 *		SmsOptions::HTTP_REQUEST_RETRY => 3
	 *  );
	 *  
	 *  You can use $config=SmsClient::config(...) to get config.
	 * 	if $config is empty(null or empty array), use SmsConfig.php as default,
	 * 	so if you want to create a config use default value, pass null.
	 * </pre>
     *
     * @see baidubce\sms\SmsConfig.php
	 * @return SmsClient the instance
	 */
	public static function getInstance(array $config = null){
		if(empty($config)){
			$config = self::config();
		}
		//compute config md5
		ksort($config);
		$md5key = md5(json_encode($config));
		//get instance
		if(!array_key_exists($md5key, self::$instArray)){
			self::$instArray[$md5key] = new self($config);
		}
		return self::$instArray[$md5key];
	}
	
	private function __construct(array $config) {
		$this->config = $config;
	}
	
	/**
	 * Send message
     * 
     * <p>
     * To send message, you have to specify a template which is built by system, or created by yourself which is audited
     * by BCE administrator.
     *
     * One or more receiver can be specified while sending message.
     * </p>
     *
	 * @param string $templateId SMS template id
	 * @param array $receiverList receiver list, can not be empty
	 * <pre>
	 * 	$receiverList is an array contain phone numbers, like:
	 * 		$receiverList = array(
	 * 			'13000000000',
	 * 			'13000000001',
	 * 			...
	 * 		);
	 * 
	 * 	<strong>NOTICE: </strong>duplicate phone number will be trimed.
	 * </pre>
	 * @param array $contentVarMap content var map
	 * <pre>
	 * 	$contentVarMap is a k-v map like:
	 * 		$contentVarMap = array('k'=>'v', ...)
	 * 	this k represent the k appeared in template, and will be replaced with v.
	 * </pre>
	 * 
	 * @return \baidubce\sms\model\response\MsgPostResponse $res
	 * <pre>
	 * you can use the following function to complete your business:
	 *  1. check if call success
	 * 		$res->isOk();
	 * 	2. get message id
	 * 		$res->getMessageId();
	 *  3. get send count
	 *  	$res->getSendCount();
	 *  4. get success count
	 *  	$res->getSuccessCount();
	 *  5. get fail list
	 *  	$res->getFailList();
	 *  for more detail see \baidubce\sms\model\response\MsgPostResponse
	 * </pre>
     *
	 * @see \baidubce\sms\model\response\MsgPostResponse
	 * @see \baidubce\sms\model\request\MsgPostCommand::execute(array $options)
	 */
	public function messageSend($templateId, array $receiverList, array $contentVarMap){
		$command = new MsgPostCommand();
		$command->setTplId($templateId);
		$command->setContentVar($contentVarMap);
		$command->setReceiver($receiverList);
		$res = $command->execute($this->config);
		return $res;
	}
	
	/**
	 * Get message info
	 *
	 * @param string $messageId The id of message
	 *
	 * @return \baidubce\sms\model\response\MsgGetResponse
	 * <pre>
	 * you can use the following function to complete your business:
	 *  1. check if call success
	 * 		$res->isOk();
	 * 	2. get message id
	 * 		$res->getMessageId();
	 *  3. get message content
	 *  	$res->getContent();
	 *  4. get receiver list
	 *  	$res->getReceiver();
	 *  5. get message send time
	 *  	$res->getSendTime();
	 *  for more detail see \baidubce\sms\model\response\MsgGetResponse
	 * </pre>
	 * @see \baidubce\sms\model\response\MsgGetResponse
	 * @see \baidubce\sms\model\request\MsgGetCommand::execute(array $options)
	 */
	public function messageInfo($messageId){
		$command = new MsgGetCommand();
		$command->setMessageId($messageId);
		$res = $command->execute($this->config);
		return $res;
	}
	
	/**
	 * Create message template
     * <p>
     * The template which is created will have a unique id. after audited by BCE administrator, it can be used normally.
     * </p>
	 *
	 * @param string $name message id
	 * @param string $content teplate content, variable use '${KEY}', we will replace variable when send message.
	 *
	 * @return \baidubce\sms\model\response\TplPostResponse
	 * <pre>
	 * you can use the following function to complete your business:
	 *  1. check if call success
	 * 		$res->isOk();
	 * 	2. get template id
	 * 		$res->getTemplateId();
	 *  for more detail see \baidubce\sms\model\response\TplPostResponse
	 * </pre>
     *
	 * @see \baidubce\sms\model\response\TplPostResponse
	 * @see \baidubce\sms\model\request\TplPostCommand::execute(array $options)
	 */
	public function templateCreate($name, $content){
		$command = new TplPostCommand();
		$command->setName($name);
		$command->setContent($content);
		$res = $command->execute($this->config);
		return $res;
	}
	
	/**
	 * Update message template
	 *
	 * @param string $templateId template id
	 * @param string $name message id
	 * @param string $content teplate content, variable use '${KEY}', we will replace variable when send message.
	 * @param string $status one of SmsClient::TEMPLATE_STATUS_PROCESSING/SmsClient::TEMPLATE_STATUS_VALID/SmsClient::TEMPLATE_STATUS_UNVALID.
	 *
	 * @return \baidubce\sms\model\response\TplPutResponse
	 * <pre>
	 * you can use the following function to complete your business:
	 *  1. check if call success
	 * 		$res->isOk();
	 *  for more detail see \baidubce\sms\model\response\TplPutResponse
	 * </pre>
     *
	 * @see \baidubce\sms\model\response\TplPutResponse
	 * @see \baidubce\sms\model\request\TplPutCommand::execute(array $options)
	 */
	public function templateUpdate($templateId, $name=null, $content=null, $status=null){
		$command = new TplPutCommand();
		$command->setName($name);
		$command->setContent($content);
		$command->setStatus($status);
		$command->setTemplateId($templateId);
		$res = $command->execute($this->config);
		return $res;
	}
	
	/**
	 * Delete message template
	 *
	 * @param string $templateId template id
	 *
	 * @return \baidubce\sms\model\response\TplDeleteResponse
	 * <pre>
	 * you can use the following function to complete your business:
	 *  1. check if call success
	 * 		$res->isOk();
	 *  for more detail see \baidubce\sms\model\response\TplDelResponse
	 * </pre>
	 * @see \baidubce\sms\model\response\TplDelResponse
	 * @see \baidubce\sms\model\request\TplDeleteCommand::execute(array $options)
	 */
	public function templateDelete($templateId){
		$command = new TplDelCommand();
		$command->setTemplateId($templateId);
		$res = $command->execute($this->config);
		return $res;
	}
	
	/**
	 * Get template info
	 *
	 * @param string $templateId template id
	 *
	 * @return \baidubce\sms\model\response\TplGetResponse
	 * <pre>
	 * you can use the following function to complete your business:
	 *  1. check if call success
	 * 		$res->isOk();
	 *  for more detail see \baidubce\sms\model\response\TplGetResponse
	 *  2. get tempalte info
	 *  	$res->getTemplateInfo();
	 *  	the response is an array like:
	 *  		array(
	 * 				'templateId' => 'string',
	 * 				'name' => 'string',
	 * 				'content' => 'string',
	 * 				'status' => 'string',
	 * 				'createTime' => 'string time',
	 * 				'updateTime' => 'string time',
	 * 			);
	 * </pre>
     *
	 * @see \baidubce\sms\model\response\TplGetResponse
	 * @see \baidubce\sms\model\request\TplGetCommand::execute(array $options)
	 */
	public function templateInfo($templateId){
		$command = new TplGetCommand();
		$command->setTemplateId($templateId);
		$res = $command->execute($this->config);
		return $res;
	}
	
	/**
	 * Get the list of message template
	 *
	 * @return \baidubce\sms\model\response\TplGetListResponse
	 * <pre>
	 * you can use the following function to complete your business:
	 *  1. check if call success
	 * 		$res->isOk();
	 *  for more detail see \baidubce\sms\model\response\TplGetListResponse
	 *  2. get tempalte list info
	 *  	$res->getTemplateInfo();
	 *  	the response is an array like:
	 *  		array(
	 *  			array(
	 * 					'templateId' => 'string',
	 * 					'name' => 'string',
	 * 					'content' => 'string',
	 * 					'status' => 'string',
	 * 					'createTime' => 'string time',
	 * 					'updateTime' => 'string time',
	 * 				),
	 * 				...
	 * 			);
	 * </pre>
     *
	 * @see \baidubce\sms\model\response\TplGetListResponse
	 * @see \baidubce\sms\model\request\TplGetListCommand::execute(array $options)
	 */
	public function templateList(){
		$command = new TplGetListCommand();
		$res = $command->execute($this->config);
		return $res;
	}
	
	/**
	 * Update quota
	 * 
	 * @param int $maxSendPerDay
	 * @param int $maxReceivePerPhoneNumberDay
	 * @return \baidubce\sms\model\response\QuotaPutResponse
	 * <pre>
	 * you can use the following function to complete your business:
	 *  1. check if call success
	 * 		$res->isOk();
	 *  for more detail see \baidubce\sms\model\response\QuotaPutResponse
	 * </pre>
     *
	 * @see \baidubce\sms\model\response\QuotaPutResponse
	 * @see \baidubce\sms\model\request\QuotaPutCommand::execute(array $options)
	 */
	public function quotaUpdate($maxSendPerDay, $maxReceivePerPhoneNumberDay){
		$command = new QuotaPutCommand();
		$command->setSendQuota($maxSendPerDay);
		$command->setReceiveQuota($maxReceivePerPhoneNumberDay);
		$res = $command->execute($this->config);
		return $res;
	}
	
	/**
	 * Get quota info
	 *
	 * @return \baidubce\sms\model\response\QuotaGetResponse
	 * <pre>
	 * you can use the following function to complete your business:
	 *  1. check if call success
	 * 		$res->isOk();
	 * 	2. get send quota
	 * 		$res->getSendQuota();
	 *  3. get receive quota
	 *  	$res->getReceiveQuota();
	 *  4. get today send info
	 *  	$res->getSentToday();
	 *  for more detail see \baidubce\sms\model\response\QuotaGetResponse
	 * </pre>
     *
	 * @see \baidubce\sms\model\response\QuotaGetResponse
	 * @see \baidubce\sms\model\request\QuotaGetCommand::execute(array $options)
	 */
	public function quotaInfo(){
		$command = new QuotaGetCommand();
		$res = $command->execute($this->config);
		return $res;
	}
	
	/**
	 * Get the statistics about receiving message
	 *
	 * @param string $phoneNumber phone number, number string
	 * @return \baidubce\sms\model\response\ReceiverGetResponse
	 * <pre>
	 * you can use the following function to complete your business:
	 *  1. check if call success
	 * 		$res->isOk();
	 * 	2. get receive count today
	 * 		$res->getReceiveCountToday();
	 *  3. get max count per day
	 *  	$res->getMaxCountPerDay();
	 *  for more detail see \baidubce\sms\model\response\ReceiverGetResponse
	 * </pre>
     *
	 * @see \baidubce\sms\model\response\ReceiverGetResponse
	 * @see \baidubce\sms\model\request\ReceiverGetCommand::execute(array $options)
	 */
	public function receiverInfo($phoneNumber){
		$command = new ReceiverGetCommand();
		$command->setPhoneNumber($phoneNumber);
		$res = $command->execute($this->config);
		return $res;
	}
	
	const TEMPLATE_STATUS_PROCESSING = 'PROCESSING';
	const TEMPLATE_STATUS_VALID = 'VALID';
	const TEMPLATE_STATUS_UNVALID = 'UNVALID';
	
	/**
	 * Get request options.
	 * If you want to use default options, or your options is already set in SmsConfig.php,
	 * please call baidubce\sms\util\SmsOptions::getDefaultOptions() instead.
	 *
	 * @param string $ak read from baidubce\sms\SmsConfig.php SMS_AK by default
	 * @param string $sk read from baidubce\sms\SmsConfig.php SMS_SK by default
	 * @param string $host read from baidubce\sms\SmsConfig.php SMS_HOST by default
	 * @param string $port read from baidubce\sms\SmsConfig.php SMS_PORT by default
	 * @param string $apiVersion read from baidubce\sms\SmsConfig.php SMS_API_VERSION by default
	 * @param int $requestTimeout http request timeout default is 30s
	 * @param int $requestRetry http request retry times, default is 3 times
	 * @param boolean $debugMode set if use debug mode
	 * @return array options
	 * @see \baidubce\sms\util\SmsOptions::getDefaultOptions()
	 */
	public static function config( $ak = null, $sk = null,
			$host = null, $port = null,
			$apiVersion = null,
			$requestTimeout = Constant::SMS_HTTP_TIMEOUT,
			$requestRetry = Constant::SMS_HTTP_RETRY,
			$debugMode = null ){
		$options = SmsOptions::getDefaultOptions();
		if(!is_null($ak)){
			$options[SmsOptions::SECURE_AK_KEY] = trim($ak);
		}
		if(!is_null($sk)){
			$options[SmsOptions::SECURE_SK_KEY] = trim($sk);
		}
		if(!is_null($host)){
			$options[SmsOptions::HTTP_DOMAIN_HOST_KEY] = trim($host);
		}
		if(!is_null($port)){
			$options[SmsOptions::HTTP_DOMAIN_PORT_KEY] = trim($port);
		}
		if(!is_null($apiVersion)){
			$options[SmsOptions::SMS_COMMON_API_VERSION] = trim($apiVersion);
		}
		if(!is_null($requestTimeout)){
			$options[SmsOptions::HTTP_REQUEST_TIMEOUT] = trim($requestTimeout);
		}
		if(!is_null($requestRetry)){
			$options[SmsOptions::HTTP_REQUEST_RETRY] = trim($requestRetry);
		}
		if(!is_null($debugMode)){
			$options[SmsOptions::SMS_COMMON_DEBUG_KEY] = $debugMode;
		}
		return $options;
	}
}
