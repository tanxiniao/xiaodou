<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

namespace baidubce\sms;

//AK 公钥
define ( 'SMS_AK', 'f7874554659e4df4a51d8982268be3db' );

//SK 私钥
define ( 'SMS_SK', 'bca17dddf3b8419da43fcf61bfb81f97' );

//SMS Domain setting
define ( 'SMS_HOST', '10.40.25.34' );
define ( 'SMS_PORT', 8887 );

//Debug model, set true if you want more infomation
define('SMS_DEBUG_MODE', false);

//API版本
define ( 'SMS_API_VERSION', 'v1' );
