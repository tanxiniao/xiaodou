<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
require_once dirname(__DIR__) . '/services/bos/BosClient.php';
require_once dirname(__DIR__) . '/services/bos/util/BosOptions.php';
require_once dirname(__DIR__) . '/services/bos/model/request/CompleteMultipartUpload.php';


/*
 * PutBucket creates a bucket for you.
 * Remember that bucket name should be unique and different from all others.
 */
function CreateBucket($bos_client) {
    $request = array();
    $bucket_name = "sjl25986117127850";
    $request[\baidubce\bos\util\BosOptions::BUCKET] = $bucket_name;
    $request[\baidubce\bos\util\BosOptions::BUCKET_LOCATION] = "beijing";

    $response = $bos_client->createBucket($request);
//    $bos_client->deleteBucket($request);

    return $response;
}

/*
 * ListBucket shows all bucket an owner has.
 */
function ListBuckets($bos_client) {
    $request = array();

    return $bos_client->listBuckets($request);
}

/*
 * GetBucketConfiguration shows a specific bucket's configuration.
 */
function GetBucketConfiguration($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127850";

    return $bos_client->getBucketConfiguration($request);
}

/*
 * HeadBucket shows whether a bucket exist or not and whether a user has rights to manipulate the bucket if it exists.
 */
function DoesBucketExist($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127850";

    return $bos_client->doesBucketExist($request);
}

/*
 * DeleteBucket deletes a specific bucket.
 */
function DeleteBucket($bos_client) {
    $request = array();
    $bucket_name = "cuican-test-" . rand() . rand();
    $request[\baidubce\bos\util\BosOptions::BUCKET_LOCATION] = "beijing";
    $request[\baidubce\bos\util\BosOptions::BUCKET] = $bucket_name;
    $bos_client->createBucket($request);
    return $bos_client->deleteBucket($request);
}

/*
 * PutBucketAcl set the acl of a bucket.
 */
function SetBucketAcl($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127850";
    $request[\baidubce\bos\util\BosOptions::ACL] = "public-read-write";

    return $bos_client->setBucketAcl($request);
}

function GetBucketAcl($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127850";

    return $bos_client->getBucketAcl($request);
}

$client_options = array();
//$client_options[\bce\bos\common\BosOptions::ENDPOINT] = "10.58.144.56:8080";
//$client_options[\bce\bos\common\BosOptions::ACCESS_KEY_ID] = "9aed84eced8a4cd8b20622352f345cd0";
//$client_options[\bce\bos\common\BosOptions::ACCESS_KEY_SECRET] = "cbc3a456b9ff401cad2094193bab0413";

$client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "10.99.19.14:8080";
$client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "9c06499d35174c25b69578eaa5ce3bd9";
$client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "34c23b3de24b43fda34978a5c3b90970";

//$client_options[\bce\bos\common\BosOptions::ENDPOINT] = "10.26.208.32:8828";
//$client_options[\bce\bos\common\BosOptions::ACCESS_KEY_ID] = "6dbd3c7dca7f4fc99025fe8b6e883073";
//$client_options[\bce\bos\common\BosOptions::ACCESS_KEY_SECRET] = "94377aa9f6944207bc18d90460419092";

$bos_client = \baidubce\bos\BosClient::factory($client_options);

try {
//    //create a bucket
//    $response = CreateBucket($bos_client);
//    echo sprintf("\nCreateBucket function, bucket's location:%s", $response->getLocation());


    //show all your buckets
    $response = ListBuckets($bos_client);
    echo sprintf("\nListBucket function, owner's id:%s, owner's name:%s\n", $response->getOwnerId(), $response->getOwnerDisplayName());

    $bucket_list = $response->getBucketList();
    foreach($bucket_list as $bucket) {
        $time = $bucket->getCreateTime();
        echo sprintf("\nbucket name:%s, created time:%s\n", $bucket->getBucketName(), $bucket->getCreateTime()->format(\DateTime::ISO8601));
    }


//    //show a bucket's configuration
//    $result = GetBucketConfiguration($bos_client);
//    echo sprintf("\nGetBucketConfiguration function, LocationConstraint:%s\n", $result->getLocationConstraint());
//
//    //check if a bucket has already existed or not
//    //you can also know if you has the right to manipulate the bucket
//    DoesBucketExist($bos_client);
//
//    //delete a specific bucket
//    DeleteBucket($bos_client);
//
//    //modify a bucket's acl configuration
//    SetBucketAcl($bos_client);
//
//    $response = GetBucketAcl($bos_client);
//    $acl_list = $response->getAcl();
//    foreach($acl_list as $acl){
//        echo sprintf("\ngrantee's name:%s, id:%d, permission:%s\n",$acl->getGranteeName(), $acl->getGranteeId(), $acl->getPermission());
//    }


} catch (\baidubce\bos\exception\BosServiceException $ex){
    echo sprintf("%s\n", $ex->getDebugMessage());
}catch (\baidubce\bos\exception\BosBaseException $ex) {
    echo sprintf("%s\n", $ex->getDebugMessage());
} catch (Exception $ex) {
    echo sprintf("%s\n", $ex->getMessage());
}