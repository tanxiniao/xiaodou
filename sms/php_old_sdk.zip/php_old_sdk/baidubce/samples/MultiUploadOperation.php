<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

require_once dirname(__DIR__) . '/services/bos/BosClient.php';
require_once dirname(__DIR__) . '/services/bos/util/BosOptions.php';
require_once dirname(__DIR__) . '/services/bos/model/request/CompleteMultipartUpload.php';
use \baidubce\bos\model\request\MultipartUploadPartId;

/*
 * InitMultiUpload is the first step if you want to upload a super big object.
 */
function InitiateMultiUpload($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127850";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "supper_object_1";

    return $bos_client->initiateMultipartUpload($request);
}

function StringRepeat($str, $times) {
    $result = array();
    for ($i = 0; $i < $times; $i++) {
        array_push($result, $str);
    }

    return implode("", $result);
}

/*
 * Fake object content for uploading
 */
function GenerateUploadPart() {
    $str = "0123456789";
    return StringRepeat(StringRepeat($str, 1024), 1024);
}

/*
 * When uploading a super big object, the first step is to do the initiation
 * then call  UploadPart function
 * finally call CompleteMultipartUpload function
 */
function PutSupperFile($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127850";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "supper-object";

    $response = $bos_client->initiateMultipartUpload($request);
    $part_list = array();

    $request[\baidubce\bos\util\BosOptions::UPLOAD_ID] = $response->getUploadId();
    $request[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] = GenerateUploadPart();
    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 1;
    $response = $bos_client->uploadPart($request);
    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 1));

    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 2;
    $response = $bos_client->uploadPart($request);
    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 2));

    $request[\baidubce\bos\util\BosOptions::PART_LIST] = $part_list;

    return $bos_client->completeMultipartUpload($request);
}

/*
 * When you want to abort a process of uploading a super big object, call AbortMultipartUpload function
 */
function AbortPutSupperFile(\baidubce\bos\BosClient $bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127850";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "supper-object";

    $response = $bos_client->initiateMultipartUpload($request);
    $part_list = array();

    $request[\baidubce\bos\util\BosOptions::UPLOAD_ID] =  $response->getUploadId();
    $request[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] = substr(GenerateUploadPart(), 0, 1024);
    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 1;
    $response = $bos_client->uploadPart($request);
    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 1));

    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 2;
    $response = $bos_client->uploadPart($request);
    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 2));

    return $bos_client->abortMultipartUpload($request);
}

/*
 * ListParts shows those successfully uploaded parts under a specific UploadId
 */
function ListParts($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "bucket-1234";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "supper-object";

    //Initiate the process of uploading a super big file
    $response = $bos_client->initiateMultipartUpload($request);
    $part_list = array();

    $request[\baidubce\bos\util\BosOptions::UPLOAD_ID] = $response->getUploadId();

    $request[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] = GenerateUploadPart();
    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 1;
    $response = $bos_client->uploadPart($request);
    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 1));

    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 2;
    $response = $bos_client->uploadPart($request);
    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 2));

    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 3;
    $response = $bos_client->uploadPart($request);
    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 3));

    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 4;
    $response = $bos_client->uploadPart($request);
    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 4));

    $request[\baidubce\bos\util\BosOptions::PART_LIST] = $part_list;

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test3";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "supper-object";
    $request[\baidubce\bos\util\BosOptions::UPLOAD_ID] =  "5242886abe414cfbf4a9a5e132d4eb31";
    $request[\baidubce\bos\util\BosOptions::MAX_PARTS_COUNT] = 2;
    $request[\baidubce\bos\util\BosOptions::PART_NUMBER_MARKER] = "1";

    //Show successfully uploaded part under a specific UploadId
    return $bos_client->listParts($request);
}

/*
 * ListMultipartUploads shows those parts that have finished the IniMultipartUplpad process but neither the CompleteMultipartUploads nor AbortMultipartUpload
 */
function ListMultipartUploads($bos_client) {
    //Initiate the process of uploading a super big file
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "bucket-1234";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/";
    $response = $bos_client->initiateMultipartUpload($request);
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/a";
    $response = $bos_client->initiateMultipartUpload($request);
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/b";
    $response = $bos_client->initiateMultipartUpload($request);
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/b/c";
    $response = $bos_client->initiateMultipartUpload($request);
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/c/d";
    $response = $bos_client->initiateMultipartUpload($request);
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/d";
    $response = $bos_client->initiateMultipartUpload($request);

    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object1";
    $response = $bos_client->initiateMultipartUpload($request);

    //Set options before calling ListMultipartUploads function
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "bucket-1234";
    $request[\baidubce\bos\util\BosOptions::LIST_PREFIX] = "test_obj";
    $request[\baidubce\bos\util\BosOptions::LIST_MARKER] = "test_object/b";
    $request[\baidubce\bos\util\BosOptions::LIST_DELIMITER] = "/";
    $request[\baidubce\bos\util\BosOptions::LIST_MAX_UPLOAD_SIZE] = 2;
    return $bos_client->listMultipartUploads($request);
}

$client_options = array();
$client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "10.99.19.14:8080";
$client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "9c06499d35174c25b69578eaa5ce3bd9";
$client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "34c23b3de24b43fda34978a5c3b90970";
$bos_client = \baidubce\bos\BosClient::factory($client_options);

try {
    $response = PutSupperFile($bos_client);
    echo sprintf("\nPutSuperFile, bucket_name:%s, object_name:%s, location:%s, etag:%s\n",
            $response->getBucketName(), $response->getObjectName(), $response->getLocation(), $response->getEtag());

//    AbortPutSupperFile($bos_client);
//
//    $result = ListMultipartUploads($bos_client);
//    echo sprintf("ListMultipartUploads,  bucket_name:%s, prefix:%s, marker:%s, max_uploads:%s, isTruncated:%d\n",
//        $result->getBucketName(), $result->getPrefix(), $result->getKeyMarker(), $result->getMaxUploads(), $result->getIsTruncated());
//    $upload_list = $result->getUploadList();
//    foreach($upload_list as $upload) {
//        echo sprintf("upload, object_name:%s, initiatedTime:%s, owner_name:%s, owner_id:%s\n",
//            $upload->getObjectName(), $upload->getInitiatedTime()->format(DateTime::ISO8601), $upload->getOwnerName(), $upload->getOwnerId());
//    }
//    $common_prefixs = $result->getCommonPrefixList();
//    foreach($common_prefixs as $common_prefix) {
//        echo "common_prefix:$common_prefix\n";
//    }
//
//    $response = ListParts($bos_client);
//    echo sprintf("\nListParts, bucket_name:%s, object_name:%s, upload_id:%s, initiated_time:%s, owner_name:%s, owner_id:%s,".
//        "partNumberMarker:%s, nextPartNumberMarker:%s, maxParts:%s, isTruncated:%d\n",
//        $response->getBucketName(), $response->getObjectname(), $response->getUploadId(), $response->getInitiatedTime()->format(DateTime::ISO8601), $response->getOwnerName(), $response->getOwnerId(),
//        $response->getPartNumberMarker(), $response->getNextPartNumberMarker(), $response->getMaxParts(), $response->getIsTruncated());
//    $part_info_list = $response->getPartInfo();
//
//    foreach ($part_info_list as $part) {
//        echo sprintf("\npart, partNumber:%s, lastModified:%s, eTag:%s, size:%s\n",
//            $part->getPartNumber(), $part->getLastModified()->format(DateTime::ISO8601), $part->getEtag(), $part->getSize());
//    }

} catch (\baidubce\bos\exception\BosServiceException $ex){
    echo sprintf("%s\n", $ex->getDebugMessage());
}catch (\baidubce\bos\exception\BosBaseException $ex) {
    echo sprintf("%s\n", $ex->getDebugMessage());
} catch (Exception $ex) {
    echo sprintf("%s\n", $ex->getMessage());
}