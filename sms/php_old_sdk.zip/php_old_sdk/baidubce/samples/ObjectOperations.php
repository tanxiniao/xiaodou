<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
require_once dirname(__DIR__) . '/services/bos/BosClient.php';
require_once dirname(__DIR__) . '/services/bos/util/BosOptions.php';
require_once dirname(__DIR__) . '/services/bos/model/request/CompleteMultipartUpload.php';

/*
 * PutObject allows you to put an object to an existing bucket.
 * If you don't have an bucket, then create one first. See BucketOperation.
 */
function PutObject($bos_client) {
    $request = array();

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127850";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "sjl01";
    $request[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] = "0123456789";

    $request["x-bce-meta-key1"] = "val1";
    $request["X-bce-meta-key2"] = "val2";

    return $bos_client->putObject($request);
}

/*
 * GetObject allows you to get a specific object.
 * But first you must have READ right on that object
 */
function GetObject($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127850";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "sjl01";
    $request["range"] = "bytes=re-3d";

    return $bos_client->getObject($request);
}

/*
 * HeadObject shows you a specific object's meta data.
 */
function GetObjectMetadata($bos_client) {
    $request = array();

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127850";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "sjl01";

    return $bos_client->getObjectMetadata($request);
}

/*
 * DeleteObject deletes a specific object.
 */
function DeleteObject($bos_client) {
    $request = array();

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127850";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "sjl01";

    return $bos_client->deleteObject($request);
}

/*
 * CopyObject copies a specific to another directory.
 */
function CopyObject($bos_client) {
    $request = array();

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "bucket-1234";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "cuican_object2";
    $request[\baidubce\bos\util\BosOptions::OBJECT_COPY_SOURCE] = "/bucket-1234/cuican_object";
    $request[\baidubce\bos\util\BosOptions::OBJECT_COPY_METADATA_DIRECTIVE] = "replace";
    $request["x-bce-meta-key3"] = "val3";

    return $bos_client->copyObject($request);
}

/*
 * ListObject shows all objects' information under a specific bucket.
 */
function ListObjects($bos_client) {
//    $object_name_list = array("testa0object/aa","testa0object/bb","testa0object/cc","testa0object/ll","testb0","testc0","testd0");
//    foreach ($object_name_list as $object_name) {
//        $put_object_request = array();
//        $put_object_request[\bce\bos\common\BosOptions::BUCKET] = "sjl24771197765241";
//        $put_object_request[\bce\bos\common\BosOptions::OBJECT] = $object_name;
//        $put_object_request[\bce\bos\common\BosOptions::OBJECT_CONTENT_STRING] = "0123456789";
//        $bos_client->putObject($put_object_request);
//    }

    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "sjl25986117127856";
    $request[\baidubce\bos\util\BosOptions::LIST_MAX_KEY_SIZE] = 2;
//    $request[\baidubce\bos\util\BosOptions::LIST_PREFIX] = "testa0object/";
//    $request[\bce\bos\common\BosOptions::LIST_MARKER] = "testc0";
//    $request[\baidubce\bos\util\BosOptions::LIST_DELIMITER] = "/";

    return $bos_client->listObjects($request);
}

$client_options = array();
$client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "10.99.19.14:8080";
$client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "9c06499d35174c25b69578eaa5ce3bd9";
$client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "34c23b3de24b43fda34978a5c3b90970";
$bos_client = \baidubce\bos\BosClient::factory($client_options);

try {

//    //Put object into an existed bucket. If you don't have any bucket, then create one first.
//    $response = PutObject($bos_client);
//    echo sprintf("Object's etag:%s, request_id:%s, debug_id:%s\n",
//                $response->getETag(), $response->getRequestId(), $response->getDebugId());

    //If you want to know an object's meta data without downloading that object, use HeadObject().
//    $response = GetObjectMetadata($bos_client);
//    echo sprintf("headobject, etag:%s, content_length:%s\n", $response->getETag(), $response->getContentLength());
//    echo "begin object meta\n";
//    print_r($response->getObjectMeta());
//    echo "end object meta\n";

//    //show all objects' information under a specific bucket.
//    $response = ListObjects($bos_client);
//    echo sprintf("\n ListObject, bucket_name:%s, prefix:%s, delimiter:%s, marker:%s, maxKeys:%d, isTruncated:%s\n",
//        $response->getBucketName(), $response->getPrefix(), $response->getDelimiter(), $response->getMarker(), $response->getMaxKeys(), $response->isTruncated());
//    $object_list = $response->getObjectList();
//    foreach($object_list as $object) {
//        echo sprintf("\n object_name:%s, last_modified:%s, etag:%s, size:%s, owner_id:%s, owner_name:%s\n",
//                $object->getObjectName(), $object->getLastModified()->format(\DateTime::ISO8601), $object->getEtag(), $object->getSize(), $object->getOwnerId(), $object->getOwnerName());
//    }

//    //retrieve an object
//    $response = GetObject($bos_client);
//    echo sprintf("GetObject, tag:%s, Content-Range:%s, Content-Length:%s, content:%s\n",
//            $response->getETag(), $response->getContentRange(), $response->getContentLength(), $response->getContent());
//    echo "begin object meta\n";
//    print_r($response->getObjectMeta());
//    echo "end object meta\n";

    //delete an object
    $response = DeleteObject($bos_client);

//    //copy an object to another directory
//    $response = CopyObject($bos_client);
//    echo sprintf("copyobject, etag:%s, time:%s\n", $response->getDestEtag(), $response->getDestLastModify()->format(\DateTime::ISO8601));

} catch (\baidubce\bos\exception\BosServiceException $ex){
    echo sprintf("%s\n", $ex->getDebugMessage());
}catch (\baidubce\bos\exception\BosBaseException $ex) {
    echo sprintf("%s\n", $ex->getDebugMessage());
} catch (Exception $ex) {
    echo sprintf("%s\n", $ex->getMessage());
}