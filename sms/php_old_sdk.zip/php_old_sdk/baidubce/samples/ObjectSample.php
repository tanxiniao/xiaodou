<?php
/*
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
require_once dirname(__DIR__) . '/services/bos/BosClient.php';
require_once dirname(__DIR__) . '/services/bos/util/BosOptions.php';
require_once dirname(__DIR__) . '/services/bos/model/request/CompleteMultipartUpload.php';
use \baidubce\bos\model\request\MultipartUploadPartId;

function PutObjectString($bos_client) {
    $request = array();

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test7";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "cuican_object";
    $request[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] = "0123456789";

    $request["x-bce-meta-key1"] = "val1";
    $request["x-bce-meta-key2"] = "val2";

    return $bos_client->putObject($request);
}

function GetObjectString($bos_client) {
    $request = array();

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test7";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "cuican_object";
    $request["range"] = "bytes=2-5";

    return $bos_client->getObject($request);
}


function HeadObject($bos_client) {
    $request = array();

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "cuican_object2";

    return $bos_client->headObject($request);
}

function DeleteObject($bos_client) {
    $request = array();

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "cuican_object";

    return $bos_client->deleteObject($request);
}

function CopyObject($bos_client) {
    $request = array();

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "cuican_object2";
    $request[\baidubce\bos\util\BosOptions::OBJECT_COPY_SOURCE] = "/cuican-test5/cuican_object";
    $request[\baidubce\bos\util\BosOptions::OBJECT_COPY_METADATA_DIRECTIVE] = "replace";
    $request["x-bce-meta-key3"] = "val3";

    return $bos_client->copyObject($request);
}

function PutBucket($bos_client) {
    $request = array();

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test7";

    $request[\baidubce\bos\util\BosOptions::BUCKET_LOCATION] = "beijing";

    $response = $bos_client->putBucket($request);
    // $bos_client->deleteBucket($request);

    return $response;
}

function ListBucket($bos_client) {
    $request = array();

    return $bos_client->listBucket($request);
}

function GetBucketConfiguration($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";

    return $bos_client->getBucketConfiguration($request);
}

function ListObject($bos_client) {
//    $object_name_list = array("testa0object", "testb0object", "testx0object", "testx10object", "testx20object", "testz0object");
//    foreach ($object_name_list as $object_name) {
//        $put_object_request = array();
//        $put_object_request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
//        $put_object_request[\baidubce\bos\util\BosOptions::OBJECT] = $object_name;
//        $put_object_request[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] = "0123456789";
//        $bos_client->putObject($put_object_request);
//    }

    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
    $request[\baidubce\bos\util\BosOptions::LIST_MAX_KEY_SIZE] = 3;
    $request[\baidubce\bos\util\BosOptions::LIST_PREFIX] = "test";
    $request[\baidubce\bos\util\BosOptions::LIST_MARKER] = "testx";
    $request[\baidubce\bos\util\BosOptions::LIST_DELIMITER] = "1";

    return $bos_client->listObject($request);
}

function HeadBucket($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";

    return $bos_client->headBucket($request);
}

function DeleteBucket($bos_client) {
    $request = array();
    $bucket_name = "cuican-test5";
    $request[\baidubce\bos\util\BosOptions::BUCKET_LOCATION] = "beijing";
    $request[\baidubce\bos\util\BosOptions::BUCKET] = $bucket_name;
    // $bos_client->putBucket($request);
    return $bos_client->deleteBucket($request);
}

function PutBucketAcl($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
    $request[\baidubce\bos\util\BosOptions::ACL] = "public-read-write";

    return $bos_client->putBucketAcl($request);
}

function GetBucketAcl($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";

    return $bos_client->getBucketAcl($request);
}

function InitMultiUpload($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "supper-object";

    return $bos_client->initMultiUpload($request);
}

function StringRepeat($str, $times) {
    $result = array();
    for ($i = 0; $i < $times; $i++) {
        array_push($result, $str);
    }

    return implode("", $result);
}

function GenerateUploadPart() {
    $str = "0123456789";
    return StringRepeat(StringRepeat($str, 1024), 1024);
}

function PutSupperFile($bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "supper-object";
    $request[\baidubce\bos\util\BosOptions::BUCKET_LOCATION] = "beijing";

    $response = $bos_client->initMultiUpload($request);
    $part_list = array();

    $request[\baidubce\bos\util\BosOptions::UPLOAD_ID] =  $response->getUploadId();
    $request[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] = GenerateUploadPart();
    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 1;
    $response = $bos_client->uploadPart($request);
    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 1));

    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 2;
    $response = $bos_client->uploadPart($request);
    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 2));

    $request[\baidubce\bos\util\BosOptions::PART_LIST] = $part_list;

    return $bos_client->completeMultipartUpload($request);
}

function AbortPutSupperFile(\baidubce\bos\BosClient $bos_client) {
    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "supper-object";

    $response = $bos_client->initMultiUpload($request);
    $part_list = array();

    $request[\baidubce\bos\util\BosOptions::UPLOAD_ID] =  $response->getUploadId();
    $request[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] = substr(GenerateUploadPart(), 0, 1024);
    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 1;
    $response = $bos_client->uploadPart($request);
    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 1));

//    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 2;
//    $response = $bos_client->uploadPart($request);
//    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 2));

    return $bos_client->abortMultipartUpload($request);
}

function ListParts($bos_client) {
    $request = array();
//    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test3";
//    $request[\baidubce\bos\util\BosOptions::OBJECT] = "supper-object";
//
//    $response = $bos_client->initMultiUpload($request);
//    $part_list = array();
//
//    $request[\baidubce\bos\util\BosOptions::UPLOAD_ID] =  $response->getUploadId();
//    $request[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] = GenerateUploadPart();
//    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 1;
//    $response = $bos_client->uploadPart($request);
//    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 1));
//
//    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 2;
//    $response = $bos_client->uploadPart($request);
//    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 2));
//
//    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 3;
//    $response = $bos_client->uploadPart($request);
//    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 3));
//
//    $request[\baidubce\bos\util\BosOptions::PART_NUM] = 4;
//    $response = $bos_client->uploadPart($request);
//    array_push($part_list, new MultipartUploadPartId($response->getEtag(), 4));

    // $request[\baidubce\bos\util\BosOptions::PART_LIST] = $part_list;

    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
    $request[\baidubce\bos\util\BosOptions::OBJECT] = "supper-object";
    $request[\baidubce\bos\util\BosOptions::UPLOAD_ID] =  "5242886abe414cfbf4a9a5e132d4eb31";
    $request[\baidubce\bos\util\BosOptions::MAX_PARTS_COUNT] = 2;
    $request[\baidubce\bos\util\BosOptions::PART_NUMBER_MARKER] = "1";
    return $bos_client->listParts($request);
}

function ListMultipartUploads($bos_client) {
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
//    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/";
//    $response = $bos_client->initMultiUpload($request);
//    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/a";
//    $response = $bos_client->initMultiUpload($request);
//    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/b";
//    $response = $bos_client->initMultiUpload($request);
//    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/b/c";
//    $response = $bos_client->initMultiUpload($request);
//    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/c/d";
//    $response = $bos_client->initMultiUpload($request);
//    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object/d";
//    $response = $bos_client->initMultiUpload($request);

    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object1";
    $response = $bos_client->initMultiUpload($request);

    $request = array();
    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
    $request[\baidubce\bos\util\BosOptions::LIST_PREFIX] = "test_obj";
    $request[\baidubce\bos\util\BosOptions::LIST_MARKER] = "test_object/b";
    $request[\baidubce\bos\util\BosOptions::LIST_DELIMITER] = "/";
    $request[\baidubce\bos\util\BosOptions::LIST_MAX_UPLOAD_SIZE] = 2;
    return $bos_client->listMultipartUploads($request);
}

$client_options = array();

// $client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "10.216.45.63:8080";
$client_options[\baidubce\bos\util\BosOptions::ENDPOINT] = "cq02-inf-bec18.cq02.baidu.com:8080";
$client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_ID] = "cuicanak";
$client_options[\baidubce\bos\util\BosOptions::ACCESS_KEY_SECRET] = "cuicansk";

$bos_client = \baidubce\bos\BosClient::factory($client_options);

try {
    Putbucket($bos_client);
    $response = ListBucket($bos_client);
    echo sprintf("list bucket, owner_id:%s, owner_name:%s\n", $response->getOwnerId(), $response->getOwnerDisplayName());
    $response = PutObjectString($bos_client);
    echo sprintf("get object etag:%s, request_id:%s, debug_id:%s\n",
                $response->getETag(), $response->getRequestId(), $response->getDebugId());

    $response = GetObjectString($bos_client);
    echo sprintf("get object, tag:%s, Content-Range:%s, Content-Length:%s, content:%s\n",
            $response->getETag(), $response->getContentRange(), $response->getContentLength(), $response->getContent());
    echo "begin object meta\n";
    print_r($response->getObjectMeta());
    echo "end object meta\n";

    // $response = DeleteObject($bos_client);

      $response = CopyObject($bos_client);
    echo sprintf("copyobject, etag:%s, time:%s\n", $response->getDestEtag(), $response->getDestLastModify()->format(\DateTime::ISO8601));

    $response = HeadObject($bos_client);
    echo sprintf("headobject, etag:%s, content_length:%s\n", $response->getETag(), $response->getContentLength());
    echo "begin object meta\n";
    print_r($response->getObjectMeta());
    echo "end object meta\n";
    $response = PutBucket($bos_client);
    echo sprintf("putbucket, location:%s", $response->getLocation());
    $response = ListBucket($bos_client);
    echo sprintf("list bucket, owner_id:%s, owner_name:%s\n", $response->getOwnerId(), $response->getOwnerDisplayName());
    $bucket_list = $response->getBucketList();
    foreach($bucket_list as $bucket) {
        $time = $bucket->getCreateTime();
        echo sprintf("bucket_name:%s, create_time:%s\n", $bucket->getBucketName(), $bucket->getCreateTime()->format(\DateTime::ISO8601));
    }

    $result = GetBucketConfiguration($bos_client);
    echo sprintf("get_bucket_configuration, LocationConstraint:%s\n", $result->getLocationConstraint());
    $response = ListObject($bos_client);
    echo sprintf("list object, bucket_name:%s, prefix:%s, delimiter:%s, marker:%s, maxKeys:%d, isTruncated:%s\n",
        $response->getBucketName(), $response->getPrefix(), $response->getDelimiter(), $response->getMarker(), $response->getMaxKeys(), $response->isTruncated());
    $object_list = $response->getObjectList();
    foreach($object_list as $object) {
        echo sprintf("object_name:%s, last_modified:%s, etag:%s, size:%s, owner_id:%s, owner_name:%s\n",
                $object->getObjectName(), $object->getLastModified()->format(\DateTime::ISO8601), $object->getEtag(), $object->getSize(), $object->getOwnerId(), $object->getOwnerName());
    }

    $common_prefix_list = $response->getCommonPrefixList();
    foreach($common_prefix_list as $prefix) {
        echo sprintf("prefix:%s\n", $prefix->getPrefix());
    }
    HeadBucket($bos_client);
    DeleteBucket($bos_client);
    PutBucketAcl($bos_client);
    $response = GetBucketAcl($bos_client);
    echo sprintf("get_bucket_acl, acl:%s\n", $response->getAcl());
    $response = PutSupperFile($bos_client);
    echo sprintf("put supper file, bucket_name:%s, object_name:%s, location:%s, etag:%s\n",
            $response->getBucketName(), $response->getObjectName(), $response->getLocation(), $response->getEtag());
    AbortPutSupperFile($bos_client);
    $response = ListParts($bos_client);
    echo sprintf("list_parts, bucket_name:%s, object_name:%s, upload_id:%s, initiated_time:%s, owner_name:%s, owner_id:%s,".
            "partNumberMarker:%s, nextPartNumberMarker:%s, maxParts:%s, isTruncated:%d\n",
            $response->getBucketName(), $response->getObjectname(), $response->getUploadId(), $response->getInitiatedTime()->format(DateTime::ISO8601), $response->getOwnerName(), $response->getOwnerId(),
            $response->getPartNumberMarker(), $response->getNextPartNumberMarker(), $response->getMaxParts(), $response->getIsTruncated());
    $part_info_list = $response->getPartInfo();

    foreach ($part_info_list as $part) {
        echo sprintf("part, partNumber:%s, lastModified:%s, eTag:%s, size:%s\n",
                $part->getPartNumber(), $part->getLastModified()->format(DateTime::ISO8601), $part->getEtag(), $part->getSize());
    }


//    $result = ListMultipartUploads($bos_client);
//    echo sprintf("ListMultipartUploads,  bucket_name:%s, prefix:%s, marker:%s, max_uploads:%s, isTruncated:%d\n",
//            $result->getBucketName(), $result->getPrefix(), $result->getKeyMarker(), $result->getMaxUploads(), $result->getIsTruncated());
//    $upload_list = $result->getUploadList();
//    foreach($upload_list as $upload) {
//        echo sprintf("upload, object_name:%s, initiatedTime:%s, owner_name:%s, owner_id:%s\n",
//            $upload->getObjectName(), $upload->getInitiatedTime()->format(DateTime::ISO8601), $upload->getOwnerName(), $upload->getOwnerId());
//    }
//    $common_prefixs = $result->getCommonPrefixList();
//    foreach($common_prefixs as $common_prefix) {
//        echo "common_prefix:$common_prefix\n";
//    }
//    PutBucket($bos_client);
//    PutObjectString($bos_client);
//    GetObjectString($bos_client);

//    $request = array();
//    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test3456";
//    $request[\baidubce\bos\util\BosOptions::BUCKET_LOCATION] = "beijing";
//
//    $response = $bos_client->putBucket($request);
//    $request[\baidubce\bos\util\BosOptions::ACL] = "public-read";
//    $response = $bos_client->putBucketAcl($request);
//    $bos_client->deleteBucket($request);
//    $response = $bos_client->putBucket($request);
//    $response = $bos_client->getBucketAcl($request);
//    $bos_client->deleteBucket($request);

//    $request = array();
//
//    $request[\baidubce\bos\util\BosOptions::BUCKET] = "cuican-test5";
//    $request[\baidubce\bos\util\BosOptions::OBJECT_CONTENT_STRING] = "0123456789";
//    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_object";
//    $bos_client->putObject($request);
//
//    $request[\baidubce\bos\util\BosOptions::OBJECT] = "cuican_object崔灿\0%2A";
//    $request["x-bce-meta-key1"] = "崔灿\1$%DEmeta_key";
//    $request["x-bce-meta-key2"] = "崔灿\1$%DEmeta_value";
//    $bos_client->putObject($request);
//
//    $response = ($bos_client->listObject($request));
//    echo sprintf("list object, bucket_name:%s, prefix:%s, delimiter:%s, marker:%s, maxKeys:%d, isTruncated:%s\n",
//    $response->getBucketName(), $response->getPrefix(), $response->getDelimiter(), $response->getMarker(), $response->getMaxKeys(), $response->isTruncated());
//    $object_list = $response->getObjectList();
//    foreach($object_list as $object) {
//        echo sprintf("object_name:%s, last_modified:%s, etag:%s, size:%s, owner_id:%s, owner_name:%s\n",
//                $object->getObjectName(), $object->getLastModified()->format(\DateTime::ISO8601), $object->getEtag(), $object->getSize(), $object->getOwnerId(), $object->getOwnerName());
//    }
//
//    $common_prefix_list = $response->getCommonPrefixList();
//    foreach($common_prefix_list as $prefix) {
//        echo sprintf("prefix:%s\n", $prefix->getPrefix());
//    }

//    $request = array();
//
//    $request[\baidubce\bos\util\BosOptions::BUCKET] = "tongsuo-test";
//
//    $request[\baidubce\bos\util\BosOptions::OBJECT] = "rccxxxxxxxx";
//    $request[\baidubce\bos\util\BosOptions::OBJECT_COPY_SOURCE] = "/jiangtao/test_rename_src/rcc";
//    $request[\baidubce\bos\util\BosOptions::OBJECT_COPY_METADATA_DIRECTIVE] = "copy";
//    $request["x-bce-meta-key3"] = "val3";
//
//    $bos_client->copyObject($request);
//
//    $request[\baidubce\bos\util\BosOptions::BUCKET] = "jiangtao";
//
//    $request[\baidubce\bos\util\BosOptions::OBJECT] = "test_rename_src/rcc";
//    $bos_client->getObject($request);

//    PutSupperFile($bos_client);
//    DeleteBucket($bos_client);
//    PutBucket($bos_client);
    PutObjectString($bos_client);
//    GetObjectString($bos_client);
} catch (\baidubce\bos\exception\BosServiceException $ex){
    echo sprintf("%s\n", $ex->getDebugMessage());
}catch (\baidubce\bos\exception\BosBaseException $ex) {
    echo sprintf("%s\n", $ex->getDebugMessage());
} catch (Exception $ex) {
    echo sprintf("%s\n", $ex->getMessage());
}